<?php
    $Author="Maneesha Mishra";
    $Description="Opposite Words from A to R";
    $Keyword="Opposite Words from A to R";
    $Title="Opposite Words";
    $Contents='Oppositewords';
    require "IndexRelated/indexUpper.php";
?> 
		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
         <p><a class="TutorialPreviousPagea" href="Fullforms.php">&lt;&lt;-Previous  Page</a>
         <a class="TutorialNextPagea"  href="BodyPart.php">Next Page-&gt;&gt;</a></p>
               <p class="h2" align="center">Opposite Words</p>
        	   <table border="1" width="100%">
                <tr style="background-color: #769FEA;">
                	<td colspan="3" align="center"><h4>A</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center" width="33%">Accord &nbsp;&nbsp;&#10005;&nbsp;&nbsp; Disaccord</td>
                	<td align="center" width="33%">Analysis &nbsp;&#10005;&nbsp; Synthesis</td>
                    <td align="center" width="33%">Accept &nbsp;&#10005;&nbsp; Reject</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Awokeward &nbsp;&#10005;&nbsp; Graceful</td>
                	<td align="center">Attract &nbsp;&#10005;&nbsp; Repel</td>
                    <td align="center">Arrongant &nbsp;&#10005;&nbsp; Humble</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Ambiguous &nbsp;&#10005;&nbsp; Clear</td>
                	<td align="center">Ascent &nbsp;&#10005;&nbsp; Discent</td>
                    <td align="center">Acquit &nbsp;&#10005;&nbsp; Convict</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Ancient &nbsp;&#10005;&nbsp; Mordern</td>
                	<td align="center">Arrival &nbsp;&#10005;&nbsp; Departure</td>
                    <td align="center">Attack &nbsp;&#10005;&nbsp; Defend</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Artificial &nbsp;&#10005;&nbsp; Natural</td>
                	<td align="center"></td>
                    <td align="center"></td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>B</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Barborous &nbsp;&#10005;&nbsp; Civilized</td>
                	<td align="center">Believe &nbsp;&#10005;&nbsp; Dought</td>
                    <td align="center">Bliss &nbsp;&#10005;&nbsp; Misery</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Bold &nbsp;&#10005;&nbsp; Limid</td>
                	<td align="center">Brave &nbsp;&#10005;&nbsp; Coward</td>
                    <td align="center">Bright &nbsp;&#10005;&nbsp; Dark</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Blame &nbsp;&#10005;&nbsp; Praise</td>
                	<td align="center">Busy &nbsp;&#10005;&nbsp; Lazy/Idle</td>
                    <td align="center">Barren &nbsp;&#10005;&nbsp; Fertile</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Beautiful &nbsp;&#10005;&nbsp; Ugly</td>
                	<td align="center">Bitter &nbsp;&#10005;&nbsp; Sweet</td>
                    <td align="center">Borrow &nbsp;&#10005;&nbsp; Lend</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Build &nbsp;&#10005;&nbsp; Destroy</td>
                	<td align="center">Broad &nbsp;&#10005;&nbsp; Narrow</td>
                    <td align="center"></td>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>C</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Credit &nbsp;&#10005;&nbsp; Debit</td>
                	<td align="center">Cheap &nbsp;&#10005;&nbsp; Costly</td>
                    <td align="center">Compress &nbsp;&#10005;&nbsp; Expand</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Comedy &nbsp;&#10005;&nbsp; Tragedy</td>
                	<td align="center">Create &nbsp;&#10005;&nbsp; Destroy</td>
                    <td align="center">Cruel &nbsp;&#10005;&nbsp; Kind</td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>D</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Danger &nbsp;&#10005;&nbsp; Safe</td>
                	<td align="center">Dscend &nbsp;&#10005;&nbsp; Ascend</td>
                    <td align="center">Discourage &nbsp;&#10005;&nbsp; Encourage</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Delete &nbsp;&#10005;&nbsp; Insert</td>
                	<td align="center">Delight &nbsp;&#10005;&nbsp; Sorrow/Sadness</td>
                    <td align="center">Decrease &nbsp;&#10005;&nbsp; Increase</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Dwarf &nbsp;&#10005;&nbsp; Giant</td>
                	<td align="center">Destruction &nbsp;&#10005;&nbsp; Construction</td>
                    <td align="center">Deep &nbsp;&#10005;&nbsp; Shallow</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Difficult &nbsp;&#10005;&nbsp; Easy</td>
                	<td align="center">Distant &nbsp;&#10005;&nbsp; Near</td>
                    <td align="center"></td>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>E</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Earthly &nbsp;&#10005;&nbsp; Celestial</td>
                	<td align="center">Energetic &nbsp;&#10005;&nbsp; Weak</td>
                    <td align="center">Enemy &nbsp;&#10005;&nbsp; Friend</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Enemity &nbsp;&#10005;&nbsp; Friendship</td>
                	<td align="center">Exterior &nbsp;&#10005;&nbsp; Interior</td>
                    <td align="center">Enough &nbsp;&#10005;&nbsp; Deficient</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">External &nbsp;&#10005;&nbsp; Internal</td>
                	<td align="center">Erase &nbsp;&#10005;&nbsp; Exgrave</td>
                    <td align="center">Early &nbsp;&#10005;&nbsp; Late</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Entrance &nbsp;&#10005;&nbsp; Exit</td>
                	<td align="center"></td>
                    <td align="center"></td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>F</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Fact &nbsp;&#10005;&nbsp; Fiction</td>
                	<td align="center">Failure &nbsp;&#10005;&nbsp; Success</td>
                    <td align="center">Fake &nbsp;&#10005;&nbsp; Genuine</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Fall &nbsp;&#10005;&nbsp; Rise</td>
                	<td align="center">False &nbsp;&#10005;&nbsp; True</td>
                    <td align="center">Famous &nbsp;&#10005;&nbsp; Notorious</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Familiar &nbsp;&#10005;&nbsp; Strange</td>
                	<td align="center">Far &nbsp;&#10005;&nbsp; Near</td>
                    <td align="center">Fast &nbsp;&#10005;&nbsp; Slow</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">First &nbsp;&#10005;&nbsp; Last</td>
                	<td align="center">Feebly &nbsp;&#10005;&nbsp; Strong</td>
                    <td align="center">Female &nbsp;&#10005;&nbsp; Male</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Find &nbsp;&#10005;&nbsp; Lost</td>
                	<td align="center">Finite &nbsp;&#10005;&nbsp; Infinite</td>
                    <td align="center">Flexible &nbsp;&#10005;&nbsp; Rigid</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Float &nbsp;&#10005;&nbsp; Sink</td>
                	<td align="center">Foolish &nbsp;&#10005;&nbsp; Wise</td>
                    <td align="center">Foreign &nbsp;&#10005;&nbsp; Native/Domestic</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Forget &nbsp;&#10005;&nbsp; Remember</td>
                	<td align="center">Forgive &nbsp;&#10005;&nbsp; Punish</td>
                    <td align="center">Freedom &nbsp;&#10005;&nbsp; Slavery</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Frequent &nbsp;&#10005;&nbsp; Rare</td>
                	<td align="center">Friend &nbsp;&#10005;&nbsp; Enemy</td>
                    <td align="center">Friendly &nbsp;&#10005;&nbsp; Hostile</td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>G</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Gain &nbsp;&#10005;&nbsp; Loss</td>
                	<td align="center">Gather &nbsp;&#10005;&nbsp; Scatter</td>
                    <td align="center">General &nbsp;&#10005;&nbsp; Particular</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Genious &nbsp;&#10005;&nbsp; Idiot</td>
                	<td align="center">Give &nbsp;&#10005;&nbsp; Take</td>
                    <td align="center">Glad &nbsp;&#10005;&nbsp; Sorrow</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Grief &nbsp;&#10005;&nbsp; Pleasure</td>
                	<td align="center">Guest &nbsp;&#10005;&nbsp; Host</td>
                    <td align="center"></td>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>H</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Half &nbsp;&#10005;&nbsp; Full</td>
                	<td align="center">Happy &nbsp;&#10005;&nbsp; Sad</td>
                    <td align="center">Hard &nbsp;&#10005;&nbsp; Soft</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Honour &nbsp;&#10005;&nbsp; Dishonour</td>
                	<td align="center">Humble &nbsp;&#10005;&nbsp; Proud</td>
                    <td align="center">Harsh &nbsp;&#10005;&nbsp; Gentel</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Hazard &nbsp;&#10005;&nbsp; Safety</td>
                	<td align="center">Hurt &nbsp;&#10005;&nbsp; Heal</td>
                    <td align="center">Head &nbsp;&#10005;&nbsp; Tail</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Heaven &nbsp;&#10005;&nbsp; Hell</td>
                	<td align="center">Heavy &nbsp;&#10005;&nbsp; Light</td>
                    <td align="center">Hero &nbsp;&#10005;&nbsp; Villian</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Hidden &nbsp;&#10005;&nbsp; Open</td>
                	<td align="center">Hide &nbsp;&#10005;&nbsp; Reveal</td>
                    <td align="center">Homogenious &nbsp;&#10005;&nbsp; Heterogenious</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Huge &nbsp;&#10005;&nbsp; Small</td>
                	<td align="center"></td>
                    <td align="center"></td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>I</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Identical &nbsp;&#10005;&nbsp; Different</td>
                	<td align="center">Idle &nbsp;&#10005;&nbsp; Active</td>
                    <td align="center">Ignorance &nbsp;&#10005;&nbsp; Knowledge</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Ignorant &nbsp;&#10005;&nbsp; Learned</td>
                	<td align="center">Ignore &nbsp;&#10005;&nbsp; Consider</td>
                    <td align="center">Ill &nbsp;&#10005;&nbsp; Well</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Imaginary &nbsp;&#10005;&nbsp; Real</td>
                	<td align="center">Immediately &nbsp;&#10005;&nbsp; Later</td>
                    <td align="center">Import &nbsp;&#10005;&nbsp; Export</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">In &nbsp;&#10005;&nbsp; Out</td>
                	<td align="center">Income &nbsp;&#10005;&nbsp; Expenditure</td>
                    <td align="center">Individual &nbsp;&#10005;&nbsp; General</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Indoor &nbsp;&#10005;&nbsp; Outdoor</td>
                	<td align="center">Inferior &nbsp;&#10005;&nbsp; Superior</td>
                    <td align="center">Inhale &nbsp;&#10005;&nbsp; Exhale</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Interest &nbsp;&#10005;&nbsp; Bore</td>
                	<td align="center">Input &nbsp;&#10005;&nbsp; Output</td>
                    <td align="center"> &nbsp;&#10005;&nbsp; </td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Introduction &nbsp;&#10005;&nbsp; Conclusion</td>
                	<td align="center">Invest &nbsp;&#10005;&nbsp; Withdraw</td>
                    <td align="center">Isolation &nbsp;&#10005;&nbsp; Association</td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>J</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Joy &nbsp;&#10005;&nbsp; Sorrow</td>
                	<td align="center">Join &nbsp;&#10005;&nbsp; Separate</td>
                    <td align="center">Justice &nbsp;&#10005;&nbsp; Partriality</td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>K</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Kind &nbsp;&#10005;&nbsp; Cruel</td>
                	<td align="center">Knowledge &nbsp;&#10005;&nbsp; Ignorance</td>
                    <td align="center">Keep &nbsp;&#10005;&nbsp; Discard</td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>L</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Lie &nbsp;&#10005;&nbsp; Truth</td>
                	<td align="center">Life &nbsp;&#10005;&nbsp; Death</td>
                    <td align="center">Live &nbsp;&#10005;&nbsp; Die</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Living &nbsp;&#10005;&nbsp; Dead</td>
                	<td align="center">Liquid &nbsp;&#10005;&nbsp; Solid</td>
                    <td align="center">Love &nbsp;&#10005;&nbsp; Hate</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Labourious &nbsp;&#10005;&nbsp; Idle</td>
                	<td align="center">Long &nbsp;&#10005;&nbsp; Short</td>
                    <td align="center">Loose &nbsp;&#10005;&nbsp; Tight</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Lord &nbsp;&#10005;&nbsp; Servent</td>
                	<td align="center">Loser &nbsp;&#10005;&nbsp; Winner</td>
                    <td align="center">Loss &nbsp;&#10005;&nbsp; Profit</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Low &nbsp;&#10005;&nbsp; High</td>
                	<td align="center">Luck &nbsp;&#10005;&nbsp; Misfortune</td>
                    <td align="center">Luminous &nbsp;&#10005;&nbsp; Dark</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Large &nbsp;&#10005;&nbsp; Small</td>
                	<td align="center">Late &nbsp;&#10005;&nbsp; Early</td>
                    <td align="center">Latest &nbsp;&#10005;&nbsp; Oldest</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Later &nbsp;&#10005;&nbsp; Earlier</td>
                	<td align="center">Laugh &nbsp;&#10005;&nbsp; Cry</td>
                    <td align="center">Lazy &nbsp;&#10005;&nbsp; Industrious</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Leader &nbsp;&#10005;&nbsp; Follower</td>
                	<td align="center">Lengthen &nbsp;&#10005;&nbsp; Shorten</td>
                    <td align="center">Less &nbsp;&#10005;&nbsp; More</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Liquid &nbsp;&#10005;&nbsp; Solid</td>
                	<td align="center">Little &nbsp;&#10005;&nbsp; Much</td>
                    <td align="center"> &nbsp;&#10005;&nbsp; </td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>M</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Major &nbsp;&#10005;&nbsp; Minor</td>
                	<td align="center">Majority &nbsp;&#10005;&nbsp; Minority</td>
                    <td align="center">Male &nbsp;&#10005;&nbsp; Female</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Mandatory &nbsp;&#10005;&nbsp; Optional</td>
                	<td align="center">Many &nbsp;&#10005;&nbsp; Few</td>
                    <td align="center">Masculine &nbsp;&#10005;&nbsp; Feminine</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Master &nbsp;&#10005;&nbsp; Servent</td>
                	<td align="center">Maximum &nbsp;&#10005;&nbsp; Minimum</td>
                    <td align="center">Melt &nbsp;&#10005;&nbsp; Freeze</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Mental &nbsp;&#10005;&nbsp; Physical</td>
                	<td align="center">Mercy &nbsp;&#10005;&nbsp; Cruelity</td>
                    <td align="center">Minimize &nbsp;&#10005;&nbsp; Maximize</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Mislead &nbsp;&#10005;&nbsp; Guide</td>
                	<td align="center">Mix &nbsp;&#10005;&nbsp; Separate</td>
                    <td align="center">Moist &nbsp;&#10005;&nbsp; Dry</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Monogamy &nbsp;&#10005;&nbsp; Polygamy</td>
                	<td align="center">Monotony &nbsp;&#10005;&nbsp; Variety</td>
                    <td align="center">More &nbsp;&#10005;&nbsp; Less</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Most &nbsp;&#10005;&nbsp; Least</td>
                	<td align="center">Motion &nbsp;&#10005;&nbsp; Stillness</td>
                    <td align="center">Move &nbsp;&#10005;&nbsp; Stop</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Myth &nbsp;&#10005;&nbsp; Reality</td>
                	<td align="center"></td>
                    <td align="center"></td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>N</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Nasty &nbsp;&#10005;&nbsp; Clean</td>
                	<td align="center">Naughty &nbsp;&#10005;&nbsp; Obedient</td>
                    <td align="center">Neat &nbsp;&#10005;&nbsp; Dirty</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Negative &nbsp;&#10005;&nbsp; Positive</td>
                	<td align="center">New &nbsp;&#10005;&nbsp; Old</td>
                    <td align="center">Neutral &nbsp;&#10005;&nbsp; Partial</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Nothing &nbsp;&#10005;&nbsp; Something</td>
                	<td align="center">Now &nbsp;&#10005;&nbsp; Then</td>
                    <td align="center">Nowhere &nbsp;&#10005;&nbsp; Everywhere</td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>P</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Pain &nbsp;&#10005;&nbsp; Pleasure</td>
                	<td align="center">Painfull &nbsp;&#10005;&nbsp; Painless</td>
                    <td align="center">Paradise &nbsp;&#10005;&nbsp; Hell</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Part &nbsp;&#10005;&nbsp; Whole</td>
                	<td align="center">Partly &nbsp;&#10005;&nbsp; Fully</td>
                    <td align="center">Particular &nbsp;&#10005;&nbsp; General</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Partner &nbsp;&#10005;&nbsp; Competitor</td>
                	<td align="center">Pass &nbsp;&#10005;&nbsp; Fail</td>
                    <td align="center">Past &nbsp;&#10005;&nbsp; Future</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Passive &nbsp;&#10005;&nbsp; Active</td>
                	<td align="center">Pay &nbsp;&#10005;&nbsp; Recieve</td>
                    <td align="center">Pause &nbsp;&#10005;&nbsp; Proceed</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Peace &nbsp;&#10005;&nbsp; War</td>
                	<td align="center">Penalty &nbsp;&#10005;&nbsp; Reward</td>
                    <td align="center">Permanent &nbsp;&#10005;&nbsp; Temporary</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Put &nbsp;&#10005;&nbsp; Pick</td>
                	<td align="center">Piece &nbsp;&#10005;&nbsp; Whole</td>
                    <td align="center">Pleasure &nbsp;&#10005;&nbsp; Sorrow</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Plentiful &nbsp;&#10005;&nbsp; Scare</td>
                	<td align="center">Polite &nbsp;&#10005;&nbsp; Rude</td>
                    <td align="center">Portion &nbsp;&#10005;&nbsp; Whole</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Positive &nbsp;&#10005;&nbsp; Negative</td>
                	<td align="center">Practical &nbsp;&#10005;&nbsp; Theory</td>
                    <td align="center">Protest &nbsp;&#10005;&nbsp; Support</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Proud &nbsp;&#10005;&nbsp; Humble</td>
                	<td align="center">Punishment &nbsp;&#10005;&nbsp; Reward</td>
                    <td align="center">Purchase &nbsp;&#10005;&nbsp; Sell</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Purification &nbsp;&#10005;&nbsp; Pollution</td>
                	<td align="center">Prefix &nbsp;&#10005;&nbsp; Postfix</td>
                    <td align="center">Prepaid &nbsp;&#10005;&nbsp; Postpaid</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Presence &nbsp;&#10005;&nbsp; Absence</td>
                	<td align="center">Presently &nbsp;&#10005;&nbsp; Afterwards</td>
                    <td align="center">Pretty &nbsp;&#10005;&nbsp; Ugly</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Previous &nbsp;&#10005;&nbsp; Later</td>
                	<td align="center">Primary &nbsp;&#10005;&nbsp; Secondary</td>
                    <td align="center">Private &nbsp;&#10005;&nbsp; Public</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Produce &nbsp;&#10005;&nbsp; Destroy</td>
                	<td align="center">Productive &nbsp;&#10005;&nbsp; Destructive</td>
                    <td align="center">Profit &nbsp;&#10005;&nbsp; Loss</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Propagate &nbsp;&#10005;&nbsp; Supress</td>
                	<td align="center">Protect &nbsp;&#10005;&nbsp; Expose</td>
                    <td align="center">Push &nbsp;&#10005;&nbsp; Pull</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Punish &nbsp;&#10005;&nbsp; Forgive</td>
                	<td align="center">Promote &nbsp;&#10005;&nbsp; Demote</td>
                    <td align="center"></td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>Q</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Quarrelsome &nbsp;&#10005;&nbsp; Peaceful</td>
                	<td align="center">Question &nbsp;&#10005;&nbsp; Answer</td>
                    <td align="center">Quick &nbsp;&#10005;&nbsp; Slow</td>
                </tr>
                <tr style="background-color: #769FEA;">
                	<td colspan="3"  align="center"><h4>R</h4></td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Radiance &nbsp;&#10005;&nbsp; Darkness</td>
                	<td align="center">Rapid &nbsp;&#10005;&nbsp; Slow</td>
                    <td align="center">Rare &nbsp;&#10005;&nbsp; Common</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Raw &nbsp;&#10005;&nbsp; Ripe</td>
                	<td align="center">Recall &nbsp;&#10005;&nbsp; Forget</td>
                    <td align="center">Recent &nbsp;&#10005;&nbsp; Ancient</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Reckless &nbsp;&#10005;&nbsp; Cautious</td>
                	<td align="center">Recover &nbsp;&#10005;&nbsp; Loss</td>
                    <td align="center">Reduce &nbsp;&#10005;&nbsp; Increase</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Refusal &nbsp;&#10005;&nbsp; Acceptance</td>
                	<td align="center">Refuse &nbsp;&#10005;&nbsp; Support</td>
                    <td align="center">Regardless &nbsp;&#10005;&nbsp; Thoughtful</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Regress &nbsp;&#10005;&nbsp; Progress</td>
                	<td align="center">Rejoice &nbsp;&#10005;&nbsp; Grieve</td>
                    <td align="center">Relative &nbsp;&#10005;&nbsp; Absolute</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Release &nbsp;&#10005;&nbsp; Arrest</td>
                	<td align="center">Religious &nbsp;&#10005;&nbsp; Secular</td>
                    <td align="center">Remember &nbsp;&#10005;&nbsp; Forget</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Remove &nbsp;&#10005;&nbsp; Place</td>
                	<td align="center">Reply &nbsp;&#10005;&nbsp; Question</td>
                    <td align="center">Republic &nbsp;&#10005;&nbsp; Monarchy</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Reward &nbsp;&#10005;&nbsp; Punish</td>
                	<td align="center">Rigid &nbsp;&#10005;&nbsp; Flexible</td>
                    <td align="center">Rise &nbsp;&#10005;&nbsp; Fall</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Rude &nbsp;&#10005;&nbsp; Polite</td>
                	<td align="center">Rumour &nbsp;&#10005;&nbsp; Fact</td>
                    <td align="center">Rural &nbsp;&#10005;&nbsp; Urban</td>
                </tr>
                <tr style="height: 30px;">
                	<td align="center">Ruthless &nbsp;&#10005;&nbsp; Merciful</td>
                	<td align="center"></td>
                    <td align="center"></td>
                </tr>
                </table>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>