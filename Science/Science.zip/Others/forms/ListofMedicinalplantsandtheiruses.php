<?php
$Author="";
$Discription="List which is Discribe about Important Medical Plants And There Uses";
$Keyword="";
$Title="List Of Important Medicinal Plants And There Uses ";
$Contents='ListofMedicinalplantsandtheiruses';
 require "IndexRelated/indexUpper.php";
?>
        		
                                       <!-- Start from Here -->
<article>
<h2 class="h2" align="center">List Of Important Medicinal Plants And There Uses </h2>
 <p ><a class="TutorialPreviousPagea" href="CountyCapitals.php">&lt;&lt;-Previous  Page</a>
                          <a class="TutorialNextPagea"  href="IndiaAtaGlance.php">Next Page-&gt;&gt;</a></p> <br/>
				
					<table  id="tabAddtutorial5" align="center"  width="" cellpadding="" cellspacing="0" border="0" class="table table-hover table-condensed table-bordered " >
 
	           <tr><td colspan="6"><p>NB: (Fam - Family, T - Tree, H - Herb, C - Climber, S- shrub)</p></td></tr>
				<tr style="background-color: #FF9767;">
                <td  height="20" align="left" valign="middle" class="PointTutorialsTitle"><strong>Plant</strong></td>
                <td align="left" valign="top" class="PointTutorialsTitle"><strong>Common name / Maturity period</strong></td>
                <td  align="left" valign="top" class="PointTutorialsTitle"><strong>Botanical Name or Family</strong></td>
				<td   align="left" valign="top" class="PointTutorialsTitle"><strong>Parts Used</strong></td>
				<td  align="left" valign="top" class="PointTutorialsTitle"><strong>Average Price( Rs. / Kg )</strong></td>
				<td  align="left" valign="top" class="PointTutorialsTitle"><strong>Medicinal Use</strong></td>
              </tr>
              <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Emblicaofficinalic.jpg" alt="Emblica officinalis"  height="75" border="0"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Amla ( T )After 4th year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Emblica officinalis<br/>Fam - euphorbiaceac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Fruit</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 15 - 45/kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Vitamin - C, Cough , Diabetes, cold, Laxativ, hyper acidity.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/ashok.jpg" alt="Ashok"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Ashok ( T )10 years onward</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Saraca Asoca<br/>Fam : Caesalpinanceac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Bark Flower</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Dry Bark Rs 125/kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Menstrual Pain, uterine, disorder, Deiabetes.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/ashawagandha.jpg" alt="Aswagandha"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Aswagandha ( H ), One year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Withania  Somnifera<br/>Fam: Solanaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root, Leafs</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 140/ Kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Restorative Tonic, stress, nerves disorder, aphrodiasiac.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Aeglemarmelous.jpg" alt="Aegle marmelous"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Bael / Bilva (T)After 4-5 year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Aegle marmelous<br/>Fam: Rutaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Fruit, Bark</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Fruit - Rs 125 / kg<br/>
				  Pulp - Rs 60 / Kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Diarrrhoea, Dysentry, Constipation.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Phyllanthousamarus.jpg" alt="Phyllanthous amarus"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Bhumi Amla ( H), with in one year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Phyllanthous amarus<br/>Fam : euphorbiaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole Plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 40 / Kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Aenimic, jaundice, Dropsy.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/bacopamonieri.jpg" alt="Bacopa, Monieri"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Brahmi ( H ) Indian penny worth/one year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Bacopa,Monnieri<br/>Fam: Scrophulariaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 20 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Nervous, Memory enhancer,mental disorder.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/chirata.jpg" alt="Chiraita"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Chiraita ( high altituted) with in one year ( H )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Swertia Chiraita<br/>Fam : Gentianaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole Plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 300-350 / per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Skin Desease, Burning, censation, fever.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/gudmar.jpg" alt="Gudmar"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Gudmar / madhunasini, after Four year ( C )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Gymnema Sylvestre<br/>Fam: Asclepiadaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Leaves</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 50 -75 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Diabetes, hydrocil, Asthama.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/guggal.jpg" alt="Guggul"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Guggul ( T)after 8 years</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Commiphora Wightii<br/>Fam: burseraccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Gum rasine</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 80 - 100 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Rheuma tised, arthritis, paralysis, laxative.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/TinosporaCordifoliaFam.jpg" alt="Tinospora CordifoliaFam"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Guluchi / Giloe ( C )With in one year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Tinospora CordifoliaFam</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Stem</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 20 - 25 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Gout, Pile, general debility, fever, Jaundice.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/gloriosa_superba.jpg" alt="Gloriosa superba"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Calihari / panchanguliaGlori Lily Five years</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Gloriosa superba<br/>Fam: Liliaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Seed, tuber</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 60</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Skin Desease, Labour pain, Abortion, General debility.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/kalmegh.jpg" alt="Kalmegh"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Kalmegh/ Bhui neem ( H ) with in one year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Andrographis PaniculataFam : scanthaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole Plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 12 - 20</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Fever, weekness, release of gas.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Peeperlongum.jpg" alt="Peeper longum"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Long peeper / Pippali ( C ) after two to three years</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Peeper longum<br/>Fam : Piperaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Fruit, Root</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 100 - 150 per kg <br/>
				  Root - 150 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Appetizer, enlarged spleen , Bronchities, Cold, antidote.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/makoy.jpg" alt="Makoi"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Makoi ( H )Kakamachi/ With in one year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Solanum nigrum<br/>Fam: Solanaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Fruit/whole plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 40 per kg <br/>
				Seed - 200 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Dropsy, General debility,Diuretic, anti dysenteric.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/coleusbarbatus.jpg" alt="Coleus barbatus"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Pashan Bheda / Pathar Chur ( H )One year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Coleus barbatus<br/>Fam : Lamiaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 40-50 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Kidny stone, Calculus.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/SantalumAlbum.jpg" alt="Santalum Album"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Sandal Wood ( T )Thirty years onward</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Santalum Album<br/>Fam: santalinaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Heart wood , oil</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 350 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Skin disorder, Burning, sensation, Jaundice, Cough.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/sarpagandha.jpg" alt="Sarpa Gandha"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Sarpa Gandha ( H )After 2 year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Ranwolfia Serpentina<br/>Fam: apocynaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root - Rs 60 per kg<br/>
				   Seed - Rs 300 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Hyper tension, insomnia.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/asparagusracemosus.jpg" alt="Asparagus Racemosus"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Satavari ( C )After 2-3 year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Asparagus Racemosus<br/>Family: liliaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Tuber, root</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 20 -50 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Enhance lactation, general weekness, fatigue, cough.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/senna.jpg" alt="Senna"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Senna ( S )With in 1 year</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Casia augustifolia<br/>Fam: Liliaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Dry Tubers</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 500/kg seed <br/>Rs1200/kg dry</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Rheumatism, general debility tonic, aphrodisiac.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/tulsi.jpg" alt="Ocimum sanclum"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Tulsi (perennial) Each 3 months</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Ocimum sanclum<br/>Fam: Lamiaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Leaves/Seed</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Leaves Rs 10/kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Cough, Cold, bronchitis,expectorand.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/vaividang.jpg" alt="Vai Vidanka"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Vai Vidanka ( C ), 2nd year onward</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Embelia Ribes<br/>Fam: Myrsinaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root, Fruit, Leaves</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 40-50 per kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Skin disease, Snake Bite, Helminthiasis.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Menthapiperita.jpg" alt="Mentha pipertia"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Pippermint ( h) Perennial</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Mentha pipertia<br/>Fam:Lamiaccac</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Leaves, Flower, Oil</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Digestive, Pain killer.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Lawsenniaiermis.jpg" alt="Lawsennia iermis"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Henna/Mehdi ( S ) 1/25 years</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Lawsennia iermis<br/>Fam: lytharaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Leaf,Flower, Seed</td>
				<td align="left" valign="top" class="PointTutorialsTitle">L - 50 /kgPowder-Rs75 perkg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Burning, Steam, Anti Imflamatary.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/aloevera.jpg" alt="Aloe Verra"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Gritkumari ( H) 2nd-5th yr</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Aloe Verra<br/>Fam: Liliaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Leaves</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Fresh L- Rs 5 kgJuice 90 Per Kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Laxative, Wound healing, Skin burns & care,Ulcer.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Vincearosea.jpg" alt="Vincea rosea"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Sada Bahar ( H ) Periwinkle/Nyantara</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Vincea rosea/ catharanthusRoseus<br/>Fam :apocyanace</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole Plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">R-Rs50 per kgL- Rs 25S- Rs 10 kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Leaukamia, Hypotensiv, Antispasmodic , Atidot.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Ecliptaalba.jpg" alt="Eclipta alba"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Vringraj ( H )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Eclipta alba<br/>Fam: Compositae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Seed/whole</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Powder-Rs 60/kg</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Anti-inflamatory, Digestive, hairtonic.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Plumbago-Zeylanica.jpg" alt="Plumbago Zeylanica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Swet chitrak <br/>Perennial ( h )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Plumbago Zeylanica<br/>Fam: Plumbaginaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root, Rootbar</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Appetiser, Antibacterial, Aticacer.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Plumbago.jpg" alt="Plumbago Indica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Rakta Chitrak ( H )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Plumbago Indica<br/>Fam : plumbaginaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root, Root bar</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Indyspeipsia, colic, imflammation, cough.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Strychinos-nuxvomica.jpg" alt="Strychinos nuxvomica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Kochila ( T )15 yrs</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Strychinos nuxvomica<br/>Fam: loganiaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Seed</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Nervous, Paralysis, healing wound.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Haritaki.jpg" alt="Terminalia Chebula"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Harida ( T )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Terminalia Chebula<br/>Fam: Combretaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Seed</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs. 80 per K<br/>Powder</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Trifala, wound ulcer, leprosy, inflammation, Cough.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/terminalia-belerica.jpg" alt="Terminalia Bellerica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Bahada (T)</td>
                <td align="left" valign="top" class="PointTutorialsTitle">TerminaliaBellerica<br/>Fam:comretaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Seed, Bark</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Fruit - Rs 20/k<br/>
				  Powder- Rs 100/k</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Cough, Insomnia, Dropsy, Vomiting, Ulcer, Trifala.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Tribulus_terrestris_f_s.jpg" alt="Tribulus Terrestris"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Gokhur ( H ) CrawlingPuncture Vine/1 yr</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Tribulus Terrestris<br/>Fam: Lygophyllaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole Plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Plant-Rs 10/K<br/>
				Fruit -Rs 15/k</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Sweet cooling, Aphrodisiac, appetizer, Digestive, Urinary.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Azardirchataindica.jpg" alt="Azardirchata &ndash; indica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Neem ( T )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Azardirchata - indica<br/>
                  Fam : Mahaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rhizome</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 45/k</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Sdedative, analgesic, epilepsy, hypertensive.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Hemibi-smus-Indicus.jpg" alt="Hemibi smus Indicus"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Anantamool/sariva ( S )Indian Sarap sarilla</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Hemibi smus Indicus<br/>Fam: Asclepiadaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root/ Leaf</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 45/k root <br/>Rs 90/kPowder</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Appetiser, Carminative, aphrodisiac, Astringent.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/acoruscalamus.jpg" alt="Acorus Calamus"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Bach ( H )<br/>Sweet Flag/1 yr</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Acorus Calamus<br/>Fam : araceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rhizome</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Rs 45/K</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Sdedative, analgesic, tpilepsy, hypertensive.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Adhatoda-vesica.jpg" alt="Adhatoda vesica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Vasa ( S )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Adhatoda vesica<br/>Fam : Sacanthaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole Plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Leaf - Rs 25/ k</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Antispasmodic, respiratory, Stimulant.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Mesua.jpg" alt="Mesua Ferrea"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Nageswar ( T ) Nag Champa</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Mesua Ferrea<br/>Fam : Guttiferae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Bark, Leaf, Flower</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Flower - Rs 120/k<br/>
				  Powder Rs 175/k</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Asthma, Skin, Burning, Vomiting, Dysentry, Piles.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/VetiveriaZiziinoides.jpg" alt="Vetiveria Ziziinoides"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Benachar ( S ) Khus/khus</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Vetiveria Ziziinoides<br/>Fam : Toaceae / Graminae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Flower - Rs 120/k<br/>
				  Powder Rs 175/k</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Hyperdisia, Burning, ulcer, Skin, Vomiting.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Centella-asiatica.jpg" alt="Centella asiatica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Mandukparni  ( H )<br/>Indianpennywort</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Centella asiatica<br/>Fam : Umdelliferae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole plant</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Antiinflamatory, Jundice, Diuretic, Diarrhoea.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/MucunaTruriens.jpg" alt="Mucuna Truriens"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Kaincha/CreeperBaidanka</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Mucuna Truriens<br/>Fam : Fabaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Root, Hair, Seed, Leaf</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Nervous, Disorder, Constipation, Nephroaphy, Strangury, Dropsy.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Cinnamomum-Zeylanicum.jpg" alt="Cinnamomum Zeylanicum"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Dalchini<br/>Perenial Shrub</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Cinnamomum Zeylanicum<br/>Fam : Lauraceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Bark, Oil</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Bronchitis, Asthma, Cardiac, Disorder, Fever.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/Holarrhena-antidysenterica.jpg" alt="Holarrhena antidysenterica"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Kurai ( S )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Holorheena antidysentrica<br/>Fam:apocyaceaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Bark, Seed</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Scabies, Antipyretic, Amoibic dysentery.</td>
              </tr>
			  <tr>
                <td  align="left" valign="top" class="PointTutorialsTitle"><img src="images/solanum_xanthocarpum.jpg" alt="Solanum Xanthocarpum"  height="75" border="1"></td>
                 <td align="left" valign="top" class="PointTutorialsTitle">Kantakari / AkrantiPerennial ( H )</td>
                <td align="left" valign="top" class="PointTutorialsTitle">Solanum Xanthocarpum<br/>Fam : Solanaceae</td>
				<td align="left" valign="top" class="PointTutorialsTitle">Whole Plant, Fruit, Seed</td>
				<td align="left" valign="top" class="PointTutorialsTitle">-</td>
				<td  align="left" valign="top" class="PointTutorialsTitle">Diuretic, Antiinflamatory, Appetiser, Stomachic.</td>
              </tr>
		    </table>
			<br/>					
				
  </article>    
 <p ><a class="TutorialPreviousPagea" href="CountyCapitals.php">&lt;&lt;-Previous  Page</a>
                          <a class="TutorialNextPagea"  href="IndiaAtaGlance.php">Next Page-&gt;&gt;</a></p> <br/>
                           <!--Work section End -->
                                <!--------------------------------------->
        	
        	
<?php
  require "IndexRelated/indexLower.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>S
