</div>

	  <!-- Right Column -->
	  <div class="col-sm-2" >

			
 
			<!-- Progress Bars -->
			<div class="panel panel-default">
				
			</div>

			<!-- Carousel --> 
 		
			<div id="side-carousel" class="carousel slide" data-ride="carousel">
			
			  </div>

	  </div><!--/Right Column -->

	</div><!--/container-fluid-->
	
		<?php
    require "../IndexRelated/Footer.php"
    ?>

	
    <!-- jQuery -->
    <script src="../js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
	
	<!-- IE10 viewport bug workaround -->
	<script src="../js/ie10-viewport-bug-workaround.js"></script>
	
	<!-- Placeholder Images -->
	<script src="../js/holder.min.js"></script>
	
</body>

</html>
