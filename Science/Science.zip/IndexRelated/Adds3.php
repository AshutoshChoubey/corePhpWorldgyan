<div style="width: 100%; height: 500px; background-color:;">
                 <!---------------Adds Are Here ----------------------!>   
                    
                  <!---------------Adds Are Here ----------------------!>    
</div> 