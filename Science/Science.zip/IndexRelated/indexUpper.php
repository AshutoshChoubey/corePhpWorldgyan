<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Portal 1</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="../css/custom.css" rel="stylesheet"/>
    <script src="../sweetalert.min.js"></script></script> 
    <link rel="stylesheet" type="text/css" href="../sweetalert.css" />      
   <script language="javascript" src="../JavaScript/IndexJS.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/3.7.0/html5shiv.js"></script>
        <script src="/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!--[endif]
<!--[endif]-->
</head>

<body>

    <!-- Navigation -->
    	<?php
    require "../IndexRelated/Nav.php"
    ?>


<div class="container-fluid">

		<!-- Left Column -->
		<div class="col-sm-2" >

           <!-- Text Panel -->
			<!-- Form --> 
			<div  class="panel panel-primary">
				<div  style="background-color: #FF9767;" class="panel-heading">
					<h3 style="color: #780606;" class="panel-title">
						<span class="glyphicon glyphicon-log-in"></span> 
						Log In
					</h3>
				</div>
				<div   class="panel-body">
					<form>
						<div class="form-group">
							<input type="text"  class="form-control" id="uid" name="uid" placeholder="Username"/>
						</div>
						<div class="form-group">
							<input type="password"  class="form-control" id="pwd" name="pwd" placeholder="Password"/>
						</div>
						<button  style="border-color: Black; " type="submit" class="btn btn-warning">Log In</button>
					</form>
				</div>
			</div>

			<!-- Text Panel -->
			<!-- List-Group Panel -->
			<div class="panel panel-primary">
				<div style="background-color: #FF9767;" class="panel-heading">
					<h1 style="color: #780606;" class="panel-title">Tutorials</h1>
				</div>
				<div class="list-group">
				
        						<a class="list-group-item"  style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Science and Technology')">Science and Technology</a>
        						<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Sprituality')">Sprituality</a>
        						<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('History')">History</a>
        						<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Helth')">Helth</a>
        						<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Geology')">Geology</a>
        						<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Others')">Others</a>
			
				</div>
			</div>

			<!-- List-Group Panel -->
			<div class="panel panel-primary">
				<div style="background-color: #FF9767;" class="panel-heading">
					<h1 style="color: #780606;" class="panel-title">Download Materials</h1>
				</div>
				<div class="list-group">
			         <a class="list-group-item"  style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Science and Technology')">Science and Technology</a>
					<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Sprituality')">Sprituality</a>
					<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('History')">History</a>
					<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Helth')">Helth</a>
					<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Geology')">Geology</a>
					<a class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="javascript:void Category('Others')">Others</a>

			 </div>
			</div>
			<!-- Text Panel -->	
				
		</div><!--/Left Column-->
  
  <div class="col-sm-8">