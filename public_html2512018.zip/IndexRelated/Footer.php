	<footer>

		<div class="footer-blurb">

         <div class="sharetastic"></div>

  <?php

  require "SocialIndex.html";

  ?>

			<div class="container">

				<div class="row">

                    

    				<table style="width: 100%; font-weight:bold;" border="0">

                        <tr>

                            <td ><a style="color: #742A2A;"class="footerlink" href="../../../Mission.php">Mission</a></td>

                            <td ><a style="color: #742A2A;" class="footerlink"  href="../../../Helping.php">Helping</a></td>

                            <td ><a style="color: #742A2A;" class="footerlink"  href="../../../Career.php">Career</a></td>

                        </tr>

                         

                </table>	

    			

                </div>



            </div>

                <table width="100%" border='0'>

            	               <tr>

                            		<td height="50px">

                            			<div style="float: right;font-size: x-small;">

                            				This Site Maintained by <a style="color:#70730F; font-size: xx-small;"  href="http://www.worldgyan.com" ><b> WorldGyan.com</b></a>

                            			</div>                        

                            		</td>

                                </tr>

                                

                </table>

				<!-- /.row -->	

        </div>

        <div class="small-print">

        	<div class="container">

        		<p>Copyright &copy;<?php echo $currentDate=date('Y'); ?> WorldGyan.com  </p>

        	</div>

        </div>

	</footer>