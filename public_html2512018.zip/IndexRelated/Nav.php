<nav class="navbar navbar-inverse navbar-static-top" role="navigation" style="background: linear-gradient(#FFDCC4,#FF9042,#FF8632 );" >

    <div class="container">

            <!-- Logo and responsive toggle -->

            <div class="navbar-header" ><!-- Logo color -->

            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">

                    <span class="sr-only">Toggle navigation</span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

            </button>

                <a class="navbar-brand" href="../../../index.php" style="color: white;"><span style="font-family: French Script MT; font-size:larger; font-weight: bold;">WorldGyan</span></a>

            </div>

            <!-- Navbar links -->

            <div class="collapse navbar-collapse" id="navbar">

                <ul class="nav navbar-nav">

                    <li >

                        <a style="color: white;" href="../../../index.php">Home</a>

                    </li>

                    <li>

                        <a style="color: white;" href="../../../About.php">About</a>

                    </li>

                    <li>

                        <a style="color: white;" href="../../../Contact.php">Contact </a>

                    </li>

					<li  class="dropdown " >

						<a style="color: white; href='' class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Online Materials <span class="caret"></span></a>

						<ul  class="dropdown-menu">

							<li ><a style="color: black;"  href="../../../index.php#DownloadMaterial">Download Material</a></li>

							<li><a style="color: black;"  href="../../../index.php#TutorialLink">Tutorial</a></li>

							<li><a style="color: black;" href="../../../index.php#OthersLink">Others</a></li>

                            <li><a style="color: black;" href="../../../index.php#OthersLinkHindi">Hindi Article</a></li>

						</ul>

					</li>    

                </ul>

				<!-- Search -->

				<form class="navbar-form navbar-left" role="search">

					<div class="form-group">

						<input type="text" class="form-control" required="" placeholder="Search"/>

					</div>

					<button  style="border-color: Black; " type="submit" class="btn btn-warning "><span class="glyphicon glyphicon-search"></span> Search</button>

				</form>



            </div>

            <!-- /.navbar-collapse -->

        </div>

        <!-- /.container -->

    </nav>