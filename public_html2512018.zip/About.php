<?php
$Contents='';
 require "IndexRelated/indexUpper.php";
?>
        		
                                       <!-- Start from Here -->
  
		<h2 align='center'>About</h2>
<p class="h4">   
WorldGyan have Tutorials and Knowledge in all the field .
<li class="PointTutorials">WorldGyan has focus on simplicity.</li><br />
<li class="PointTutorials">WorldGyan has straight-forward learning.</li><br />
<li class="PointTutorials">WorldGyan is free .</li>
</p>
<p><b class="TutorialSubTitle">You can Help-: </b>
If you face any kind of difficulty,spelling mistakes,error or incorrect grammar used in any of the Section please tell us about it. there is no doubt,
Your contribution is extremely valuable and it will certainly help bring further improvement in our service.


</p>
<p><b class="TutorialSubTitle">About Copyright-: </b>

All pages  on this web site are the property of the WorldGyan.

 Pages or other content from WorldGyan may not be redistributed or reproduced in any way, shape, or form without the written permission.
 because we work hard to develop and manage.
</p>
<p><b class="TutorialSubTitle">Note-: </b>
Contents,examples are taken from the various resourse .so that reader can learn easily. If any Query please contact us.<br/>
If you would like to contribute to further development and maintenance of the project please Support us.
for the further development and maintenance we acccepting Advertising.
</p>
                                <!--Work section End -->
                                <!--------------------------------------->
        	
        	
<?php
  require "IndexRelated/indexLower.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>
</html>