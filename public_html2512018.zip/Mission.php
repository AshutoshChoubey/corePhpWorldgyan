<?php
$Contents='';
 require "IndexRelated/indexUpper.php";
?>
        		
                                       <!-- Start from Here -->
  
		<h2 align='center'>Mission</h2>

<p class="h3" style="color: #380808;">
Our mission is to solve all the problem through Knowledge.<br /><br />
People in the world are suffering with the Lack of knowledge ,still on the internet not everything is available .<br /><br />
we try to solve all the problem and Try  to provides knowledge of all the field.<br />
So that people in the world can get knowledge easily in each and every thing just on one click.<br /><br />
</p>
                                <!--Work section End -->
                                <!--------------------------------------->
        	
        	
<?php
  require "IndexRelated/indexLower.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>
</html>