</div>

	  <!-- Right Column -->
	  <div class="col-sm-2" >

    	<div class="table-responsive">
    			
    	       <div class="panel panel-primary" id="OthersLink">
    				<div style="background-color: #FF9767;" class="panel-heading">
    					<h1 style="color: #780606;" class="panel-title"><a href="/Science/Others/forms/index.php">Other Article</a></h1>
    				</div>
    				<div class="list-group">
				    <a  <?php if($Contents=='HealthTips') echo "style=\"background-color: #483131;color:white; \""  ?> class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="/Science/Others/forms/HealthTips.php">Health Tips</a>                    
					<a <?php if($Contents=='HomeRemedies') echo "style=\"background-color: #483131;color:white; \""  ?>class="list-group-item" style="border-bottom: 2px dotted #0A1062;"href="/Science/Others/forms/HomeRemedies.php">Home Remedies</a>
                    <a <?php if($Contents=='GeneralKnowledge') echo "style=\"background-color: #483131;color:white; \""  ?>class="list-group-item" style="border-bottom: 2px dotted #0A1062;"href="/Science/Others/forms/GeneralKnowledge.php">General Knowledge</a> 
                    <a <?php if($Contents=='Fullforms') echo "style=\"background-color: #483131;color:white; \""  ?>class="list-group-item" style="border-bottom: 2px dotted #0A1062;"href="/Science/Others/forms/Fullforms.php">Full forms</a> 
                    <a <?php if($Contents=='Oppositewords') echo "style=\"background-color: #483131;color:white; \""  ?>class="list-group-item" style="border-bottom: 2px dotted #0A1062;"href="/Science/Others/forms/Oppositewords.php">Opposite words</a>
                   	<a <?php if($Contents=='Middleware') echo "style=\"background-color: #483131;color:white; \""  ?>class="list-group-item" style="border-bottom: 2px dotted #0A1062;" href="/Science/Others/forms/PositiveThinking.php"><span style="color: green;">More.....</span></a> 								
    				 								
    				</div>
    			</div>
    		
    	</div>
        <div class="table-responsive">
    			
    	       <div class="panel panel-primary" id="OthersLinkHindi">
    				<div style="background-color: #FF9767;" class="panel-heading">
    					<h1 style="color: #780606;" class="panel-title">Hindi Article</h1>
    				</div>
    				<div class="list-group">
    				    <a <?php if($Contents=='LaravelTutorial') echo "style=\"background-color: #483131;color:white; \""  ?> class="list-group-item"  style="border-bottom: 2px dotted #0A1062;" href="/Science/Hindi/forms/TruthOfTajMahal.php"> ताजमहल</a>
    				</div>
    			</div>
    		
    	</div>		
    				
               
                
				
		  </div>

	  </div><!--/Right Column -->

	</div><!--/container-fluid-->
	
	<?php
    
    require "Footer.php";
    
    ?>

	
    <!-- jQuery -->
    <script src="../../../js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../../../js/bootstrap.min.js"></script>
	
</body>

</html>
