<?php

    $Author="Maneesha Mishra";

    $Description="Interfaces of DBMS";

    $Keyword="Interfaces of DBMS";

    $Title="DBMS Interfaces";

    $Contents='Interfaces';

    require "IndexRelated/indexUpper.php";

?> 

		

        <!------------------------------------------------------ Center Column Start ------------------------------------------------------------>

<article>        

            <p ><a class="TutorialPreviousPagea" href="Language.php">&lt;&lt;-Previous  Page</a>

                          <a class="TutorialNextPagea"  href="DataModel.php">Next Page-&gt;&gt;</a></p> <br/><!-- float: left; color:#430383 ; style for previous page-->  

            <!-- for Text Area it is for code--> 

        <p class="h2" align="center">DBMS Interfaces</p><br />

        <p align="center"><img class="img-responsive" src="images/Interface.PNG"   alt=""/></p>

        

        <ul>

         <li class="PointTutorials">Some Interfaces are combination of both Menu based and Form based.</li><br />

         <li class="PointTutorials">SQL Starplus is standalone interface.</li><br />

         <li class="PointTutorials">SQL Developer is GUI interface.</li><br />

         </ul>

</article>

		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>

<?php

    require "IndexRelated/indexLower.php";

?> 

<script language="javascript" type="text/javascript">

	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

				

	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////

    

</script>