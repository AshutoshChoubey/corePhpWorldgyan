<?php
require_once ($_SERVER['DOCUMENT_ROOT']."/Science/CProgramming/classes/clsWGAddTutorialManager.php");
require_once ($_SERVER['DOCUMENT_ROOT']."/Science/CProgramming/classes/clsWGSubCategoryManager.php");
require_once ($_SERVER['DOCUMENT_ROOT']."/Science/CProgramming/classes/clsWGSubjectManeger.php");
?>