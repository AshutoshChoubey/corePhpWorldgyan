<?php
$Contents='Laravel';
 require "IndexRelated/indexUpper.php";
?>
        		
                                       <!-- Start from Here -->
  
		<h2 align='center'>About</h2>
<p>   
worldgyan have  Tutorials and Knowledge in all the field .we are focusing all the knowledge at one place for easy to learn. 
<li class="PointTutorials">worldgyan has focus on simplicity.</li>
<li class="PointTutorials">worldgyan has straight-forward learning.</li>
<li class="PointTutorials">worldgyan is free .</li>
</p>
<p><b class="TutorialSubTitle">You can Help-: </b>
<p>
If you find an error or any problem youcan cantact  about it.

Use can REPORT ERROR on contact  page.
</p>
<p><b class="TutorialSubTitle">About Copyright-: </b>

All pages  on this web site are the property of the worldgyan.

 Pages or other content from worldgyan may not be redistributed or reproduced in any way, shape, or form without the written permission..
</p>
<p><b class="TutorialSubTitle">Note-: </b>
some content,example are taken from the various resourse .so that reader can learn easily.this website is non profitable.
If you would like to contribute to further development and maintenance of the project please Support us.
for the further development and maintenance we acccepting Advertising.
</p>

                                <!--Work section End -->
                                <!--------------------------------------->
        	
        	
<?php
  require "IndexRelated/indexLower.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>
</html>