<?php
    $Author="Maneesha Mishra";
    $Description="How to stay happy and positive";
    $Keywords="How to stay happy,Positive Thinking,How to treat your child,Some important things to remember in life";
    $Title="Positive Thinking,How to take life in positive way,Never Hopeless,Hope is there";
    $Contents='PositiveThinking';
    require "IndexRelated/indexUpper.php";
?> 

		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
                        <p ><a class="TutorialNextPagea"  href="HealthTips.php">Next Page-&gt;&gt;</a></p><!-- float: left; color:#430383 ; style for previous page-->    
                          <p class="h2" align="center">Think Positive to Stay Happy</p>
		                      <div class="entry">
                              <p class="PointTutorials"><b>Some Important Points to remember</b></p>
                                <ul>
                                	<li class="PointTutorials">Like every coin has two sides life also have two sides, one is happy another is sad. </li><br/>
                                	<li class="PointTutorials">If we want to built our home in flowers then how can we avoid spin.</li><br/>
                                	<li class="PointTutorials">if we love the sun rise then how can we avoid sun set.</li><br/>
                                	<li class="PointTutorials">So love what you have right now who can say the things you have now others don't have!</li><br/>
                                	<li class="PointTutorials">As like a sea hides many things within it our life also have many suspense inside it.</li><br/>
                                	<li class="PointTutorials">From birth to death it contains how many minutes,how many days, how many weeks,how many months and how many years no one can know.</li><br/>
                                	<li class="PointTutorials">Enjoy each and every moments of life without loosing your time.Always do good things for other so that while dieying you will be satisfied of your own life.</li><br/>
                                	<li class="PointTutorials">Whenever life put me at pause or whenever life destroyies my confident there is a small will power inside me which is always alive and that again makes me move and it again builds my confident.</li><br/>
                                	<li class="PointTutorials">Never stop yourself keep moving who knows you may get daimond or you may get some negative things also but if you will stop you may miss the daimond.</li><br/>
                                    <li class="PointTutorials">Never feel bad if no one is talking with you or no one is accepting you, Because everyone can't efford costly things.</li><br/>
                                    <li class="PointTutorials">Our life is like a game when the game begins first level is too easy but when the level increases the difficulties also increases
                                    like that only our life is also very peaceful and colourful during our childhood but as time passes on school is there then higher studies then college
                                    then job then marriage then with lots of responsibility parents.</li><br/>
                                    <li class="PointTutorials">If in any situation of life you don't argue with someone then it doesn't mean that you are defeated it means you value your relation as well as you value your self respect also.</li><br/>
                                    <li class="PointTutorials">If you with start to do any good thing then don't think about people what may think.</li><br/>
                                    <li class="PointTutorials">if you heared anything about yourself wrong then just forget it and move on because action speaks louder then words.</li><br/>
                                    <li class="PointTutorials">Profit is inherited but knowledge is not.</li><br />
                                    <li class="PointTutorials">Brain power is better than muscle power.</li><br />
                                    <li class="PointTutorials">Dress does not give knowledge.</li><br />
                                    <li class="PointTutorials">Some knowledge comes from brain and some from heart.</li><br />
                                    <li class="PointTutorials">Continue your tries like the sea waves untill your goal reach.</li><br />
                                    <li class="PointTutorials">Now a days fear is a good things that doesn't allow you to do wrong things.</li><br />
                                    <li class="PointTutorials">Beauty lies in Action not In Appearence.</li><br />
                                    <li class="PointTutorials">Create an atmoshpere where people act and think positively</li><br />
                                    <li class="PointTutorials">You are the only person in the world who can use his/her ability.</li><br />
                                    <li class="PointTutorials">You can't know what you can do untill you tries.</li><br />
                                    <li class="PointTutorials">In every situation you may face many things .. Politics against you, Mistrust when as compare to other you are trustable,
                                    Don't feel bad one power is there who is watching all these it definietly do justice with you.</li><br />
                                    <li class="PointTutorials">Don't keep your dreams in your eyes, They may fall as tears,Keep them in your heart,So that every heart beat may remindes you about that dream.</li><br />
                                    <li class="PointTutorials">Just like the sunset and sunrise,Gloom and Glories are part of our life, Do not frown,Just take every step with smile</li><br />
                                    <li class="PointTutorials">Even a small dot can stop a big sentence... but few more dots can give continuity. Amazing but True .. So always be positive.</li><br />
                                    <li class="PointTutorials">The sweetness of sweets remains on tongue for some minutes but the sweetness of words soothes our heart for ever.</li><br />
                                    <li class="PointTutorials">The secreate of joy in work iscontained in one word excellence,To know how to do something well is to enjoy it.</li><br />
                                    <li class="PointTutorials">The runner says "It is possible but it is difficult" And the winner says "It is difficult but it is possible" So always think like a winner it will make you feel wonderful.</li><br />
                                    <li class="PointTutorials">Treat everyone with Love even thosew who Hurt you,Not because they are not Nice,SIMPLY because you are Nice.</li><br />
                                    <li class="PointTutorials">Hate the nature of a person don't hate that person.</li><br />
                                    <li class="PointTutorials">Everyone wants Happiness,No one needs pain...But it is not possible to get a Rainbow without a little Rain.</li><br />
                                    <li class="PointTutorials">The tree does not withdraw its shade from the wood cutter,So forgive the one who hurt you,They all realise your worth one day.</li><br />
                                    <li class="PointTutorials">Forget two things in life,the good you do to others and bad done by others.</li><br />
                                    <li class="PointTutorials">If you don't go after what you want,you will never have it,If you do not ask,the answer is always no,If you do not step forward,you are always in the same place.</li><br />
                                    <li class="PointTutorials">Success is like your own shadow,If you try to catch it,You will never succeed..Ignore it and walk in your own way, It will follow you!!!</li><br />
                                    <li class="PointTutorials">Have you ever think what is the difference between Argument and Discussion..?? Argument is to find out "who is right.?" and Duscussion is to find ot "what is right.?"</li><br />
                                    <li class="PointTutorials">We are always trying and if we fail we are always blaming that our luck is not with us but have you ever tried to know what is LUCK ??? In actuall words LUCK means Labour Under Controlled Knowledge</li><br />
                                    <li class="PointTutorials">A good way to change someone's attitude is to change your own because the same sun that melts snow also hardens clay.</li><br />
                                </ul>
                                <br />                                        
                                <p class="PointTutorials"><b>My mom told a story</b>
                                <br /><br/>There are two person one is done 75% bad and 15% good thing in his life time and other is done only 20% bad and 80% good thing in his life time
                                when god ask them what will you live first good result or bad result? The good person answered "i will first live my bad result" and that bad one is very clever
                                so that he said "i will live my bad result first" There after the good result of that bad person is increased and the bad result of the good person is also increased
                                so first pick up the good things first who knows the good thing will always stay with you.</p>
                                <br />
                                <p class="PointTutorials"><b>A small story</b>
                                <br /><br/>A student wants to erase his mistakes in his/her copyso he strikes the lines which is written in pen.
                                When he/she submitted his copy to his/her teacher , Teacher show that strike and call that student and he/she explain to each of his/her student that
                                "if you want hide your mistakes and stike it then it focous on your mistakes and it may get to know everyone. so instead of hiding your mistake just learn from it and move on and never repeat those mistake again."</p>
                                <p align="right"><b><i>Maneesha Mishra</i></b></p>
                            </div>
                            </div>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>