<?php
    $Author="Maneesha Mishra";
    $Description="Some Inspirational Stories";
    $Keywords="Inspirational Stories,Short stories";
    $Title="Inspirational Stories";
    $Contents='InspirationalStories';
    require "IndexRelated/indexUpper.php";
?> 
<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<style>
.display{
   margin-top: 3px;
   margin-left: 3px;
   display: none; 
}   
.sbox{
    /**
 * border-radius: 0px 5px 5px 0px;
 */
    height: 30px;
    width: 100%;
    font-weight: bold; 
    color: black; 
    background-color: #BAD4F2; 
    /**
 * padding-left: 5px; 
 *     text-align: left;
 */
    }
.Diva1{
    background-color: #EFEFEF;
    margin-top: 10px;
    margin-bottom: 10px;
    margin-right: 10px;
    margin-left: 10px;
    padding: 20px;
}
</style>
</head>
<script type="text/javascript">
function show1()
{
    document.getElementById('d1').style.display="block";
}
function show2()
{
    document.getElementById('d1').style.display="none";
}
function show3()
{
    document.getElementById('d2').style.display="block";
}
function show4()
{
    document.getElementById('d2').style.display="none";
}
function show5()
{
    document.getElementById('d3').style.display="block";
}
function show6()
{
    document.getElementById('d3').style.display="none";
}
function show7()
{
    document.getElementById('d4').style.display="block";
}
function show8()
{
    document.getElementById('d4').style.display="none";
}
function show9()
{
    document.getElementById('d5').style.display="block";
}
function show10()
{
    document.getElementById('d5').style.display="none";
}
function show11()
{
    document.getElementById('d6').style.display="block";
}
function show12()
{
    document.getElementById('d6').style.display="none";
}
function show13()
{
    document.getElementById('d7').style.display="block";
}
function show14()
{
    document.getElementById('d7').style.display="none";
}
function show15()
{
    document.getElementById('d8').style.display="block";
}
function show16()
{
    document.getElementById('d8').style.display="none";
}
</script>
<body class="body">
		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
                        <p><a class="TutorialPreviousPagea" href="FunnyJokes.php">&lt;&lt;-Previous  Page</a>
                        <a class="TutorialNextPagea"  href="Quotations.php">Next Page-&gt;&gt;</a></p><!-- float: left; color:#430383 ; style for previous page-->    
                          <p class="h2" align="center">Inspirational Stories</p>
                          <div class="table-responsive " style="border:solid #032d5d 1px;">
                          <table border="0" cellspacing="0" cellpadding="0" class="table table-hover table-condensed table-bordered ">
                          <tr>
                            <td>
                                <input type="button" value="INTELLECTUAL POWER Vs PHYSICAL POWER" class="sbox" onclick="show1()" ondblclick="show2()"/>
                                <div id="d1" class="Diva1 display">
                                    <b>Pandavas return after Vanvas</b><br />&nbsp;&nbsp;&nbsp;
                                    After their return from Vanvas, the pandavas asked Duryodhan for their share of the Kingdom.Duryodhan refused to part with anything without a fight.
                                    But the Pandavas were datermined to get their rightful share and were ready to go for a battle.
                                    <br /><br /><b>Invitation to take part in war</b><br />&nbsp;&nbsp;&nbsp;
                                    This war occured at the largest possible scale and involved all the kingdoms of Bharat (present india). The pandavas and the kauravas 
                                    went to different kings to invite them to join them in the battle.
                                    <br /><br /><b>Invitation to Krishnal</b><br />&nbsp;&nbsp;&nbsp;Arjuna went to invite his friend Krishna, the king of Mathura. He found that Duryodhan himself had alredy reached there 
                                    with invitation for Krishna. But Krishna was asleep. Therefore, while waiting for him to wake up Duryodhan sat close to the head of lord Krishna.
                                    On arriving there, Arjuna also had to wait. He decided to sit down near the feet of krishna.
                                    <br /><br /><b>Duryodhan is worried</b><br />&nbsp;&nbsp;&nbsp;When Krishna woke up his eyes met Arjuna first and he enquired the reasons of his visit. Arjuna explained everything.
                                    <br/>An apprehensive Duryodhan hurried up,"see Krishna,i have come first to invite you.so you must fight from my side." Till now 
                                    Krishna had not seen Duryodhan. He said "i see! Duryodhan,if you have come first,it is my duty to keep your invitation.yet,i saw Arjun first so 
                                    i cannot deny his invitation too.So to one side will go my entire army with all the weapons.To the other side, Only i will go,but i will neither fight 
                                    nor touch any weapon."
                                    <br />Krishna continued,"Since i have seen Arjun first,i give him the chance to choose one of these two alternatives."
                                    <br /><br /><b>Duryodhan wants the big army of Krishna</b><br />&nbsp;&nbsp;&nbsp;Duryodhan was scared . He was afraid that Arjun might take away the big armt of Krishna!
                                    <br />To his surprise ,Arjuna opted for Krishna!! Duryodhan was so happy!! He shouted out "Now it is final,Arjuna cannot change his 
                                    decision hereafter."
                                    <br />Duryodhan returned happily with the mighty army and Arjun with the single unarmed Krishna.
                                    <br /><br /><b>And history is testimonial..</b><br />&nbsp;&nbsp;&nbsp;It was the single personality of Krishna that changed the course of history of the mahavarat war. It is a testimony 
                                    to how intellectual strength convincingly defeats physical strength.
                                    <br /><br /><b><u>MORAL OF THE STORY</u></b>
                                    <ol start="1">
                                    	<li>The intellectual strength is superior to physical strength.</li>
                                    	<li>The mind of a superior kinf is mightier than brute force of legions.</li>
                                    </ol>
                                    <b><u>In studies</u></b>
                                    <ul>
                                    <li>A student who wants to win must develop mental strength by mental excercises.</li>
                                    </ul>
                                </div>
                            </td>
                         </tr>
                         <tr>
                            <td>
                                <input type="button" value="THE CONCENTRATION IS THE HALLMARK OF SUCCESS IN STUDIES" class="sbox" onclick="show3()" ondblclick="show4()"/>
                                <div id="d2" class="Diva1 display">
                                    <b>Dr P Mukerjee</b><br />&nbsp;&nbsp;&nbsp;
                                    It was some time in the year 1972.I happened to work as an engineer in CVRDE, a defence research establishment located at Madras (now chennai).
                                    <br />&nbsp;&nbsp;&nbsp;Dr P Mukerjee was our Director. He was an engineer and was internationally known as a top scientist of india.
                                    <br />&nbsp;&nbsp;&nbsp;Fearing danger to his life from spies of other country ,the government of india had provided him with top security.
                                    However,often Dr.Mukerjee used to be unmindful of the need of security to himself.
                                    <br /><br /><b>Mrs Mukerjee was panicky and rang us up</b><br />&nbsp;&nbsp;&nbsp;
                                    It was about 9.30 PM of a particular holiday.Suddenly we got a frantic call from Mrs.Mukerjee.
                                    <br />&nbsp;&nbsp;&nbsp;"I came at 4 PM to the market with Dada (meaning Dr.Mukerjee)." She spoke with fear in her voice.
                                    "when i returned from the vegetable shop,I found Dada and his car missing.I searched for four long hours,he is not traceable.I am afraid he might have been abducted."
                                    <br /><br /><b>We were worried</b><br />&nbsp;&nbsp;&nbsp;
                                    We were worried and informed the police immediately.Many of us took out our vehicles and went in search of Dr.Mukerjee!
                                    <br />&nbsp;&nbsp;&nbsp;It was 1 AM and Dr.Mukerjee was not traceable. Mrs.Mukerjee was crying in fear.I was with Mrs.Mukerjee,trying to alleviate her fear.
                                    <br /><br /><b>Dr.Mukerjee appears</b><br />&nbsp;&nbsp;&nbsp;
                                    All of a sudden we heard the sound of a car and Mrs.Mukerjee screamed,"it's him.."and ran towards the door.
                                    <br />Yes ,he was there,getting down from the door.He came running to his wife and shouted,"Oh Shashi,I solved a big problem today..." he was speaking out a lot of 
                                    things out of happiness as if he had achieved a great thing...
                                    <br /><br /><b>The old lady hugs her dear old husband</b>
                                    <br />&nbsp;&nbsp;&nbsp;The old Mrs Mukerjee went running and huged him ceying,"Why did you go away without informing me ?"
                                    But Dr.Mukerjee was not able to recall his mistake.He was confused.
                                    <br />&nbsp;&nbsp;&nbsp;Gradually the things became clear. Dr.Mukerjee had gone away to the office from the market unmindful of the presence of his wife.
                                    <br />&nbsp;&nbsp;&nbsp;"Oh hell,how could i do it?"he said when he recalled his mistake and profusely apologised to Mrs.Mukerjee.
                                    <br /><br /><b>The proud Mrs.Mukerjee</b>
                                    <br />&nbsp;&nbsp;&nbsp;I could see the tears in the eyes of Mrs.Mukerjee out of deep appreciation of her husband who was so dedicated to his job and 
                                    worked with so much of concentration,She had a very satisfied smile written on her face.
                                    <br /><br /><b>A great Scientist of the country</b>
                                    <br />&nbsp;&nbsp;&nbsp;Few months later,there was news that Dr.Mukerjee had been awarded the 'Padmashri' by the Government of india 
                                    In recognition of his achievements as a Scientist. However Dr.Mukerjee was unconcerned about it.
                                    <br /><br /><b><u>MORAL OF THE STORY</u></b>
                                    <ul>
                                    	<li>You need to have single-minded concentrate to get expectational success and extraordinary achievements.</li>
                                    </ul>
                                    <b><u>In studies</u></b>
                                    <ul>
                                    <li>While studying a topic,if you are unmindful of everything else,it is called concentration. Full concentration is the handmark of a good student.</li>
                                    </ul>
                                </div>
                            </td>
                         </tr>
                         <tr>
                            <td>
                                <input type="button" value="WHATEVER CANNOT BE CURED MUST BE ENDURED" class="sbox" onclick="show5()" ondblclick="show6()" />
                                <div id="d3" class="Diva1 display">
                                    <b>Garuda loved to eat snakes</b><br />&nbsp;&nbsp;&nbsp;
                                    In hindu mythology,there are two super gods: Lord Vishnu and Lord Shiva. Usually Lord Vishnu moves arround the universe on the back of the great Garuda,an eagle like bird.
                                    Eagles,in general,enjoy eating snakes.So the snakes run for their life the moment they see an eagle.Garuda was very strong and he too enjoyed eating snakes.
                                    <br /><br /><b>The snakes on Lord Shiva</b><br />&nbsp;&nbsp;&nbsp;
                                    Lord Shiva uses snakes as his ornaments and wears them around his neck,hands and legs. Once Lord Vishnu sent a message to Lord Shiva through Garuda.
                                    Garuda arrived at the mountain Kailash,Lord shiva,abode,He found Lord Shiva engrossed in meditation.So he sat down at his feet and waited.
                                    <br /><br /><b>The snakes insult Garuda</b><br />&nbsp;&nbsp;&nbsp;
                                    The snakes on the body of shiva saw garuda and heckled him by hissing at him unnecessarily.They started mocking and making faces at him.They were not afraid of Garuda as they 
                                    knew Lord Shiva would protect them. For a moment Garuda was disturbed and wanted to swallow the snakes.
                                    <br /><br /><b>Garuda controls anger</b><br />&nbsp;&nbsp;&nbsp;
                                    Immediately, he composed himself and thought,"These snakes are taking advantage of the Lors Shiva has for them, If itry to do any harm to these snakes, Lord Shiva will wake up from his meditation 
                                    and immediately kill me before i touch these foolish ones. It is better to tolerate these fools." Thinking so Garuda controlled himself.After this the snakes were further 
                                    encouraged and spat on garuda to humilate him. But Garuda maintained his cool saying ti himself,"i could have digested you all,had you not been on the body of Lord Shiva!" 
                                    <br /><br /><b>Lord Vishnu appreciates Garuda</b>&nbsp;&nbsp;&nbsp;
                                    The snakes became quiet when Lord Shiva got up from meditation.Garuda delivered him the message of Lord Vishnu. On return, Garuda narrated the situation to Lord Vishnu.Lord Vishnu patted Garuda,"Wise ones 
                                    always control this emotion,"Whatever cannot be cured must be endured !" You have done the wisest thing.
                                    <br /><br /><b><u>MORAL OF THE STORY</u></ul></b>&nbsp;&nbsp;&nbsp;
                                    <ul>
                                    	<li>Whatever cannot be cured, must be endured.</li>
                                    </ul>
                                    <b><u>In studies</u></b>&nbsp;&nbsp;&nbsp;
                                    <ul>
                                    	<li>If you do not like a teacher or a classmate or an inappopriate exam date..etc..,better endure them as you cannot avoid the same.</li>
                                    </ul>   
                                </div>
                            </td>
                         </tr>
                         <tr>
                            <td>
                                <input type="button" value="TAKE THIS CARE WHILE HELPING OR RETURNING HELP" class="sbox" onclick="show7()" ondblclick="show8()"/>
                                <div id="d4" class="Diva1 display">
                                    <b>Ram saw a strange fight</b><br />&nbsp;&nbsp;&nbsp;
                                    Once Ram ,a tribesman,was passing through a jungle.He had a brass jug(LOTA) in hand and a bow with arrows hanging from his shoulders.The pot contained milk for his child.
                                    He saw a peculiar and deadly fight between a king cobra and an eagle. The snake was in an advantageous position.It had coiled itself around the beak of the eagle,which was about to die from suffocation.
                                    <br /><br /><b>Ram helps the eagle</b><br />&nbsp;&nbsp;&nbsp;
                                    Rsam ran up to them and loosened up the snake's coil from around the eagle.The eagle somehow survived and was highly grateful to Ram.
                                    <br /><br /><b>The snake tries to take revange on Ram</b><br />&nbsp;&nbsp;&nbsp;
                                    The snake was terribly angry at Ram and wanted to punish him.It spate venom into the pot,containing milk.This was unknown to Ram.The eagle who had seen this,wanted to save Ram for all 
                                    that he had done to save his life.
                                    <br /><br /><b>The Eagle tries to return the help</b><br />&nbsp;&nbsp;&nbsp;
                                    Ignorant of the danger,Ram continuied his journey with the jug full of poisoned milk in his hand.The eagle was looking for a chance.Suddenly he came flying,
                                    Snatched away the pot and threw it into the near by drain.
                                    <br /><br /><b>Ram could not understand eagle's help</b><br />&nbsp;&nbsp;&nbsp;
                                    Ram was annoyed ,"Is this the return i get for saving your life,you stupid eagle?",he said.He took out his bow and arrow quickly and shot at the eagle 
                                    before it could fly away.The eagle died on the spot.
                                    <br /><br /><b><u>MORAL OF THE STORY</u></b><br />&nbsp;&nbsp;&nbsp;
                                    <ul>
                                    	<li>While helping or returning a help,one must ensure that the person to whom it is directed,as 'help' should properly understands it.Your help should never be seen as a harmful action.</li>
                                    </ul>
                                    <b><u>In studies</u></b>&nbsp;&nbsp;&nbsp;
                                    <ul>
                                    	<li>Only those friends who feel that studying helps in life will take an advice on studies.Never say the same to a friend who feels studying is a burden.He will hackle you and take you for an enemy.</li>
                                    </ul>
                                </div>
                            </td>
                         </tr>
                         <tr>
                            <td>
                                <input type="button" value="PUSH...PUSH...AND PUSH" class="sbox" onclick="show9()" ondblclick="show10()"/>
                                <div id="d5" class="Diva1 display">
                                    <b>God rewards Mitra :"PUSH"</b><br />&nbsp;&nbsp;&nbsp;
                                    A man Mitra by name,meditated for months to get God's blessings.God appeared and asked him,"what do you want?"
                                    "please give me something by which i can live very long."Mitra requested.
                                    Pointing to a big rock,the God said,"Push this rock and you will get something which will lengthen your life span."
                                    Mitra pushed the heavy rock by using all his strength.He did so for years together.However,the rock didn't move.
                                    One day a tiger attacked Mitra.He fought with it and killed it as if in a miracle.
                                    <br /><br /><b>Saitan enters - when Mitra gets frustrated</b><br />&nbsp;&nbsp;&nbsp;
                                    Mitra was some what frustrated, as the rock remained unmoved after years of pushing.Saitan was obseving Mitra all along.
                                    Seeing opportunity,Saitan came to Mitra and said,"what did you get by pushing that rock? Nothing! The God has cheated you."
                                    "what is the use of working so hard when there is no outcome? Instead of toiling without rest, enjoy your life advised Saitan.
                                    <br /><br /><b>Mitra stops 'PUSHING'</b><br />&nbsp;&nbsp;&nbsp;
                                    "Yes,thought Mitra and stopped pushing the rock from that day.
                                    One day a wolf attacked Mitra.Surprisingly,Mitra fought against the beast but the beast overpowered him and ate a part of his body before leaving him in agony.
                                    <br /><br /><b>Mitra scolds God</b><br />&nbsp;&nbsp;&nbsp;
                                    God appeared now.Mitra was angry and scolded him."Knowing full well that the rock is immovable,you asked me to push it.
                                    you gave a false hope that i will get something,which will lenthen my life.you are a lier! and here i am not able to fight even a wolf!"
                                    "Your only job was to PUSH," continued God."Rewards i give.How i reward is not for you to ask.Have faith and just keep PUSHING!"
                                    <br /><br /><b>Just keep PUSHING</b><br />&nbsp;&nbsp;&nbsp;
                                    God always (and really always) rewards each and every hard work.However,sometimes we do not understand His way of rewarding and feel that our efforts are in vein.
                                    Thereafter we feel discouraged and frustrated and fall into saitan's hand by withdrawing from PUSHING. That is the bigening of our end.
                                    Even when everything seems meaningless ... just P.U.S.H! When professionally you feel diappointed,...Just P.U.S.H!
                                    When people criticise you for your good works,...Just P.U.S.H! When your action apparently produces no result,...Just P.U.S.H! 
                                    When people just don't understand you,...Just keep PUSHING.
                                    <br /><br /><b><u>MORAL OF THE STORY</u></b>&nbsp;&nbsp;&nbsp;
                                    <ul>
                                    	<li>PUSH PUSH and just PUSH!!! Never get frustrated.you will be rewarded in the loop run.</li>
                                    </ul>
                                    <b><u>In studies</u></b>&nbsp;&nbsp;&nbsp;
                                    <ul>
                                    	<li>PUSH=STUDY.</li>
                                        <li>PUSH PUSH and just PUSH,until the end of the exam that you are going to appear!!! Never get frustrated,You will win.</li>
                                    </ul> 
                                </div>
                            </td>
                         </tr>
                         <tr>
                            <td>
                                <input type="button" value="NEVER AVOID HARD WORK" class="sbox" onclick="show11()" ondblclick="show12()"/>
                                <div id="d6" class="Diva1 display">
                                    <b>The Sugar Merchant</b><br />&nbsp;&nbsp;&nbsp;
                                    There was a sugar merchant.<br />He used to purchase sugar from a particular market in the city, where it was cheap.
                                    <br />He used sell the same to the village shops who sold it at a higher price.
                                    <br /><br /><b>His donkey and the stream</b><br />&nbsp;&nbsp;&nbsp;
                                    He used to transport the sugar on his back of his donkey.<br />Before entering this city market they had to cross a stream,
                                    which had knee-deep water.<br />The merchant and the donkey used to wade through the water.
                                    <br /><br /><b>The donkey slips into water</b><br />&nbsp;&nbsp;&nbsp;
                                    Once,while crossing the stream with a bag of sugar on his back,the feet of the donkey slipped.<br />It fell into the water.
                                    When he got up,he felt lighter because most of the sugar had been dissolved in the water.
                                    <br /><br /><b>The donkey plays the same trick again</b><br />&nbsp;&nbsp;&nbsp;
                                    The merchant returned back and took another bag of sugar again.<br />They again started wading through the stream.
                                    <br />The donkey deliberately fell into the water to reduce the load.<br />Indeed,he saw the load did reduce again!
                                    <br />The donkey rejoiced at the load reduction with braying.
                                    <br /><br /><b>The donkey's master teaches him a lesson</b><br />&nbsp;&nbsp;&nbsp;
                                    The merchant understood the donkey's trick.He went back again to the market.<br />He loaded another big bag on the back of the donkey.
                                    This bag was filled with cotton.<br />While crossing the stream,as usual,the donkey fell into water.<br />As he started to bray happily while getting up from water,
                                    the donkey felt that the load had become doubly heavier than before!
                                    <br /><br /><b>The lesson learnt by the donkey</b><br />&nbsp;&nbsp;&nbsp;
                                    The donkey had to carry this heavy load to different places because of his own stupidity! <br />He said to himself "It never helps to skip hard work."
                                    <br /><br /><b><u>MORAL OF THE STORY</u></b>&nbsp;&nbsp;&nbsp;
                                    <ol start="1">
                                    	<li>Never cut down on hard work.</li>
                                        <li>If you try to reduce hard work,you will end up in frustration.</li>
                                    </ol>
                                    <b><u>In studies</u></b>&nbsp;&nbsp;&nbsp;
                                    <ul>
                                    	<li>Never think that you can cut down on study hours.Less study and better results do not go together.</li>
                                    </ul> 
                                </div>
                            </td>
                         </tr>
                         <tr>
                            <td>
                                <input type="button" value="NEVER IMITATE BLINDLY" class="sbox" onclick="show13()" ondblclick="show14()"/>
                                <div id="d7" class="Diva1 display">
                                    <b>The donkey and the tiny dog</b><br />&nbsp;&nbsp;&nbsp;
                                    A man had a donkey, and a pet puppy.The puppy was tiny and very cute.<br />Everybody in the family was fond of it and liked to fondle.
                                    <br />They took the puppy whenever they went out for dinner and fed him with puppy chow.<br />
                                    whenever the puppy got sick,a vet was called in for immediate treatment.<br />In short,the puppy enjoyed the best luxuries possible.
                                    <br /><br /><b>The donkey grows jealous</b><br />&nbsp;&nbsp;&nbsp;
                                    The donkey was jealous of the pup.He always thought,"I work hard everyday,where as the stupid dog does nothing.
                                    <br />yet he enjoys the best of comfort!! The dog was an idle one."
                                    <br />it was the donkey who had to carry heavy burdens all through the day.
                                    <br />He was given the same food daily oats and hay!
                                    <br /><br /><b>The donkey observes the pup carefully</b><br />&nbsp;&nbsp;&nbsp;
                                    He observed that the pup jumped arround and often played on the master's lap,waged his tail,licked everybody and ran playfully after the kids.
                                    <br />He knew many tricks which was very amusing to the family members.Everybody liked the way the pup barked.
                                    <br />The donkey thought that perhaps thst was the 'secrets' of the dog's popularity. So he decided to do the same and please his master.
                                    <br /><br /><b>The donkey behaves like the dog</b><br />&nbsp;&nbsp;&nbsp;
                                    The next day,the donkey started acting like the dog.He snapped his cord and started jumping freely arround the house.
                                    <br />He rushed inside his master's house.Lifting up his forelegs,he looked at his master with great love and started braying the way the 
                                    puupy barked at the master.
                                    <br />He jumped towards his master who became injured!
                                    <br /><br /><b>The donkey was caught and beaten</b><br />&nbsp;&nbsp;&nbsp;
                                    Everybody in the house got horrified! the servants ran for sticks and rope.
                                    <br />Quickly the donkey was controlled and tied.He was taken to the stable after being beaten thoroughly.
                                    <br />The donkey was baffled,"what went wrong?when the dog behaves like this,he is rewarded where as i am punished!"
                                    <br /><br /><b><u>MORAL OF THE STORY</u></b>&nbsp;&nbsp;&nbsp;
                                    <ol start="1">
                                    	<li>Never imitate blindly of another's behaviour.</li>
                                        <li>Whenever you want to get what the other person is getting now,understand clearly the difference between you and him.
                                        and the situations/surroundings he is in.And act accordingly!</li>
                                    </ol>
                                    <b><u>In studies</u></b>&nbsp;&nbsp;&nbsp;
                                    <ol start="">
                                    	<li>Never try to imitate the behaviour of another colleague/student.</li>
                                        <li>Instead, understand him,his situations,and then take an appropriate decision for yourself.</li>
                                    </ol> 
                                </div>
                            </td>
                         </tr>
                         <tr>
                            <td>
                                <input type="button" value="Everyone Has a Story in Life" class="sbox" onclick="show15()" ondblclick="show16()"/>
                                <div id="d8" class="Diva1 display">
                                    A 24 year old boy seeing out from the train's window shouted...
                                    <br />"Dad, look the trees are going behind!"
                                    <br />Dad smiled and a young couple sitting nearby, looked at the 24 year old's childish behavior with pity, suddenly he again exclaimed...
                                    <br />"Dad, look the clouds are running with us!"
                                    <br />The couple couldn't resist and said to the old man...
                                    <br />"Why don't you take your son to a good doctor?" The old man smiled and said..."I did and we are just coming from the hospital, my son was blind from birth, he just got his eyes today."
                                     <br />Every single person on the planet has a story. Don't judge people before you truly know them. The truth might surprise you.
                                </div>
                            </td>
                         </tr>
                         </table>
                         </div>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
</body>
</html>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>