<?php
    $Author="Maneesha Mishra";
    $Description="General knowledge";
    $Keywords="General knowledge,Indian Nobel Prize Winners,India's Largest";
    $Title="General knowledge";
    $Contents='GeneralKnowledge';
    require "IndexRelated/indexUpper.php";
?> 

		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
                        <p><a class="TutorialPreviousPagea" href="Quotations.php">&lt;&lt;-Previous  Page</a>
                        <a class="TutorialNextPagea"  href="BodyPart.php">Next Page-&gt;&gt;</a></p><!-- float: left; color:#430383 ; style for previous page-->    
		                      
                              <p class="h2" align="center">Indian Nobel Prize Winners</p>
                              <div class="table-responsive " style="border:solid #032d5d 1px;">
                              <pre>
                              Name --- Rabindra Nath Tagore
                              Category --- Literature(Gitanjali)
                              Year --- 1913
                              Date of Birth --- 1861</pre>
                              <pre>
                              Name --- Chandra Sekhar Venkata Raman
                              Category --- Physics
                              Year --- 1930
                              Date of Birth --- 1888</pre>
                              <pre>
                              Name --- Har Gobind Khorana
                              Category --- Medicine
                              Year --- 1968
                              Date of Birth --- 1992</pre>
                              <pre>
                              Name --- Mother Teresa
                              Category --- Peace
                              Year --- 1979
                              Date of Birth --- 1910</pre>
                              <pre>
                              Name --- Subramanyam Chandra Sekhar
                              Category --- Physics
                              Year --- 1983
                              Date of Birth --- 1910</pre>
                              <pre>
                              Name --- Amartyasen
                              Category --- Economic Science
                              Year --- 1998
                              Date of Birth --- 1933</pre>
                              </div>
                              <p class="h2" align="center" class="PointTutorials">India's Largest</p>
                              <ul>
                            	<li class="PointTutorials">India's Largest State --- Rajasthan(Length wise)</li><br/>
                            	<li class="PointTutorials">India's Largest Educated State --- kerala</li><br/>
                            	<li class="PointTutorials">India's Largest Wular Lake --- Kashmir</li><br/>
                            	<li class="PointTutorials">India's Largest Lake (Saline Water) --- Chilka Lake, Orrisa</li><br/>
                            	<li class="PointTutorials">India's Largest Man-Made Lake --- Govind Vallabh Pant Sagar (Rihand Dam)</li><br/>
                            	<li class="PointTutorials">India's Largest Fresh Water Lake --- Kolleru Lake (Andhra Pradesh)</li><br/>
                            	<li class="PointTutorials">India's Largest Populated City --- Mumbai</li><br/>
                            	<li class="PointTutorials">India's Largest State(Area) --- Rajasthan</li><br/>
                            	<li class="PointTutorials">India's Largest State(Population) --- Uttar Pradesh</li><br/>
                            	<li class="PointTutorials">India's Largest Delta --- Sunderbans Delta</li><br/>
                            	<li class="PointTutorials">India's Largest River without Delta --- Narmada and Tapti</li><br/>
                            	<li class="PointTutorials">India's largest area under forest(State wise) --- Madhya Pradesh</li><br/>
                            	<li class="PointTutorials">India's Largest Public Sector Bank --- State Bank of India</li><br/>
                            	<li class="PointTutorials">India's Largest Dome --- Gol Gumbaz at Bijapur</li><br/>
                            	<li class="PointTutorials">India's Largest Zoo --- Zoological Garden at Alipur (Kolkata)</li><br/>
                            	<li class="PointTutorials">India's Largest Museum --- India Museum at Kolkata</li><br/>
                            	<li class="PointTutorials">India's Largest Desert --- Thar (Rajasthan)</li><br/>
                            	<li class="PointTutorials">India's Largest District --- Kutch district</li><br/>
                            	<li class="PointTutorials">India's Largest State (Area) --- Rajasthan</li><br/>
                            	<li class="PointTutorials">India's Largest State (Population) --- Uttar Pradesh</li><br/>
                            	<li class="PointTutorials">India's Largest Cave --- Amarnath (Jammu & Kashmir)</li><br/>
                            	<li class="PointTutorials">India's Largest Cave Temple --- Kailash Temple, Ellora (Maharastra)</li><br/>
                            	<li class="PointTutorials">India's Largest Animal Fair --- Sonepur (Bihar)</li><br/>
                            	<li class="PointTutorials">India's Largest Auditorium --- Sri Shanmukhanand Hall (Mumbai)</li><br/>
                            	<li class="PointTutorials">India's Largest Port --- Mumbai</li><br/>
                            	<li class="PointTutorials">India's Largest Gurudwara --- Golden Temple, Amritsar</li><br/>
                            	<li class="PointTutorials">India's Largest inland salt lake --- Sambhar lake</li><br/>
                            	<li class="PointTutorials">India's Largest Church --- Saint Cathedral (Goa)</li><br/>
                            	<li class="PointTutorials">India's Largest River Island --- Majuli (Brahmaputra River, Asom)</li><br/>
                            	<li class="PointTutorials">India's Largest Planetarium --- Birla Planetarium (Kolkata)</li><br/>
                            	<li class="PointTutorials">India's Largest Rainy Place --- Cherapunji(Meghalaya)</li><br/>
                            	<li class="PointTutorials">India's Largest Hill Station --- Kanchanjangha(k2)</li><br/>
                            </ul>
                            
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>