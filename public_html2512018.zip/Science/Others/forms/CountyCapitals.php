<?php
$Description="List of All the country with there capital alphabetically ordered";
$Keywords="List of Country with capital,Country,Capital";
$Title="Country and There Capitals";
$Contents='CountyCapitals';
 require "IndexRelated/indexUpper.php";
?>
        		
                                       <!-- Start from Here -->
                                       <h2 align='center'>Country with Capitals</h2>
                                        <p ><a class="TutorialPreviousPagea" href="BodyPart.php">&lt;&lt;-Previous  Page</a>
                          <a class="TutorialNextPagea"  href="ImportantMedicinalPlants.php">Next Page-&gt;&gt;</a></p> <br/>
                  <p class="h4">
                  What number of countries are in the world? Sadly, there isn't one right answer. Maps and Country System for the most part are political,
                   so it can fluctuate contingent upon your perspectives and where you originate from 
                   </p>
                   <div class="table-responsive " >
                                 <table  id="tabAddtutorial5" align="center"  width="" cellpadding="" cellspacing="0" border="0" class="table table-hover table-condensed table-bordered " >
                                     <thead style="background-color: #EC9A56;">
                                    	<tr>
                                                <td align="center" >Country</td>
                                                <td align="center" >Capital city</td> 
                                                                                                               
                                        </tr>
                                        </thead>

<tr><td colspan="2" class="Alphabate" align="center">A</td></tr>
<tr class="CountryOdd"><td>Afghanistan</td><td>Kabul</td></tr>
<tr class="CountryEven"><td>Albania</td><td>Tirana</td></tr>
<tr class="CountryOdd"><td>Algeria</td><td>Algiers</td></tr>
<tr class="CountryEven"><td>Andorra</td><td>Andorra la Vella</td></tr>
<tr class="CountryOdd"><td>Angola</td><td>Luanda</td></tr>
<tr class="CountryEven"><td>Antigua and Barbuda</td><td>Saint John's</td></tr>
<tr class="CountryOdd"><td>Argentina</td><td>Buenos Aires</td></tr>
<tr class="CountryEven"><td>Armenia</td><td>Yerevan</td></tr>
<tr class="CountryOdd"><td>Australia</td><td>Canberra</td></tr>
<tr class="CountryEven"><td>Austria</td><td>Vienna</td></tr>
<tr class="CountryOdd"><td>Azerbaijan</td><td>Baku</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">B</td></tr>
<tr class="CountryOdd"><td>Bahamas</td><td>Nassau</td></tr>
<tr class="CountryEven"><td>Bahrain</td><td>Manama</td></tr>
<tr class="CountryOdd"><td>Bangladesh</td><td>Dhaka</td></tr>
<tr class="CountryEven"><td>Barbados</td><td>Bridgetown</td></tr>
<tr class="CountryOdd"><td>Belarus</td><td>Minsk</td></tr>
<tr class="CountryEven"><td>Belgium</td><td>Brussels</td></tr>
<tr class="CountryOdd"><td>Belize</td><td>Belmopan</td></tr>
<tr class="CountryEven"><td>Benin</td><td>Porto-Novo</td></tr>
<tr class="CountryOdd"><td>Bhutan</td><td>Thimphu</td></tr>
<tr class="CountryEven"><td>Bolivia</td><td>Sucre <span>(de jure),</span> <br/>La Paz <span>(seat of government)</span></td></tr>
<tr class="CountryOdd"><td>Bosnia and Herzegovina</td><td>Sarajevo</td></tr>
<tr class="CountryEven"><td>Botswana</td><td>Gaborone</td></tr>
<tr class="CountryOdd"><td>Brazil</td><td>Brasilia</td></tr>
<tr class="CountryEven"><td>Brunei</td><td>Bandar Seri Begawan</td></tr>
<tr class="CountryOdd"><td>Bulgaria</td><td>Sofia</td></tr>
<tr class="CountryEven"><td>Burkina Faso</td><td>Ouagadougou</td></tr>
<tr class="CountryOdd"><td>Burundi</td><td>Bujumbura</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">C</td></tr>
<tr class="CountryOdd"><td>Cabo Verde</td><td>Praia</td></tr>
<tr class="CountryEven"><td>Cambodia</td><td>Phnom Penh</td></tr>
<tr class="CountryOdd"><td>Cameroon</td><td>Yaounde</td></tr>
<tr class="CountryEven"><td>Canada</td><td>Ottawa</td></tr>
<tr class="CountryOdd"><td>Central African Republic</td><td>Bangui</td></tr>
<tr class="CountryEven"><td>Chad</td><td>N'Djamena</td></tr>
<tr class="CountryOdd"><td>Chile</td><td>Santiago</td></tr>
<tr class="CountryEven"><td>China</td><td>Beijing</td></tr>
<tr class="CountryOdd"><td>Colombia</td><td>Bogota</td></tr>
<tr class="CountryEven"><td>Comoros</td><td>Moroni</td></tr>
<tr class="CountryOdd"><td><span class="black">Democratic Republic of the</span> Congo</td><td>Kinshasa</td></tr>
<tr class="CountryEven"><td><span class="black">Republic of the</span> Congo</td><td>Brazzaville</tr>
<tr class="CountryOdd"><td>Costa Rica</td><td>San Jose</td></tr>
<tr class="CountryEven"><td>Cote d'Ivoire</td><td>Yamoussoukro</td></tr>
<tr class="CountryOdd"><td>Croatia</td><td>Zagreb</td></tr>
<tr class="CountryEven"><td>Cuba</td><td>Havana</td></tr>
<tr class="CountryOdd"><td>Cyprus</td><td>Nicosia</td></tr>
<tr class="CountryEven"><td>Czech Republic</td><td>Prague</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">D</td></tr>
<tr class="CountryOdd"><td>Denmark</td><td>Copenhagen</td></tr>
<tr class="CountryEven"><td>Djibouti</td><td>Djibouti (city)</td></tr>
<tr class="CountryOdd"><td>Dominica</td><td>Roseau</td></tr>
<tr class="CountryEven"><td>Dominican Republic</td><td>Santo Domingo</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">E</td></tr>
<tr class="CountryOdd"><td>Ecuador</td><td>Quito</td></tr>
<tr class="CountryEven"><td>Egypt</td><td>Cairo</td></tr>
<tr class="CountryOdd"><td>El Salvador</td><td>San Salvador</td></tr>
<tr class="CountryEven"><td>Equatorial Guinea</td><td>Malabo <span>(de jure),</span> <br/>Oyala <span>(seat of government)</span></td></tr>
<tr class="CountryOdd"><td>Eritrea</td><td>Asmara</td></tr>
<tr class="CountryEven"><td>Estonia</td><td>Tallinn</td></tr>
<tr class="CountryOdd"><td>Ethiopia</td><td>Addis Ababa</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">F</td></tr>
<tr class="CountryOdd"><td>Fiji</td><td>Suva</td></tr>
<tr class="CountryEven"><td>Finland</td><td>Helsinki</td></tr>
<tr class="CountryOdd"><td>France</td><td>Paris</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">G</td></tr>
<tr class="CountryOdd"><td>Gabon</td><td>Libreville</td></tr>
<tr class="CountryEven"><td>Gambia</td><td>Banjul</td></tr>
<tr class="CountryOdd"><td>Georgia</td><td>Tbilisi</td></tr>
<tr class="CountryEven"><td>Germany</td><td>Berlin</td></tr>
<tr class="CountryOdd"><td>Ghana</td><td>Accra</td></tr>
<tr class="CountryEven"><td>Greece</td><td>Athens</td></tr>
<tr class="CountryOdd"><td>Grenada</td><td>Saint George's</td></tr>
<tr class="CountryEven"><td>Guatemala</td><td>Guatemala City</td></tr>
<tr class="CountryOdd"><td>Guinea</td><td>Conakry</td></tr>
<tr class="CountryEven"><td>Guinea-Bissau</td><td>Bissau</td></tr>
<tr class="CountryOdd"><td>Guyana</td><td>Georgetown</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">H</td></tr>
<tr class="CountryOdd"><td>Haiti</td><td>Port-au-Prince</td></tr>
<tr class="CountryEven"><td>Honduras</td><td>Tegucigalpa</td></tr>
<tr class="CountryOdd"><td>Hungary</td><td>Budapest</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">I</td></tr>
<tr class="CountryOdd"><td>Iceland</td><td>Reykjavik</td></tr>
<tr class="CountryEven"><td>India</td><td>New Delhi</td></tr>
<tr class="CountryOdd"><td>Indonesia</td><td>Jakarta</td></tr>
<tr class="CountryEven"><td>Iran</td><td>Tehran</td></tr>
<tr class="CountryOdd"><td>Iraq</td><td>Baghdad</td></tr>
<tr class="CountryEven"><td>Ireland</td><td>Dublin</td></tr>
<tr class="CountryOdd"><td>Israel</td><td>Jerusalem</td></tr>
<tr class="CountryEven"><td>Italy</td><td>Rome</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">J</td></tr>
<tr class="CountryOdd"><td>Jamaica</td><td>Kingston</td></tr>
<tr class="CountryEven"><td>Japan</td><td>Tokyo</td></tr>
<tr class="CountryOdd"><td>Jordan</td><td>Amman</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">K</td></tr>
<tr class="CountryOdd"><td>Kazakhstan</td><td>Astana</td></tr>
<tr class="CountryEven"><td>Kenya</td><td>Nairobi</td></tr>
<tr class="CountryOdd"><td>Kiribati</td><td>Tarawa</td></tr>
<tr class="CountryEven"><td>Kosovo</td><td>Pristina</td></tr>
<tr class="CountryOdd"><td>Kuwait</td><td>Kuwait City</td></tr>
<tr class="CountryEven"><td>Kyrgyzstan</td><td>Bishkek</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">L</td></tr>
<tr class="CountryOdd"><td>Laos</td><td>Vientiane</td></tr>
<tr class="CountryEven"><td>Latvia</td><td>Riga</td></tr>
<tr class="CountryOdd"><td>Lebanon</td><td>Beirut</td></tr>
<tr class="CountryEven"><td>Lesotho</td><td>Maseru</td></tr>
<tr class="CountryOdd"><td>Liberia</td><td>Monrovia</td></tr>
<tr class="CountryEven"><td>Libya</td><td>Tripoli</td></tr>
<tr class="CountryOdd"><td>Liechtenstein</td><td>Vaduz</td></tr>
<tr class="CountryEven"><td>Lithuania</td><td>Vilnius</td></tr>
<tr class="CountryOdd"><td>Luxembourg</td><td>Luxembourg (city)</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">M</td></tr>
<tr class="CountryOdd"><td>Macedonia (FYROM)</td><td>Skopje</td></tr>
<tr class="CountryEven"><td>Madagascar</td><td>Antananarivo</td></tr>
<tr class="CountryOdd"><td>Malawi</td><td>Lilongwe</td></tr>
<tr class="CountryEven"><td>Malaysia</td><td>Kuala Lumpur</td></tr>
<tr class="CountryOdd"><td>Maldives</td><td>Male</td></tr>
<tr class="CountryEven"><td>Mali</td><td>Bamako</td></tr>
<tr class="CountryOdd"><td>Malta</td><td>Valletta</td></tr>
<tr class="CountryEven"><td>Marshall Islands</td><td>Majuro</td></tr>
<tr class="CountryOdd"><td>Mauritania</td><td>Nouakchott</td></tr>
<tr class="CountryEven"><td>Mauritius</td><td>Port Louis</td></tr>
<tr class="CountryOdd"><td>Mexico</td><td>Mexico City</td></tr>
<tr class="CountryEven"><td>Micronesia</td><td>Palikir</td></tr>
<tr class="CountryOdd"><td>Moldova</td><td>Chisinau</td></tr>
<tr class="CountryEven"><td>Monaco</td><td>Monaco</td></tr>
<tr class="CountryOdd"><td>Mongolia</td><td>Ulaanbaatar</td></tr>
<tr class="CountryEven"><td>Montenegro</td><td>Podgorica</td></tr>
<tr class="CountryOdd"><td>Morocco</td><td>Rabat</td></tr>
<tr class="CountryEven"><td>Mozambique</td><td>Maputo</td></tr>
<tr class="CountryOdd"><td>Myanmar (Burma)</td><td>Naypyidaw</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">N</td></tr>
<tr class="CountryOdd"><td>Namibia</td><td>Windhoek</td></tr>
<tr class="CountryEven"><td>Nauru</td><td>Yaren District <span>(de facto)</span></td></tr>
<tr class="CountryOdd"><td>Nepal</td><td>Kathmandu</td></tr>
<tr class="CountryEven"><td>Netherlands</td><td>Amsterdam</td></tr>
<tr class="CountryOdd"><td>New Zealand</td><td>Wellington</td></tr>
<tr class="CountryEven"><td>Nicaragua</td><td>Managua</td></tr>
<tr class="CountryOdd"><td>Niger</td><td>Niamey</td></tr>
<tr class="CountryEven"><td>Nigeria</td><td>Abuja</td></tr>
<tr class="CountryOdd"><td>North Korea</td><td>Pyongyang</td></tr>
<tr class="CountryEven"><td>Norway</td><td>Oslo</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">O</td></tr>
<tr class="CountryOdd"><td>Oman</td><td>Muscat</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">P</td></tr>
<tr class="CountryOdd"><td>Pakistan</td><td>Islamabad</td></tr>
<tr class="CountryEven"><td>Palau</td><td>Ngerulmud</td></tr>
<tr class="CountryOdd"><td>Palestine</td><td>Jerusalem (East)</td></tr>
<tr class="CountryEven"><td>Panama</td><td>Panama City</td></tr>
<tr class="CountryOdd"><td>Papua New Guinea</td><td>Port Moresby</td></tr>
<tr class="CountryEven"><td>Paraguay</td><td>Asuncion</td></tr>
<tr class="CountryOdd"><td>Peru</td><td>Lima</td></tr>
<tr class="CountryEven"><td>Philippines</td><td>Manila</td></tr>
<tr class="CountryOdd"><td>Poland</td><td>Warsaw</td></tr>
<tr class="CountryEven"><td>Portugal</td><td>Lisbon</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">Q</td></tr>
<tr class="CountryOdd"><td>Qatar</td><td>Doha</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">R</td></tr>
<tr class="CountryOdd"><td>Romania</td><td>Bucharest</td></tr>
<tr class="CountryEven"><td>Russia</td><td>Moscow</td></tr>
<tr class="CountryOdd"><td>Rwanda</td><td>Kigali</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">S</td></tr>
<tr class="CountryOdd"><td>Saint Kitts and Nevis</td><td>Basseterre</td></tr>
<tr class="CountryEven"><td>Saint Lucia</td><td>Castries</td></tr>
<tr class="CountryOdd"><td>Saint Vincent and the Grenadines</td><td>Kingstown</td></tr>
<tr class="CountryEven"><td>Samoa</td><td>Apia</td></tr>
<tr class="CountryOdd"><td>San Marino</td><td>San Marino</td></tr>
<tr class="CountryEven"><td>Sao Tome and Principe</td><td>Sao Tome</td></tr>
<tr class="CountryOdd"><td>Saudi Arabia</td><td>Riyadh</td></tr>
<tr class="CountryEven"><td>Senegal</td><td>Dakar</td></tr>
<tr class="CountryOdd"><td>Serbia</td><td>Belgrade</td></tr>
<tr class="CountryEven"><td>Seychelles</td><td>Victoria</td></tr>
<tr class="CountryOdd"><td>Sierra Leone</td><td>Freetown</td></tr>
<tr class="CountryEven"><td>Singapore</td><td>Singapore</td></tr>
<tr class="CountryOdd"><td>Slovakia</td><td>Bratislava</td></tr>
<tr class="CountryEven"><td>Slovenia</td><td>Ljubljana</td></tr>
<tr class="CountryOdd"><td>Solomon Islands</td><td>Honiara</td></tr>
<tr class="CountryEven"><td>Somalia</td><td>Mogadishu</td></tr>
<tr class="CountryOdd"><td>South Africa</td><td>Pretoria <span>(administrative),</span> <br/>Cape Town <span>(legislative),</span> <br/>Bloemfontein <span>(judicial)</span></td></tr>
<tr class="CountryEven"><td>South Korea</td><td>Seoul</td></tr>
<tr class="CountryOdd"><td>South Sudan</td><td>Juba</td></tr>
<tr class="CountryEven"><td>Spain</td><td>Madrid</td></tr>
<tr class="CountryOdd"><td>Sri Lanka</td><td>Sri Jayawardenepura Kotte</td></tr>
<tr class="CountryEven"><td>Sudan</td><td>Khartoum</td></tr>
<tr class="CountryOdd"><td>Suriname</td><td>Paramaribo</td></tr>
<tr class="CountryEven"><td>Swaziland</td><td>Mbabane <span>(administrative),</span> <br/>Lobamba <span>(legislative, royal)</span></td></tr>
<tr class="CountryOdd"><td>Sweden</td><td>Stockholm</td></tr>
<tr class="CountryEven"><td>Switzerland</td><td>Bern</td></tr>
<tr class="CountryOdd"><td>Syria</td><td>Damascus</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">T</td></tr>
<tr class="CountryOdd"><td>Taiwan</td><td>Taipei</td></tr>
<tr class="CountryEven"><td>Tajikistan</td><td>Dushanbe</td></tr>
<tr class="CountryOdd"><td>Tanzania</td><td>Dodoma</td></tr>
<tr class="CountryEven"><td>Thailand</td><td>Bangkok</td></tr>
<tr class="CountryOdd"><td>Timor-Leste</td><td>Dili</td></tr>
<tr class="CountryEven"><td>Togo</td><td>Lome</td></tr>
<tr class="CountryOdd"><td>Tonga</td><td>Nuku?alofa</td></tr>
<tr class="CountryEven"><td>Trinidad and Tobago</td><td>Port of Spain</td></tr>
<tr class="CountryOdd"><td>Tunisia</td><td>Tunis</td></tr>
<tr class="CountryEven"><td>Turkey</td><td>Ankara</td></tr>
<tr class="CountryOdd"><td>Turkmenistan</td><td>Ashgabat</td></tr>
<tr class="CountryEven"><td>Tuvalu</td><td>Funafuti</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">U</td></tr>
<tr class="CountryOdd"><td>Uganda</td><td>Kampala</td></tr>
<tr class="CountryEven"><td>Ukraine</td><td>Kyiv <span>(also known as Kiev)</span></td></tr>
<tr class="CountryOdd"><td>United Arab Emirates</td><td>Abu Dhabi</td></tr>
<tr class="CountryEven"><td>United Kingdom</td><td>London</td></tr>
<tr class="CountryOdd"><td>United States of America</td><td>Washington, D.C.</td></tr>
<tr class="CountryEven"><td>Uruguay</td><td>Montevideo</td></tr>
<tr class="CountryOdd"><td>Uzbekistan</td><td>Tashkent</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">V</td></tr>
<tr class="CountryOdd"><td>Vanuatu</td><td>Port Vila</td></tr>
<tr class="CountryEven"><td>Vatican City (Holy See)</td><td>Vatican City</td></tr>
<tr class="CountryOdd"><td>Venezuela</td><td>Caracas</td></tr>
<tr class="CountryEven"><td>Vietnam</td><td>Hanoi</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">Y</td></tr>
<tr class="CountryOdd"><td>Yemen</td><td>Sana'a</td></tr>
<tr><td colspan="2" class="Alphabate" align="center">Z</td></tr>
<tr class="CountryOdd"><td>Zambia</td><td>Lusaka</td></tr>
<tr class="CountryEven"><td>Zimbabwe</td><td>Harare</td></tr>
</tbody>
</table>

</div>
<p ><a class="TutorialPreviousPagea" href="BodyPart.php">&lt;&lt;-Previous  Page</a>
                          <a class="TutorialNextPagea"  href="ListofMedicinalplantsandtheiruses.php">Next Page-&gt;&gt;</a></p> <br/>
                                <!--Work section End -->
                                <!--------------------------------------->
        	
        	
<?php
  require "IndexRelated/indexLower.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>
</html>