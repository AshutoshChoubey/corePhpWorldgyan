<?php
    $Author="Maneesha Mishra";
    $Description="A true story of inspiration";
    $Keywords="True Story,Inspirational Story";
    $Title="A Heart Touching Story";
    $Contents='Story';
    require "IndexRelated/indexUpper.php";
?> 
<!DOCTYPE html>
<html>
<head>
<style>
article {
    background-color: #F5F5F5;
    width: 100%;
    border: 25px solid green;
    padding: 25px;
    margin: 25px;
}
</style>
</head>
		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
          <p><a class="TutorialPreviousPagea" href="HealthTips.php">&lt;&lt;-Previous  Page</a>
                <a class="TutorialNextPagea"  href="HomeRemedies.php">Next Page-&gt;&gt;</a></p>
                                <article>
                                <h1 class="h2" align="center"><b style="color: #1C7B42;">A True Story</b><br /></h1>
                                <h3 align="center">An invisible battle she fought</h3>
                				<div class="entry">
                                    <p>Crimson hues on the cheekbones, curled eyelashes adorning her delightful eyes and heart-shaped cherry red lips undoubtedly made her one of the prettiest girls of our college. A sober, gentle girl she was, a bright student securing brilliant grades. An embodiment of punctuality and sincerity Maneesha was. Though a single parent, yet Maneesha's mother toiled hard to fullfil the dreams her children see. 
                                    Her father had passed away, when she was just in her fourth grade.
                                     But immense love of a mother helped her daughters get over their father's bereavement, slowly.
                                     By then we had traversed together a journey of four years pursuing engineering under the same branch.
                                     It was on 31st January 2015, we all attended our technical festival. 
                                     In the daytime we learnt from exhibitions and events and in the night we enjoyed to the fullest.</p>
                                     <p>On the first week of February, Maneesha left for a wedding at her relative's place. She had seen off the campus with lots of dreams yet to be accomplished upon her return. After all, last semesters decided our careers ahead.
                                     After an exhilarating marriage procession followed by grand celebrations, Maneesha along with the bride and groom, groom's elder brother and a relative of the bride voyaged on her way back to hostel. Behind the elder brother who drove the four-wheeler, she settled on the back seat and next to her were the newly wed. It was a wintry morning and fog blanketed the atmosphere.
                                     Fondled by the cool breeze my friend drowsed and woke up only after one tormenting month. Things were fine until they had to turn in a curve near the Rambha junction. A heavily loaded truck collided with their car from a side, producing deafening noise. Rest of the onboarders had minor cuts and bruises. But unfortunately, Maneesha's condition was critical. Broken pieces of the glass window had pierced into her delicate face and badly hurt by J hooks of the truck she bled.
                                     Immediately she was driven to the nearest hospital - MKCG, Berhampur from where she was referred to Apollo hospital. In an ambulance with an oxygen mask and a pumping device to pump out excessive blood accumulated in the organs, she was taken to Bhubaneswar. Regardless of forty-eight hours of continuous treatment and supervision, doctors couldn't ensure if she would live again. The fatal crash shattered a small home causing an emotional distraught.
                                     Nevertheless, my bold friend seesawed alone on life's nightmarish seesaw. Being placed in a life supporting system of an ICU, she battled with death.
                                     Prayers poured in from all around.</p>
                                     <p>Some kind of mysterious power from the heaven helped her escape the harrowing ordeal and fortunately after a month she moved her fingers, opened her eyes and regained consciousness. Her entire body racked with pain. She had lost her memory and behaved alike an insane. Might be, the high power antibiotics and injections intended to prepare her body for surgeries ahead, caused this. 
                                        She wept tears of insufferable pain when in intense hunger she was only fed with coconut water for she couldn't open her mouth.
                                        Post a not so successful surgery at the Apollo, she was flown to Shushrusha Hospital, Mumbai. The multiple brain surgeries she then underwent were critical ones. It required presence of several specialists. We are indebted to Dr.Nitin Mokal, a renowned surgeon, for giving her rebirth. Following sessions by a physiotherapist, she slowly learnt to walk and talk.
                                        Though she couldn't afford to be treated in Mumbai for long, yet for her they are angels sent from above.</p>
                                     <p>Although she traversed along life's toughest miles, had a near-death experience, battled for survival boosting pulsations to win over death, she didn't quit. Scars of the mishap couldn't snatch her dreams, multiple fractures couldn't crumple her ambitions. Thus Maneesha is undeniably an exemplar. Fake ones left her side, however she treads on joyously with the real ones alongside her. Vanquishing all hurdles that came her way, today she works as a software engineer in NTCS department of NIST, Berhampur. 
                                        Though a vein reaching an eye is yet to undergo LASIK treatment in the near future, still without any plea she steps out to earn a living. 
                                        All those lethargic souls, doing no good in spite of being physically fit, must take a lesson from my friend's never give-up attitude.</p>
                            <p align="right"><b><i>Bhagyashree Mishra</i></b></p>
                            </div>
                            </article>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
</body>
</html>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>