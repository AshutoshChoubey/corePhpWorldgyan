<?php
    $Author="Maneesha Mishra";
    $Description="Funny Jokes";
    $Keywords="Funny Jokes,Suspense jokes,Bakwas Jokes";
    $Title="Funny Jokes,Funny Quotations";
    $Contents='FunnyJokes';
    require "IndexRelated/indexUpper.php";
?> 

		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
        <p><a class="TutorialPreviousPagea" href="InspirationalThoughts.php">&lt;&lt;-Previous  Page</a>
        <a class="TutorialNextPagea"  href="InspirationalStories.php">Next Page-&gt;&gt;</a></p><!-- float: left; color:#430383 ; style for previous page-->    
          <p class="h2" align="center">Funny Jokes</p>
              <div class="table-responsive " style="border:solid #032d5d 1px;">
              <pre>
              Agar Hum Par gussa aye to ,
              Tajmahal ko phodo,
              charminar ko todo,
              kutabminar ko modo,
              Titanic ko Fevicol se jodo ,
              Magar humari yaad karna na chodo</pre>
              <pre>
              Kitna pyar se muskuralate ho, 
              Asani se apna banalate ho,
              Itna pyar kaise jata lete ho,
              Kisi se sikha hai ya phir ,
              Meri nakal utar lete ho</pre>
              <pre>
              Aap Aap ho Hum Hum Hai, 
              Pyaz nahi kate phir bhi ankhe naam hai,
              Supply kam Hone Se Golgappa me Aalu kam Hai 
              Is se Bakwaas MSG Bhejo ,
              Aagar Aap me Dum Hai...</pre>
              <pre>
              Ek din apki life me ek aisa ladka aega
              Jo apko bahut zyada pyar karega
              aapko pyar se chuega ,
              Aur aapko dher sara kiss karega
              Aur kahega ................. 
              I Love You Mummy</pre>
              <pre>
              Lamha Lamha waqt gujar jaega,
              Lamho mein exam bhi ajaega,
              Abhi bhi waqt hai do line padhlo,
              Warna pass kya tumahara sasur karvayega?</pre>
              <pre>
              Aap humare dil mein base ho,
              Aap humare dil mein base ho,
              Are wo thoda side ho jao,
              Blood circulation wala ,
              pipe main fase ho</pre>
              <pre>
              Zindegi ki raste mein agar ,
              koi khubsurat ladki ko dekhoge, 
              To use I Love You kehena,
              Aagar wo rose ke badle sandel de,
              To use kehena,
              Meri pyari behena,
              Hamesa khus rehna</pre>
              <pre>
              A,B,C,D,E,F,G,H,I .... U,V,W,X,Y,Z
              Dekha ! I & U ke beech jo aya ,
              wo sabko tapka dala</pre>
              <pre>
              Two lovers plan to suicide,
              Boy jumped first,
              Girl closed her eyes,
              Abd returned by saying,
              Love is blind,
              Boy in air opened his parachute,
              Saying love never dies</pre>
              <pre>
              Kya leke aye the,Kya leke jaoge,
              Mujhe phone na karke,
              Kitna paisa kamaoge,
              Kya upar jake,
              Bangla banaoge ..?</pre>
              <pre>
              Your brain is divided into,
              Two parts Left and Right,
              In left nothing is right,
              And ....................
              In right nothing is left,
              Ha ha ha ............</pre>
              <pre>
              Hati ne chiti ko cold drink di,
              Lekin chiti ne nahi pi,
              Pucho kyun...........?
              Kyun ki .............
              Chiti ko dibestise tha.
              Hati ne chiti ko cake diya,
              Lekin chiti ne nahi pi,
              Pucho kyun...........?
              Kyun ki..............
              Chiti ko cake oasand nahi tha
              Ha ha ha ............</pre>
              <pre>
              You are Flower in English,
              In sansrikt "Pushp",
              In arabi "Zuhra",
              In urdu "Gul",
              Don't be so happy because,
              In hindi..............
              You are a "Fool"......
              Ha ha ha..............</pre>
              <pre>
              Mobile ek mandir,
              Sms uska bhagban,
              Sms karne wala pujari,
              Sms padhne wala bhakt,
              Aur sms padhke reply na dene wala,
              Mandir ka bahar ka chapal choor...</pre>
              <pre>
              Agar hum mar jaye,
              To gum na karna,
              Dukh na jatana,
              Mere moth par bhi na ana,
              Sidhe upar chale ana ..:D</pre>
              <pre>
              Funny Sunny
              Postman : I have come 7 miles to deliver you this letter.
              Sunny : why did you came so far, you could have posted it!</pre>
              <pre>
              Patient : Kya me 100 sal tak jiyunga?
              Dr : Kya tum sigret,sharab pite ho?
              Patient : Nahi....
              Dr : Jua khelte ho?
              Patient : Nahi....
              Dr : Phir tum jina kyun chahte ho?</pre>
              <pre>
              Mangu apne father ke samne,
              Cigaratte pi raha tha.....
              Logo ne kaha ke aap apne,
              Father ke samne cigaratte pi rahe ho!
              Mangu ne kaha..............
              Wo mere papa hai,koi petrol pump nahi</pre>
              <pre>
              Changu and Mangu
              Changu : Kal tujhe kitne call kiya,
                       tune kyun nahi uthaya?
              Mangu : Kyun uthau?
                      30rs deke jo gana lagwaya hai,
                      wo kya tera sasur sunega!!..:D</pre>
              <pre>
              Santa and Banta
              Santa blank paper par kiss kar raha tha
              Banta : ye kya hai....!!
              Santa : Meri gf ka love letter hai
              Banta : Magar ye to khali hai
              Santa : Aj kal hum bat nahi katey</pre>
              <pre>
              Teacher : Nisar,tum kab paida huye?
              Nisar : Jawani janeman hasin dilruba
                      mile do dil jawan Nisar hogaya.</pre>
              <pre>
              Dil ko pata tha woh zarur aegi,
              Dil ko pata tha woh zarur aegi,
              Par kabhi socha na tha ki.....
              Surprise me Kambhakht apne....
              Husband bhi saath laegi.... :D</pre>
              </div>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>