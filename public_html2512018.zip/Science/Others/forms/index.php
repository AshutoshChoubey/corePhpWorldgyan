<?php
    $Author="Maneesha Mishra";
    $Description="How to stay happy and positive";
    $Keywords="How to stay happy,Positive Thinking,How to treat your child,Some important things to remember in life";
    $Title="Positive Thinking";
    $Contents='PositiveThinking';
    require "IndexRelated/indexUpper.php";
?> 

		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
                        <p ><a class="TutorialNextPagea"  href="PositiveThinking.php">Next Page-&gt;&gt;</a></p><!-- float: left; color:#430383 ; style for previous page-->    
                          <p class="h2" align="center">Think Positive to Stay Happy</p>
		                      <div class="entry">
                              <p class="PointTutorials"><b>Some Important Points to remember</b></p>
                                <ul>
                                	<li class="PointTutorials">Like every coin has two sides life also have two sides, one is happy another is sad. </li><br/>
                                	<li class="PointTutorials">If we want to built our home in flowers then how can we avoid spin.</li><br/>
                                	<li class="PointTutorials">if we love the sun rise then how can we avoid sun set.</li><br/>
                                	<li class="PointTutorials">So love what you have right now who can say the things you have now others don't have!</li><br/>
                                	<li class="PointTutorials">As like a sea hides many things within it our life also have many suspense inside it.</li><br/>
                                	<li class="PointTutorials">From birth to death it contains how many minutes,how many days, how many weeks,how many months and how many years no one can know.</li><br/>
                                	<li class="PointTutorials">Enjoy each and every moments of life without loosing your time.Always do good things for other so that while dieying you will be satisfied of your own life.</li><br/>
                                	<li class="PointTutorials">Whenever life put me at pause or whenever life destroyies my confident there is a small will power inside me which is always alive and that again makes me move and it again builds my confident.</li><br/>
                                	<li class="PointTutorials">Never stop yourself keep moving who knows you may get daimond or you may get some negative things also but if you will stop you may miss the daimond.</li><br/>
                                    <li class="PointTutorials">Never feel bad if no one is talking with you or no one is accepting you, Because everyone can't efford costly things.</li><br/>
                                    <li class="PointTutorials">Our life is like a game when the game begins first level is too easy but when the level increases the difficulties also increases
                                    like that only our life is also very peaceful and colourful during our childhood but as time passes on school is there then higher studies then college
                                    then job then marriage then with lots of responsibility parents.</li><br/>
                                    <li class="PointTutorials">If in any situation of life you don't argue with someone then it doesn't mean that you are defeated it means you value your relation as well as you value your self respect also.</li><br/>
                                    <li class="PointTutorials">If you with start to do any good thing then don't think about people what may think.</li><br/>
                                    <li class="PointTutorials">if you heared anything about yourself wrong then just forget it and move on because action speaks louder then words.</li><br/>
                                </ul>
                                <br />                                        
                                <p class="PointTutorials"><b>My mom told a story</b>
                                <br /><br/>There are two person one is done 75% bad and 15% good thing in his life time and other is done only 20% bad and 80% good thing in his life time
                                when god ask them what will you live first good result or bad result? The good person answered "i will first live my bad result" and that bad one is very clever
                                so that he said "i will live my bad result first" There after the good result of that bad person is increased and the bad result of the good person is also increased
                                so first pick up the good things first who knows the good thing will always stay with you.</p>
                                <br />
                                <p class="PointTutorials"><b>A small story</b>
                                <br /><br/>A student wants to erase his mistakes in his/her copyso he strikes the lines which is written in pen.
                                When he/she submitted his copy to his/her teacher , Teacher show that strike and call that student and he/she explain to each of his/her student that
                                "if you want hide your mistakes and stike it then it focous on your mistakes and it may get to know everyone. so instead of hiding your mistake just learn from it and move on and never repeat those mistake again."</p>
                                <p align="right"><b><i>Maneesha Mishra</i></b></p>
                            </div>
                            </div>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>