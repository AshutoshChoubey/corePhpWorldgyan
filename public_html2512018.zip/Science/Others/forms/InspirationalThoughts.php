<?php
    $Author="Maneesha Mishra";
    $Description="Inspirational Thoughts";
    $Keywords="Inspirational Thoughts,Thoughts By Chanakya,Thoughts By A.P.J Abdul Kalam,Thoughts";
    $Title="Inspirational Thoughts";
    $Contents='InspirationalThoughts';
    require "IndexRelated/indexUpper.php";
?> 

		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
                        <p><a class="TutorialPreviousPagea" href="Oppositewords.php">&lt;&lt;-Previous  Page</a>
                        <a class="TutorialNextPagea"  href="FunnyJokes.php">Next Page-&gt;&gt;</a></p><!-- float: left; color:#430383 ; style for previous page-->    
                           <div class="entry">
                            <p class="h2" align="center" class="PointTutorials">15 Great Thoughts By Chanakya</p>
                            <ol start="1">
                            	<li class="PointTutorials">Learn from the mistakes of others, you can't live long enough to make them all yourselves.</li><br/>
                            	<li class="PointTutorials">A person should not be too honest. Straight trees are cut first and Honest people are screwed first.</li><br/>
                            	<li class="PointTutorials">Even if a snake is not poisonous, it should pretend to be venomous.</li><br/>
                            	<li class="PointTutorials">There is some self interest behind every friendship. There is no friendship without self interests. This is a bitter truth.</li><br/>
                            	<li class="PointTutorials">Before you start some work always ask yourself three questions 
                                    <ul>
                                    	<li class="PointTutorials">Why am i doing it</li><br/>
                                    	<li class="PointTutorials">What the results might be</li><br/>
                                    	<li class="PointTutorials">Will i be successfull</li><br/>
                                    </ul>Only when you think deeply and find satisfactory answerts to these questions, Go a head.</li><br/>
                            	<li class="PointTutorials">As soon as the fear approaches near, attack and destroy it.</li><br/>
                            	<li class="PointTutorials">The world's biggest power is the youth and beauty if a woman.</li><br/>
                            	<li class="PointTutorials">Once you start a working on something, Don't afraid of failure and don't abandon it. People who work Sincerely are the happiest.</li><br/>
                            	<li class="PointTutorials">The fragrance of flowers spreads only in the direction of the wind, But the goodness of a person spreads in all direction.</li><br/>
                            	<li class="PointTutorials">God is not present in idols your feelings are your god, The soul is your temple.</li><br/>
                            	<li class="PointTutorials">A man is great by deeds, not by birth.</li><br/>
                            	<li class="PointTutorials">Never make friends with people who are above or below you in status such friendships will never give you any happiness.</li><br/>
                            	<li class="PointTutorials">Treat your kid like a darling for the first five years, For the next five years Scold them, By the time they turn sixteen, Treat them like a friend, Your grown up children are your best friends.</li><br/>
                            	<li class="PointTutorials">Books are useful to a stuid person as a mirror is useful to a blind person.</li><br/>
                            	<li class="PointTutorials">Education is the best friend. An educated person is respected every where, Education beats the beauty and the youth.</li><br/>
                            </ol>
                            <p class="h2" align="center" class="PointTutorials">11 Great Thoughts By A.P.J Abdul Kalam</p>
                            <ol start="1">
                            	<li class="PointTutorials">Confidence and Hardwork is the best medecine to kill the disease called failure ,it will make you successful person.</li><br />
                            	<li class="PointTutorials">Speak 5 lines to yourself every morning
                                    <ul>
                                	<li class="PointTutorials">I am the best.</li><br />
                                	<li class="PointTutorials">I can do it.</li><br />
                                	<li class="PointTutorials">God is always with me.</li><br />
                                	<li class="PointTutorials">I am a winner.</li><br />
                                	<li class="PointTutorials">Today is my day.</li><br />
                                </ul></li>
                            	<li class="PointTutorials">All birds find shelter during a rain but Eagle avoids rain by flying above the clouds , Problems are common but attitude makes the difference.</li><br />
                            	<li class="PointTutorials">If you want to shine like a sun First burn like a sun.</li><br />
                            	<li class="PointTutorials">Black colour is some time sentimentally bad but every black board makes the students future Bright.</li><br />
                            	<li class="PointTutorials">End is not the end in fact E.N.D means Effort Never Dies.</li><br />
                            	<li class="PointTutorials">Don't take rest after your first victory because if you fail in second, more lips are wating to say that your first victory was just luck.</li><br />
                            	<li class="PointTutorials">For me there are two types of people the young and the experienced.</li><br />
                            	<li class="PointTutorials">Don't read success stories you will only get a message, Read failure stories you will get some ideas to get success.</li><br />
                            	<li class="PointTutorials">Love your job but don't love your company because you may not know when your company stops loving you.</li><br />
                            	<li class="PointTutorials">Success is when your signature becomes an Autograph.</li><br />
                            </ol>
                            <p class="h2" align="center" class="PointTutorials">Some Inspirational Thoughts by Famous Personality</li><br />
                            <li class="PointTutorials">The great task of education is not meady to collect facts but to know man and make oneself known to man --------- Rabindra Nath Tagore</li><br />
                            <li class="PointTutorials">Education is a continuing process from the minute we are born untill we die --------- Indira Gandhi</li><br />
                            <li class="PointTutorials">There could no failure if ideals remained undemmed and spirits undaunted.Real failure is a desertion of principle and submission to wrong --------- Jawaharlal Neheru</li><br />
                            <li class="PointTutorials">To harbour internal hatred may even be worse then war --------- Mahatma Gandhi</li><br />
                            <li class="PointTutorials">Lifes truest happiness is found in the friendship we make along the way --------- J.P.Kennery</li><br />
                            <li class="PointTutorials">If you want to succeed in the world, you must make your own opportunities as you go --------- John.B.Gough</li><br />
                            <li class="PointTutorials">All times are beautiful for those who maintain joy with in them , but there is no happy or favourable time for those with disconsolate or orphaned souls --------- Rosalia Castro</li><br />
                            <li class="PointTutorials">Nothing can bring you peace but yourself --------- Raiph Waldo Emerson</li><br />
                            <li class="PointTutorials">If a man wants his dreams to come true, he must wake up --------- Anonumous</li><br />
                            <li class="PointTutorials">Blame yourself if you have no branches or leaves, don't accuse the sun of partiality --------- Chinese Proverb</li><br />
                            <li class="PointTutorials">The man who cannot believe in himself cannot believe in anything else --------- Roy.L.Smith</li><br />
                            <li class="PointTutorials">For they conquer who believe they can --------- John Dryden</li><br />
                            <li class="PointTutorials">Fear is the most damnable ,damaging thing to human personality in the whole world --------- William Faulkner</li><br />
                            <li class="PointTutorials">He that fears not the future may enjoy the present --------- Thomas Fuller</li><br />
                            <li class="PointTutorials">The great virtue in life is real courage that knows how to face and live beyond them --------- D.H.Lawrence</li><br />
                            <li class="PointTutorials">Optimism is essential to achievement and it is also the foundation of courage and of true progress --------- Nicholas Murray Butler</li><br />
                            </div>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>