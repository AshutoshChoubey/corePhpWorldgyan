<?php

$Description="Name of the body part of human";

$Keywords="Human body part,Name of the fingure";



$Title="Name Of The Body Part";

$Contents="BodyPart";

 require "IndexRelated/indexUpper.php";

?>

        		

                                       <!-- Start from Here -->

                                        <h2  align="center">Body Part</h2>

                                         <p ><a class="TutorialPreviousPagea" href="GeneralKnowledge.php">&lt;&lt;-Previous  Page</a>
                          <a class="TutorialNextPagea"  href="CountyCapitals.php">Next Page-&gt;&gt;</a></p> <br/><!-- float: left; color:#430383 ; style for previous page-->

        

                                      <div>

                                     <p align="center"> <img class="img-responsive" src="Images/BodyPart.PNG"  alt=""/>

                                     <img class="img-responsive" src="Images/InternalBodyPart.PNG"  alt=""/>

                                     </p><br />



</div>

<br />

<h3 class="h3">

Internal Parts of the Body</h3>

<div>

<ul style="text-align: left;">



<li class="PointTutorials"><b class="PointTutorialsTitle">Throat</b>&nbsp;- Nourishment goes down this to get to your stomach.</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Liver</b>&nbsp;- The organ that cleans your blood.</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Heart</b>&nbsp;- Your heart directs your blood around your body.</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Lungs</b>&nbsp;-when you inhale, the air goes into your lungs. </li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Veins</b>&nbsp;- These transport blood through your body. They are like little tubes.</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Brain</b>&nbsp;-  This is your 'thinking machine' inside your head.</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Stomach</b>&nbsp;- Your nourishment goes here when you swallow it</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Kidneys</b>&nbsp;-Organs that procedure all your body squander</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Skeleton</b>&nbsp;- The majority of the bones in your body. </li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Ribs</b>&nbsp;- These are the bones that protect the organs in your chest.</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Bones</b>&nbsp;- Your skeleton consists of many bones.There are around 206 in your body</li>

<li class="PointTutorials"><b class="PointTutorialsTitle">Skin</b>&nbsp;-It covers nearly the whole body and helps keep every one of the organs and muscles set up.</li>

</ul>

<table cellpadding="0" cellspacing="0" class="tr-caption-container" style="float: right; margin-left: 1em; text-align: right;"><tbody>

<tr><td style="text-align: center;"><img class="img-responsive" src="Images/Finger.PNG"  alt=""/></td><tr><td class="tr-caption" style="text-align: center;">Name of Fingers</td></tr>

</tbody></table>

<div>

<br /></div>

<div>

<h3 class="h3">

Name of Fingers</h3>

<ol style="background-color: white; font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 21px;">

<li class="PointTutorials">hand</li>

<li class="PointTutorials">thumb</li>

<li class="PointTutorials">little finger</li>

<li class="PointTutorials">index finger </li>

<li class="PointTutorials">middle finger</li>

<li class="PointTutorials">ring finger</li>

<li class="PointTutorials">nail</li>

<li class="PointTutorials">knuckle</li>

</ol>

</div>

</div>

 <p ><a class="TutorialPreviousPagea" href="OppositeWords.php">&lt;&lt;-Previous  Page</a>

                          <a class="TutorialNextPagea"  href="CountryCapitals.php">Next Page-&gt;&gt;</a></p> <br/>





                                <!--Work section End -->

                                <!--------------------------------------->

        	

        	

<?php

  require "IndexRelated/indexLower.php";

?>   

<script language="javascript" type="text/javascript">

	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////



    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////

</script>

</html>