</div>

	  <!-- Right Column -->
	 <div class="col-sm-2" >
			<div class="">
				
			</div>

			<div >
				
				
		  </div>

	  </div><!--/Right Column -->

	</div><!--/container-fluid-->
     <?php
    require "../../../IndexRelated/Footer.php"
    ?>
	
    <!-- jQuery -->
    <script src="../../../js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../../../js/bootstrap.min.js"></script>
	
</body>

</html>
