<?php
    $Author="Maneesha Mishra";
    $Description="Benefits of fruits and vegetables and how to treat diseases using it";
    $Keywords="Home Remedies,Best medicine near your eye,Bleeding Gums,weak eye sight,backache,menstrual cramps,heavy bleeding,dry cough,boost your immunity,skin problems";
    $Title="Home Remedies";
    $Contents='HomeRemedies';
    require "IndexRelated/indexUpper.php";
?> 
		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
         <p><a class="TutorialPreviousPagea" href="Story.php">&lt;&lt;-Previous  Page</a>
               <a class="TutorialNextPagea"  href="Fullforms.php">Next Page-&gt;&gt;</a></p>
               <p class="h2" align="center">Home Remedies For Bleeding-Gums</p>
               <p>
                	<li class="PointTutorials">Massage littile bit Honey on your gums, keep it for 10 minutes then wash it if you wash ii with luke warm water then it gives effective results.</li><br/>
                	<li class="PointTutorials">In a half full glass of warm water add half p spoon of salt water in it and gurgle it for few minutes.</li><br/>
                    <li class="PointTutorials">In a half full glass of warm water add any mouth wash in it and gurgle it for few minutes.</li><br/>
                    <li class="PointTutorials">In a half full glass of warm water sqeeze small piece of lemon in it and gurgle it for few minutes.</li><br/>
                    <li class="PointTutorials">Take a p spoon of coconut oid and massage it on your gums and leave it for 15 minutes then wash it in warm water.</li><br/>
                    <li class="PointTutorials">Mixture of salt , mustard oil and turmeric powder also gives good result during bleeding of gums if you massage this mixture in your gums and leave it for 15 minutes and wash it with luke warm water.</li><br/>
                    <li class="PointTutorials">Ginger juice massage is also good for bleeding Gums.</li><br/>
                    <li class="PointTutorials">Massage aloevera juice on your gum for cureness of bleeding gums.</li><br/>
                    <li class="PointTutorials">Only massage of mustard oil for 15 minutes then wash it with warm water also gives good result.</li><br/>
                </p>
                <p class="h2" align="center">Home Remedies For Weak Eye Sight</p>
                <p>
                	<li class="PointTutorials">Eat plentyof food those are rich in Vitamin A(Tomatoes, Papaya, Carrot), Vitamin E(Wheat Gram,Nuts) and Vitamin C(Oranges, Strawberry, Peppers, Broccoli).</li><br/>
                	<li class="PointTutorials">Eat plenty of green leafy vegetables, mangoes, Kiwi, Peas, Corn and Red grapes.</li><br/>
                    <li class="PointTutorials">Small Exercise of eye is also good for relaxation of eye.</li><br/>
                    <li class="PointTutorials">Almond is too god for vision as well as improves memory power.</li><br/>
                    <li class="PointTutorials">Massage your palm and keep it on your eye untill the warm ends.</li><br/>
                </p>  
            	<p class="h2" align="center">Home Remedies For Backache</p>
                <p>
                	<li class="PointTutorials">Ginger tea which can be used in the treatment of back pain. The anti-inflammatory compounds in ginger can give you relief from a backache.</li><br/>
                    <li class="PointTutorials">Ice first, heat later. As a pain reliever, ice works great So put some icein your back.</li><br/>
                    <li class="PointTutorials">Food as well as Excercise is good for cure deseases, So must follow some excercise also.</li><br/>
                </p>
                <p class="h2" align="center">Home Remedies For Menstrual Cramps and Heavy Bleeding</p>
                <p>
                	<li class="PointTutorials">If you have Metrual Cramps during periods then out few ice cubes in a towel and put it on 
                    your lower abdomen for 15 to 20 minutes and relax.</li><br/>
                	<li class="PointTutorials">Mix 1 to 2 teaspoons of raw, unfiltered apple cider vinegar in a glass of water, Drink this solution 3 times a day during the menstrual cycle for best results..</li><br/>
                    <li class="PointTutorials">According to Ayurveda, coriander seeds can help stop heavy menstrual cycles. It can help improve uterine functioning and balance female hormones in the body.
                     Add 1 teaspoon of coriander seeds to 2 cups of water then boil it until it reduces by half, after straining it add little honey, Drink it while it is still warm, 2 or 3 times a day during your monthly cycle.</li><br/>
                    <li class="PointTutorials">A tea prepared by steeping one Cinnamon stick in a cup of boiling water is very effective home remedy for stopping heavy Periods. Alternatively 3 drops of tincture of cinnamon bark can be taken internally, 
                    twice a day to stop Heavy Menstrual Bleeding during periods.</li><br/>
                    <li class="PointTutorials">Take 40 grams of dried Mustard seeds and grind to fine powder. 
                    Take 2 grams of mustard seed powder with milk twice a day before or during Menstrual cycle to arrest excessive bleeding. 
                    This is an effective home remedy for Heavy Periods.</li><br/>
                    <li class="PointTutorials">Food rich in iron content like potatoes, 
                    pumpkin seeds, clams, molasses are helpful and effective treatment for stopping heavy bleeding during Menstruation.</li><br/>
                    <li class="PointTutorials">If bleeding continues for 7 or more days, during each Menstrual cycle, despite the home remedies you try, 
                    consider consulting a Gynecologist.</li><br/>
                </p>
                <p class="h2" align="center">Home Remedies For Dry Cough</p>
                <p>
                	<li class="PointTutorials">Drink a glass of milk with 1/2 teaspoon of turmeric twice daily to clear your throat during Dry Cough.</li><br/>
                	<li class="PointTutorials">A mix of 1/4 teaspoon honey, 1/4 teaspoon mulethi powder and 1/4 teaspoon cinnamon with water had twice daily in the morning and evening works wonders.</li><br/>
                    <li class="PointTutorials">Black Pepper is the simplest home remedy. Mix 1/2 teaspoon of Black Pepper with desi ghee and have it on a full stomach.</li><br/>
                    <li class="PointTutorials">For kids you could give them a mix of 1/2 cup Pomegranate juice, a pinch of Ginger powder along with Pippali Powder.</li><br/>
                </p>
                <p class="h2" align="center">Home Remedies to Boost your Immunity</p>
                <p>
                	<li class="PointTutorials">Garlic is one of the best foods to boost the immune system. It is a natural antibiotic, antiviral, antibacterial and anti-fungal agent, helps to protect the body against a variety of illnesses. 
                    Regular consumption of Garlic helps to control inflammation, rheumatoid arthritis and multiple sclerosis. 
                    It also helps to lower the blood pressure , cholesterol level and lowers the risk of various types of cancer</li><br/>
                	<li class="PointTutorials">One tablespoon of Honey a day is extremely good for the Immune System. 
                    It is a natural Antioxidant, Antibacterial and Antimicrobial agent that helps to protect the body against Viruses, Fungi and Bacteria. 
                    It also improves the digestive system by treating acid reflux. 
                    It helps to soothe a sore throat, regulate blood sugar, and treat coughs and colds.</li><br/>
                    <li class="PointTutorials">Green tea is great for boosting the immunity. It contains Epigallocatechin gallate, a type of Flavonoid that fights Bacteria and Viruses, and Stimulates the Production of Immune Cells. 
                    Green tea is also a rich source of anti-oxidants . 
                    Regular consumption of Green Tea prevents Cardiovascular Diseases, Stroke and Cancer.</li><br/>
                    <li class="PointTutorials">Deficiency of vitamin B6 adversely affects different aspects of immune response such as Lymphocytes Ability to mature and convert into various types of T and B-cells. 
                    Turmeric contains vitamin B6 as well as minerals like potassium, manganese and iron that are important for the functioning of different body systems. 
                    It also contains curcumin, whose Antioxidant action improves the Functioning of the Immune System </li><br/>
                    <li class="PointTutorials">A portion of Oatmeal at breakfast can greatly benefit your immune system. The soluble fiber contained in it can reduce LDL or Bad Cholesterol. 
                    Oats also contain vitamins and minerals such as, Vitamin B1, Iron, Zinc, Copper, Magnesium, Manganese, Phosphorus and Selenium.</li><br/>
                    <li class="PointTutorials">Almonds are a rich source of vitamin E that helps to reduce Oxidative stress and Inflammation. All you need to do is chew a handful of Almonds to keep your immune system running in smoothly.</li><br/>
                </p>
                <p class="h2" align="center">Home Remedies For Skin Problems.</p>
                <p>
                	<li class="PointTutorials">Coconut Water is good for any type of skin problems. So for best result Apply fresh coconut water on the affected area and once dry, wash it thoroughly with room temperature water.</li><br/>
                	<li class="PointTutorials">For moisturising your skin and make it clean Make a mixture of turmeric and chilled yogurt. Apply it on the affected area and wash it off after 30 minutes.</li><br/>
                    <li class="PointTutorials">To remove Black-Heads Take one teaspoon of green tea and add some water to it. Make a fine paste and apply it on the affected area. Gently massage it for 2-3 minutes and then rinse it with luke-warm water.</li><br/>
                    <li class="PointTutorials">To treat Stretch Marks Take a medium-sized potato and cut it into thick slices. Rub a slice gently on the affected area for a few minutes. Allow the juice to dry and once it dries, wash it with lukewarm water.</li><br/>
                    <li class="PointTutorials">To treat Stretch Marks Make a mixture by adding sugar, almond oil and few drops of lemon juice. Gently rub the mixture on the affected area in a circular motion for at least 10 minutes and wash it off with normal temperature water.</li><br/>
                    <li class="PointTutorials">To avoid dryness of Skin Apply some castor oil to the affected area and gently massage in circular motions with your fingertips. Massage for at least 15-20 minutes and cover your skin with thin cotton cloth. Apply some heat to the affected area.</li><br/>
                    <li class="PointTutorials">To avoid White Heads Extract some lemon juice and apply it to the affect area. Use cotton swab to apply it on your face. Let it stay for 10 to 15 minutes and then wash it off with normal temperature water. You can also use it for three times a day for best results.</li><br/>
                    <li class="PointTutorials">To avoid White Heads After washing your face thoroughly, rub garlic or garlic juice on the affected area. Leave it on for at least 15 minutes and then wash it off with lukewarm water.</li><br/>
                    <li class="PointTutorials">If you use Aloevera gel or Aloevera it self on your skin before sleeping then it will give wonderful results and also moisturise your skin.</li><br/>
                </p>    			
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>