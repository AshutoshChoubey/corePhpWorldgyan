<?php
    $Author="Maneesha Mishra";
    $Description="Quotations";
    $Keywords="Quotations,Love Quotes,Inspirational quotes,Spiritual quotes,Friendship quotes,Heart touching quotes,quotes for students,good night messages,good morning messages";
    $Title="Quotations";
    $Contents='Quotations';
    require "IndexRelated/indexUpper.php";
?> 

		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
        <p><a class="TutorialPreviousPagea" href="InspirationalStories.php">&lt;&lt;-Previous  Page</a>
        <a class="TutorialNextPagea"  href="GeneralKnowledge.php">Next Page-&gt;&gt;</a></p><!-- float: left; color:#430383 ; style for previous page-->    
          <p class="h2" align="center">Funny Jokes</p>
              <div class="table-responsive " style="border:solid #032d5d 1px;">
              <pre>
              If Life is a book,
              I will give you library,
              If hug is a SIM ,
              I will give you TalkTime,
              If Love is a Bike ,
              I will give you Petrol,
              If Friendship is Life ,
              I will give you My self.</pre>
              <pre>
              Bade arman se banaya hai
              bahut dur se mangwaya hai
              Roshni se bhi sajaya hai
              Jara khidki kholke dekhiye 
              Apko Good Night Kehene ke liye 
              chand bhijwaya hai.</pre>
              <pre>
              Har subah aap ke paas ujala ho,
              Har koi apko chahne wala ho,
              Waqt gujar jaye unki yado mein,
              Koi apko itna pyar karne wala ho.</pre>
              <pre>
              Man wishes to fly like a bird,
              Sing like cuckoo,
              Dance like a peacock,
              Swim like a fish,
              But man doesn't wish to 
              Live like a man.</pre>
              <pre>
              Love a friend who hurts you,
              But Don't hurt a friend who loves you,
              Sacrifice everything for a friend,
              But don't sacrifice a friend for anything.</pre>
              <pre>
              A star fell down from heaven,
              And landed in my life,
              I touched the star and,
              It become my friend,
              It brightened my life,
              And made me new,
              That star is now reading my msg.</pre>
              <pre>
              F - Few
              R - Relation
              I - In
              E - Earth
              N - Never
              D - Dies</pre>
              <pre>
              Think - Gentely
              Talk - Simply
              Laugh - Loudly
              Work - Hardly
              Love - Sincierly
              Feel - Freely
              Read - Slowly
                  And
              Most Important
              Remember me daily.</pre>
              <pre>
              Every second god remembers you,
              Every minutes god bless you,
              Every hour god protects you,
              Because ,
              Every day Some one prays for you.</pre>
              <pre>
              Lamha Lamha waqt gujar jaega,
              Lamho mein exam bhi ajaega,
              Abhi bhi waqt hai do line padhlo,
              Warna pass kya tumahara sasur karvayega?</pre>
              <pre>
              Bade arman se banaya hai,
              Bahut dur se mangwaya hai,
              Roshni se bhi sajaya hai,
              Jara khidki kholke dekhiye,
              apko good night kehene liye,
              Chand bhijwaya hai.</pre>
              <pre>
              World is a stage,
              Life is a drama,
              Man is a actor,
              God is a director.</pre>
              <pre>
              Life is a song sing it,
              Life is a game play it,
              Life is a challenge meet it,
              Life is a dream realize it,
              Life is a sacrifice offer it,
              Life is a love enjoy it.</pre>
              <pre>
              Imagine a running race between love 
              And friendship...
              Who will win ...???
              Answer is none.
              Because friendship always compromises ,
              And love always sacrifices.</pre>
              <pre>
              Moon ne band ki lighting,
              Sun ne suru ki shining,
              Murgi ne di hai warning,
              Ki ho gai hai morning,
              To hum bhi apko wish karte hai good morning.</pre>
              <pre>
              Barish ko sirf rona ata hai hasana nahi,
              Suraj ko sirf jalana ata hai bujhana nahi,
              Aur mujhe sirf aap ko yaad karna ata hai ,
              Bhulana nahi.</pre>
              <pre>
              Shyam rangeen subah sinduri ho,
              Har tamana apki puri ho,
              Khuda aap par yun meherban ho ki,
              Aap ko kamyabi dilana uski majburi ho.</pre>
              <pre>
              1+1=2 eyes looking at you,
              3+2=5 sense missing you,
              4+3=7 days thinking of you,
              5+7=12 months dreaming about you,
              99+1=100 years need a friend like you.</pre>
              <pre>
              No one is born happy!
              But all of us are born with,
              The ability to create happiness,
              So today make others happy,
              Flash your sweetest smile.</pre>
              <pre>
              Zindegi ki asli udan abhi baki hai,
              Irado ka imtehan abhi baku hai,
              Abhi to napi hai muthi bhar Zameen,
              Aage sara asmaan baki hai.</pre>
              <pre>
              Whenever you have a dream,
              Never let it go ,Because,
              Dreams are the tiny seeds,
              From which a beautiful tomorrow acn grow.</pre>
              <pre>
              Success is like a train,
              It has several coaches,
              Like Hardwork,Focous,
              Luck,Attitude,Vision,
              But leading those is,
              An engine of CONFIDENCE.</pre>
              <pre>
              God hears more than you say,
              He answers more than you ask,
              He gives more than you desire,
              All he needs is your smile,
              So in any situation keep smiling.</pre>
              <pre>
              G - Go to bed
              O - Off bed light
              O - Out of Tension
              D - Dreams some
              N - Nice sleep
              I - Ignore walking
              G - Get up early
              H - Have a
              T - Tight sleep</pre>
              <pre>
              Eyes are two but vision is one,
              Ears are two but hearing sounds is one,
              Legs are two but walking is one,
              Similarly weare two but ,
              Our friendship is one.</pre>
              <pre>
              A loving memory of your smiling face,
              A friend like you can never replace,
              Deep in my heart you will always stay,
              Freshly remembered everyday.</pre>
              <pre>
              Man asked a fallen Rose,
              "Don't you get hurt,
              when you are plucked?"
              Rose replied "No!,
              I forget my pain,
              Thinking that i am,
              The reason for someone's Smile.</pre>
              <pre>
              Bhejkar sms dil se yaad kiya,
              Fir na kehna humne na yaad kiya,
              Aab na koi sikwa na koi bahana hoga,
              Is khubsurat sms ki kasam ,
              Aapko muskurana hoga.</pre>
              <pre>
              In world 6 things are God's gift,
              Mom's love,
              Dad's advice,
              Brother's care,
              Sister's fight,
              Kisi ka pyar,
              And apni dosti yaar.</pre>
              <pre>
              Friendship never speaks values,
              It never demands proof.........
              It never has a happy ending too,
              Simply because it never ends,
              When friends are true.........</pre>
              <pre>
              Har kadam par imtehan leti hai zindegi,
              Har waqt naye sadme deti hai zindegi,
              hum zindegi se sikwa bhi kaise kare..
              Aap jaise apne bhi to deti zindegi...</pre>
              <pre>
              Have you ever thought,
              What is LUCK ....?????
              L - Labour
              U - Under
              C - Controlled
              K - Knowledge</pre>
              <pre>
              Tu dur hai aur paas bhi hai,
              Teri kami ka ehsas bhi hai,
              Ristein to kayi hain jahan mein,
              Par tu pyara bhi hai,
              Aur khas bhi hai.</pre>
              <pre>
              Pahunch hai humari chand tak,
              yeh tare bhi salaam kiya karte hai,
              yeh aasma bhi jhuk jate hai ,
              Jab hum aapko yaad karte hai.</pre>
              <pre>
              Hasi ko "Inbox",
              Ansu ko "Outbox",
              Guse jo "Delete",
              Muskan ko "Sent",
              Dil ko karo "Vibration",
              Fir dekho ..............
              Zindegi ki ringtone...
              Kitni pyari bajti hai.</pre>
              <pre>
              This is a CHOCOLATE message,
              For a DAIRY-MILK person,
              From a 5-STAR friend,
              For a MELODY reason,
              At a MUNCH day,
              In a PERK mood,
              To say Good Morning.</pre>
              <pre>
              Raat ko chupke se ati hai ek pari,
              Kuch khusiyo ke sapne lati hai pari,
              Kehti hai khwabo ke aghosh me kho jao,
              Bhul ke sare gum chupke se so jao.</pre>
              <pre>
              Apni dosti colgate jaisi nahi,
              12 ghante wali..............
              Allout Jaisi bhi nahi,
              45 rato wali................
              Apni dosti to LIC jaisi hai,
              Zindegi ke sath bhi .......
              Zindegi ke bad bhi ........</pre>
              <pre>
              I wish moon always be full and bright,
              You always will be cool and right,
              Whenever you go to switch off the light,
              Remember that i am wishing you......
              Good Night.........................</pre>
              </div>
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>