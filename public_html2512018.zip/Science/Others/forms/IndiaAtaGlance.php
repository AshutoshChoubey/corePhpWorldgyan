<?php
$Description="Detail about India with farces,Climate of India,Largest In India,States and their Capitals ,Constitution and Polity,Brief History of Indian Neavy,army and Airforce etc..";
$Keywords="Detail about India, Indian Army,first in India happenings ,Fastivals in india,Largest In India,States and their Capitals,Solar and Lunar positions in india,Brief History of Indian Neavy,Climate of India ,Indial Neavy,Indian Army,Detail about Indian Army,everything about india,Constitution of india,General Knowledge,";
$Title="About India";
$Contents="IndiaAtaGlance";
 require "IndexRelated/indexUpper.php";
?>

 <div class="table-responsive " >
  <p ><a class="TutorialPreviousPagea" href="ImportantMedicinalPlants.php">&lt;&lt;-Previous  Page</a>
                          <a class="TutorialNextPagea"  href="ListofMedicinalplantsandtheiruses.php">Next Page-&gt;&gt;</a></p> <br/>
                                 <table  id="tabAddtutorial5" align="center"  width="" cellpadding="" cellspacing="0" border="0" class="table table-hover table-condensed table-bordered " >
                                     <thead style="background-color: #EC9A56;">
                                    	<td colspan="2" align="center" class="h4">Details About India</td>
                                        </thead>

<tr>
 <td class="TableTdPlant">Capital </td>  <td class="TableTdPlant">New Delhi </td>
</tr>
<tr>
 <td class="TableTdPlant">States</td>  <td class="TableTdPlant">29 </td>
</tr>
<tr>
 <td class="TableTdPlant">Union Teritory</td>  <td class="TableTdPlant">7 </td>
</tr>
<tr>
 <td class="TableTdPlant">Area </td>  <td class="TableTdPlant">32,87,263 sq.km </td>
</tr>

<tr>
 <td class="TableTdPlant">Area wise in the world </td>  <td class="TableTdPlant">7th </td>
</tr>

<tr>
 <td class="TableTdPlant">Location </td>  <td class="TableTdPlant">India extends between latitudes 8<sup>o</sup>4'N and 37<sup>o</sup>6'N. It is a country of the east with its landmass lying beteen longitudes 68<sup>o</sup>7'E and 97<sup>o</sup>25'E.</td>
</tr>

<tr>
 <td class="TableTdPlant">Stretch </td>  <td class="TableTdPlant">3,214 Kilometers from north to south <br/> 2,933 Kilometers from east to west </td>
</tr>

<tr>
 <td class="TableTdPlant">Land Frontier </td>  <td class="TableTdPlant">15,200 km </td>
</tr>

<tr>
 <td class="TableTdPlant">Coastline </td>  <td class="TableTdPlant">7516.5 km </td>
</tr>

<tr>
 <td class="TableTdPlant">Neighbouring Countries </td>  <td class="TableTdPlant">India shares its political borders with Pakistan and Afghanistan on the west and Bangladesh and Myanmar on the east. The northern boundary is made up of the Sinkiang province of China, Tibet, Nepal and Bhutan. India is seperated from Sri Lanka by a narrow channel of sea formed by the Palk Strait and Gulf of Mannar</td>
</tr>

<tr>
 <td class="TableTdPlant">Physical Feature </td>  <td class="TableTdPlant">The mainland consists of four well-defined regions: (i)The great mountain zone, (ii)The Indo-Gangetic plain, (iii)The desert region and (iv)The Southern Peninsula </td>
</tr>

<tr>
 <td class="TableTdPlant">Rivers </td>  <td class="TableTdPlant">The main rivers of the Himalayan group are the Indus, the Ganga and the Brahmaputra. </td>
</tr>

<tr>
 <td class="TableTdPlant">Climate </td>  <td class="TableTdPlant">There are four seasons which are recognised by the India Meteorological department. They are - Cold weather, hot weather, rainy season and the season of the retreating south-west monsoon. </td>
</tr>

<tr>
 <td class="TableTdPlant">Fauna </td>  <td class="TableTdPlant">Approx. 89,451 species </td>
</tr>

<tr>
 <td class="TableTdPlant">National Parks </td>  <td class="TableTdPlant">94 </td>
</tr>

<tr>
 <td class="TableTdPlant">Wildlife Sanctuaries </td>  <td class="TableTdPlant">501 </td>
</tr>

<tr>
 <td class="TableTdPlant">Official Languages </td>  <td class="TableTdPlant">Hindi </td>
</tr>

<tr>
 <td class="TableTdPlant">Population (2001 census)</td>  <td class="TableTdPlant">1,203,710,000(March 2011)(17% of the world's population) </td>
</tr>

<tr>
 <td class="TableTdPlant">Populationwise place in the world </td>  <td class="TableTdPlant">2nd </td>
</tr>

<tr>
 <td class="TableTdPlant">Population density </td>  <td class="TableTdPlant">324 person per square kilometer </td>
</tr>

<tr>
 <td class="TableTdPlant">Population growth </td>  <td class="TableTdPlant">21.34 % </td>
</tr>

<tr>
 <td class="TableTdPlant">Sex Ratio </td>  <td class="TableTdPlant">933 females per 1000 males </td>
</tr>

<tr>
 <td class="TableTdPlant">Literacy </td>  <td class="TableTdPlant">65.38 % </td>
</tr>

<tr>
 <td class="TableTdPlant">Male Literacy </td>  <td class="TableTdPlant">75.85 % </td>
</tr>

<tr>
 <td class="TableTdPlant">Female Literacy </td>  <td class="TableTdPlant">54.16 % </td>
</tr>
<tr>
 <td class="TableTdPlant">Telephone Code </td>  <td class="TableTdPlant">+91 </td>
</tr>
<tr>
 <td class="TableTdPlant">Coastline </td>  <td class="TableTdPlant">7516.6 km encompassing the mainland, Lakshadweep Islands, and the Andaman & Nicobar Islands.  </td>
</tr>
<tr>
 <td class="TableTdPlant">High Point </td>  <td class="TableTdPlant">Kanchenjunga 8,598 m. </td>
</tr>
<tr>
 <td class="TableTdPlant">National Song </td>  <td class="TableTdPlant">Vande Mataram </td>
</tr>
<tr>
 <td class="TableTdPlant">National Animal </td>  <td class="TableTdPlant">Tiger </td>
</tr>
<tr>
 <td class="TableTdPlant">National Bird </td>  <td class="TableTdPlant">Peacock </td>
</tr>
<tr>
 <td class="TableTdPlant">National Fruit </td>  <td class="TableTdPlant">Mango </td>
</tr>
<tr>
 <td class="TableTdPlant">National Flower </td>  <td class="TableTdPlant">Lotus </td>
</tr>
<tr>
 <td class="TableTdPlant">National Tree </td>  <td class="TableTdPlant"> Banyan </td>
</tr>
<tr>
<td class="TableTdPlant" colspan="2"><b>Government</b> </td> 
</tr>

<tr>
<td class="TableTdPlant">Country Name </td>
<td class="TableTdPlant">Republic of India; Bharat Ganrajya </td>
</tr>

<tr>
<td class="TableTdPlant">Government Type </td>
<td class="TableTdPlant">Sovereign Socialist Democratic Republic with a Parliamentary system of Government </td>
</tr>

<tr>
<td class="TableTdPlant">Capital </td>
<td class="TableTdPlant">New Delhi </td>
</tr>

<tr>
<td class="TableTdPlant">Official Language </td>
<td class="TableTdPlant">Hindi, English </td>
</tr>

<tr>
<td class="TableTdPlant">Administrative Division </td>
<td class="TableTdPlant">29 States and 7 Union Territories. </td>
</tr>

<tr>
<td class="TableTdPlant">Independence </td>
<td class="TableTdPlant">15th August 1947 (From the British Colonial Rule) </td>
</tr>

<tr>
<td class="TableTdPlant">Constitution </td>
<td class="TableTdPlant">The Constitution of India came into force on 26th January 1950. </td>
</tr>

<tr>
<td class="TableTdPlant">Legislature </td>
<td class="TableTdPlant">Sansad </td>
</tr>

<tr>
<td class="TableTdPlant">Legal System </td>
<td class="TableTdPlant">The Constitution of India is the fountain source of the legal system in the Country. </td>
</tr>

<tr>
<td class="TableTdPlant">Executive Branch </td>
<td class="TableTdPlant">The President of India is the Head of the State, while Prime Minister is the Head of the Government, and runs office with the support of Council of Ministers who form the Cabinet Ministry. </td>
</tr>

<tr>
<td class="TableTdPlant">Legislative Branch </td>
<td class="TableTdPlant">The Indian Legislature comprises of the Lok Sabha (House of the people) and the Rajya Sabha (Council of States) forming both the Houses of the Parliament. </td>
</tr>

<tr>
<td class="TableTdPlant">Judicial Branch </td>
<td class="TableTdPlant">The Supreme Court of India is the apex body of the Indian legal system, followed by other High Courts and subordinate Courts.  </td>
</tr>


</table>

		  
<p class="Paragraph">Following are first in India happenings </p>
<h3 class="Title"> Male </h3>
<table  id="tabAddtutorial5" align="center"  width="" cellpadding="" cellspacing="0" border="0" class="table table-hover table-condensed table-bordered " >

<tr style="text-align:left"> <td class="TableTdPlant">The first President of Indian Republic </td><td class="TableTdPlant">Dr. Rajendra Prasad</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first Prime Minister of free India </td><td class="TableTdPlant">Pt. Jawahar Lal Nehru </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first Indian to win Nobel Prize </td><td class="TableTdPlant">Rabindranath Tagore </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first President of Indian National Congress </td><td class="TableTdPlant">W.C. Banerjee</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first Muslim President of Indian National Congress </td><td class="TableTdPlant">Badruddin Tayyabji</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Muslim President of India</td><td class="TableTdPlant">Dr. Zakir Hussain </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first British Governor General of India</td><td class="TableTdPlant">Lord William Bentinck(1833-1835)</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first British Governor General of Bengal</td><td class="TableTdPlant">Lord Warren Hasting(1774-1885)</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first British Viceroy of India </td> <td class="TableTdPlant">Lord Canning</td></tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first Governor General of free India </td><td class="TableTdPlant">Lord Mountbatten</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first and the last Indian to be Governor General of free India </td><td class="TableTdPlant">C. Rajgopalachari</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first man who introduced printing press in India </td><td class="TableTdPlant">James Hicky</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian to join the I.C.S </td><td class="TableTdPlant">Satyendra Nath Tagore </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> India?s first man in Space</td><td class="TableTdPlant">Rakesh Sharma </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Prime Minister of India who resigned without completing the full term</td><td class="TableTdPlant">Morarji Desai</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian Commander-in-Chief of India</td><td class="TableTdPlant">General Cariappa</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Chief of Army Staff</td><td class="TableTdPlant">Gen. Maharaj Rajendra Singhji </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian Member of the Viceroy?s executive council</td><td class="TableTdPlant">S.P.Sinha </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first President of India who died while in office</td><td class="TableTdPlant">Dr. Zakhir Hussain </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Muslim President of Indian Republic</td><td class="TableTdPlant">Dr. Zakhir Hussain </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Prime Minister of India who did not face the Parliament </td><td class="TableTdPlant">Charan Singh </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Field Marshal of India</td><td class="TableTdPlant">S.H.F. Manekshaw </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian to get Nobel Prize in Physics</td><td class="TableTdPlant">C.V.Raman </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian to receive Bharat Ratna award </td>     <td class="TableTdPlant">Dr. Radhakrishnan </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian to cross English Channel</td>     <td class="TableTdPlant"> Mihir Sen</td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Person to receive Jnanpith award</td>     <td class="TableTdPlant">Sri Shankar Kurup </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The firs Speaker of the Lok Sabha</td>     <td class="TableTdPlant">Ganesh Vasudeva Mavalankar </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Vice-President of India</td>     <td class="TableTdPlant">Dr. Radhakrishnan </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Education Minister</td>     <td class="TableTdPlant">Abdul Kalam Azad </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Home minister of India</td>     <td class="TableTdPlant"> Sardar Vallabh Bhai Patel</td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian Air Chief Marshal</td>     <td class="TableTdPlant">S. Mukherjee </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian Naval Chief</td>     <td class="TableTdPlant">Vice Admiral R.D. Katari </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Judge of International Court of Justice</td>     <td class="TableTdPlant">Dr. Nagendra Singh </td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first person to reach Mt. Everest without oxygen</td>     <td class="TableTdPlant"> Sherpa Anga Dorjee</td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first person to get Param Vir Chakra</td>     <td class="TableTdPlant"> Major Somnath Sharma</td></tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Chief Election Commissioner</td>  <td class="TableTdPlant"> Sukumar Sen</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first person to receive Magsaysay Award</td>  <td class="TableTdPlant"> Acharya Vinoba Bhave</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first person of Indian origin to receive Nobel Prize in Medicine</td>  <td class="TableTdPlant">Hargovind Khurana </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Chinese traveller to visit India</td>  <td class="TableTdPlant">Fahein </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first person to receive Stalin Prize</td>  <td class="TableTdPlant"> Saifuddin Kitchlu</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first person to resign from the Central Cabinet</td>  <td class="TableTdPlant"> Shyama Prasad Mukherjee</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first person to receive Nobel Prize in Economics</td>  <td class="TableTdPlant">Amartya Sen </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Chief Justice of Supreme Court</td>  <td class="TableTdPlant">Justice Hirala J. Kania </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant"> The first Indian Pilot</td>  <td class="TableTdPlant">J.R.D. Tata (1929) </td> </tr>

</table>




<h3 class="Title"> Female </u></h3>
<table  id="tabAddtutorial5" align="center"  width="" cellpadding="" cellspacing="0" border="0" class="table table-hover table-condensed table-bordered " >

<tr style="text-align:left"> <td class="TableTdPlant">The first lady to become Miss World </td>  <td class="TableTdPlant">Rita Faria</td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman judge in Supreme Court </td>  <td class="TableTdPlant">Mrs. Meera Sahib Fatima Bibi </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Ambassador </td>  <td class="TableTdPlant">Miss C.B. Muthamma </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Governor of a state in free India </td>  <td class="TableTdPlant">Mrs Sarojini Naidu </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Speaker of a State Assembly </td>  <td class="TableTdPlant">Shanno Devi </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Prime Minister </td>  <td class="TableTdPlant">Mrs Indira Gandhi </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Minister in a Government </td>  <td class="TableTdPlant">Rajkumari Amrit Kaur </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to climb Mount Everest </td>  <td class="TableTdPlant">Bachhendri Pal </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to climb Mount Everest twice </td>  <td class="TableTdPlant">Santosh Yadav </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman President of Indian National Congress </td>  <td class="TableTdPlant">Mrs Annie Besant </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman pilot in Indian Air Force </td>  <td class="TableTdPlant">Harita Kaur Dayal </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Graduates </td>  <td class="TableTdPlant">Kadambini Ganguly and Chandramukhi Basu, 1883 </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Airline Pilot </td>  <td class="TableTdPlant">Durba Banerjee </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Honours Graduate </td>  <td class="TableTdPlant">Kamini Roy, 1886 </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Olympic medal Winner</td>  <td class="TableTdPlant">Karnam Malleswari, 2000 </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Asian Games Gold Medal Winner</td>  <td class="TableTdPlant">Kamlijit Sandhu </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Lawyer </td>  <td class="TableTdPlant">Cornelia Sorabjee </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman President of United Nations General Assembly </td>  <td class="TableTdPlant">Mrs Vijaya Laxmi Pandit </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Chief Minister of an Indian State </td>  <td class="TableTdPlant">Mrs Sucheta Kripalani </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Chairman of Union Public Service Commission </td>  <td class="TableTdPlant">Roze Millian Bethew </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Director General of Police </td>  <td class="TableTdPlant">Kanchan Chaudhary Bhattacharya </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Judge </td>  <td class="TableTdPlant">Anna Chandy (She became judge in a district court in 1937) </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Cheif Justice of High Court </td>  <td class="TableTdPlant">Mrs Leela Seth (Himachal Pradesh High Court) </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Judge in Supreme Court of India </td>  <td class="TableTdPlant">Kumari Justice M. Fathima Beevi </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Lieutenant General </td>  <td class="TableTdPlant">Puneeta Arora </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman Air Vice Marshal </td>  <td class="TableTdPlant">P. Bandopadhyaya </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman chairperson of Indian Airlines </td>  <td class="TableTdPlant">Sushma Chawla </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman IPS officer </td>  <td class="TableTdPlant">Mrs. Kiran Bedi </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first and last Muslim woman ruler of India </td>  <td class="TableTdPlant">Razia Sultan </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to receive Ashoka Chakra </td>  <td class="TableTdPlant">Nirja Bhanot </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to receive Jnanpith Award </td>  <td class="TableTdPlant">Ashapurna Devi </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to cross English Channel </td>  <td class="TableTdPlant">Aarti Saha </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to receive Nobel Prize </td>  <td class="TableTdPlant">Mother Teresa </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to receive Bharat Ratna </td>  <td class="TableTdPlant">Mrs Indira Gandhi </td> </tr>
<tr style="text-align:left"> <td class="TableTdPlant">The first woman to receive Jnanpith Award </td>  <td class="TableTdPlant">Ashpurna Devi </td> </tr>

</table>

<br/>
<h3 class="Title">First in Others </h3>
<table  id="tabAddtutorial5" align="center"  width="" cellpadding="" cellspacing="0" border="0" class="table table-hover table-condensed table-bordered " >

<tr style="text-align:left"> <td class="TableTdPlant">First Wax statue of a Living Indian </td>  <td class="TableTdPlant">Mahatma Gandhi at Madame Tussaud's in 1939 </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Chinese pilgrim to Visit India </td>  <td class="TableTdPlant">Fa-hien </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Exclusive internet magazine  </td>  <td class="TableTdPlant">Bharat Samachar </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Miss India to participate in Miss Universe </td>  <td class="TableTdPlant">Indrani Rehman </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First President of Indian National Congress </td>  <td class="TableTdPlant">W.C. Bannerjee, 1885 </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Muslim President of the Indian National Congress </td>  <td class="TableTdPlant"> Badruddin Tayyabji</td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Judge in International Court of Justice </td>  <td class="TableTdPlant">Dr. Nagender Singh </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Graduate in Medicine  </td>  <td class="TableTdPlant">Soorjo Coomar Goodeve Chukerbutty </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">India's First University  </td>  <td class="TableTdPlant">Nalanda University </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">India's First Open University  </td>  <td class="TableTdPlant">Andhra Pradesh Open University </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">India's First Lok Sabha Member to be elected with a record maximum number of votes  </td>  <td class="TableTdPlant">P.V.Narasimha Rao </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Indian to reach Antarctica </td>  <td class="TableTdPlant">Lt. Ram Charan </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First British to Visit India  </td>  <td class="TableTdPlant">Hawkins</td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Test tube baby of India </td>  <td class="TableTdPlant">Indira (Baby Harsha) </td> </tr>

<tr style="text-align:left"> <td class="TableTdPlant">First Post Office Opened in India </td>  <td class="TableTdPlant">Kolkata(1727) </td> </tr>

</table>


<p class="Title">Constitution of India and Polity</p> 

<p class="Paragraph">The show constitution of India was confined by the Constitution Assembly of India setup under Cabinet Mission Plan of May 16, 1946. 

</p><p class="Paragraph"> 

</p><p class="Paragraph">Composition of Constituent Assembly:- 

<ul><li class="PointTutorials"> 

The Constituent Assembly comprised of 385 individuals, of which 292 were chosen by he chose individuals from the Provincial Legislative Assemblies while 93 individuals were assigned by the Princely States. To these were to be included an agent each from the four Chief Commissioners Provinces of Delhi, Ajmer-Marwar, Coorg and British Baluchistan. 

</li> 

<li class="PointTutorials">Each Province and every Indian State or gathering of States were allocated the aggregate number of oceans relative to their particular populace generally in the proportion of one to a million. 

</li> 

<li class="PointTutorials">B N Rao was delegated the Constitutional Advisor of the Assembly.</li> 

<li class="PointTutorials">The first gathering of the Constituent Assembly occurred of Dec 9, 1946 with Dr. Sachidanand Sinha as its interval President. Dr. Rajendra Prasad was chosen as its President n Dec 11, 1947. 

</li> 

<li class="PointTutorials">The Assembly confining the Constitution.had 13 Committees.</li> 

<li class="PointTutorials">The exceptionally vital Drafting Committee, which bore the duty of drafting the Constitutional archive amid the opening of the Constitutent Assembly, from July 1947 to September 1948, was shaped on August 29, 1947. Its individuals were: 

<ol><li class="PointTutorials">Dr. B.R. Ambedkar </li> 

<li class="PointTutorials">N. Gopalaswami Ayyar </li> 

<li class="PointTutorials">	K.M. Munshi</li> 

<li class="PointTutorials">Syyed Mohd. Saadulla </li> 

<li class="PointTutorials">N.Madhav Rao </li> 

<li class="PointTutorials">D.P.Khaitan (T Krishnamachari, after Kahitan?s Death in 

1948) </li> 

</ol> 

<li class="PointTutorials">It was at long last passed and acknowledged on Nov 26, 1949. The session of the Assembly was hung on Jan 24, 1950, which collectively chose Dr, Rajendra Prasad as the President of India. In all the 284 individuals from the Assembly marked the official duplicates of the Indian Constitution which became effective on Jan 26, 1950, referred to and celebrated as the Republic Day of India. </li> 

</ul>


<p class="Title">Indian Army</p>
<p class="Paragraph"> 

The Indian Army is the world's second biggest armed force regarding military staff. The fundamental duty of the Army is to defend the regional honesty of the country against outside aggressio. Likewise, the Army is regularly required to help the common organization amid inward security unsettling influences and in the mainntenance of peace, in arranging alleviation operations amid characteristic catastrophes like surges, seismic tremors and violent winds and in the support of basic administrations. <br/> 

<p class="Paragraph"> 

The Indian Army is one of the finest armed forces on the planet. Modernisation and upgradation of Army is a nonstop procedure to keep Armed Forces prepared to address any difficulty of tomorrow. It depends on fiver years designs. Center and center zones of modernisation has been:- 

<ul> 

<li class="PointTutorials">Improvement in the Fire Power and expanded Mobiliy </li> 

<li class="PointTutorials">All Weather Battle Field Surveillance ability </li> 

<li class="PointTutorials">Night Fighting abilities </li> 

<li class="PointTutorials">Enhace ability of Special Force </li> 

<li class="PointTutorials">Capability for Network Centric Warfare </li> 

<li class="PointTutorials">NBC Protection </li> 

</ul> 

</p> 

Armed force has its central command in New Delhi. <br/> 

It is head by Chief of the Army Staff and helped by the Vice-Chief of the Army Staff and seven 

other Principal Staff Officers, in particular, two Deputy Chief of Army Staff, Ajutant General, Quarter 

Ace General, Master General of Ordinance, Military Secretary and Engineer-in-Chief. 

The armed force has following orders 

</p>
<p class="Paragraph"> 
<table border=1>
<th>S.No. </th> <th>Command </th> <th>Headquarter </th>
<tr syle="text-align:center"> <td class="TableTdPlant">1 </td> <td class="TableTdPlant">Western command </td> <td class="TableTdPlant">Chandigarh </td>
<tr syle="text-align:center"> <td class="TableTdPlant">2 </td> <td class="TableTdPlant">Eastern command </td> <td class="TableTdPlant">Kolkata </td>
<tr syle="text-align:center"> <td class="TableTdPlant">3 </td> <td class="TableTdPlant">Northern command </td> <td class="TableTdPlant">56 APO </td>
<tr syle="text-align:center"> <td class="TableTdPlant">4 </td> <td class="TableTdPlant">Southern command </td> <td class="TableTdPlant">Pune </td>
<tr syle="text-align:center"> <td class="TableTdPlant">5 </td> <td class="TableTdPlant">Central command </td> <td class="TableTdPlant">Lucknow </td>
<tr syle="text-align:center"> <td class="TableTdPlant">6 </td> <td class="TableTdPlant">Army Training Command </td> <td class="TableTdPlant">Shimla </td>
<tr syle="text-align:center"> <td class="TableTdPlant">7 </td> <td class="TableTdPlant">South Western Command </td> <td class="TableTdPlant">Jaipur </td>
</table>
<!-- <a href="http://www.facts-about-india.com" > >> more infomation on this </a> // -->
</p>

Each under a General officer Commanding-n-Chief of the rank of a Lieutant-General. 

The Major Static Formation are partitioned into Areas, Independent Sub-Areas and sub-territories. 

Territory is directed by a General Officer Commanding of the rank of a Major General and an Independent 

Sub-Area and sub-territory by a Brigadier.
<br/>
Indian army is divided broadly into two main categories:-
<br/>
<ol> <li class="PointTutorials">	Arms </li>
     <li class="PointTutorials">  Services </li>
</ol>

Indian Army consists of following ranks:-
<ol>
  <li class="PointTutorials"> General</li>  
  <li class="PointTutorials"> Lt. General </li>
  <li class="PointTutorials"> Major General</li>
  <li class="PointTutorials"> Brigadier</li>
  <li class="PointTutorials"> Colonel</li>
  <li class="PointTutorials"> Lt. Colonel</li>
  <li class="PointTutorials"> Major</li>
  <li class="PointTutorials"> Captain</li>
  <li class="PointTutorials"> Lieutenant</li>
</ol>






<p class="Title">Brief History of Indian Neavy</u></p> 

<p class="Paragraph"> 

<image src="image-records/indian-naval force logo.jpg" alt="Indian Navy" align=right height="200" width="250"> 

The Indian Navy, by righteousness of its capacities, key situating and vigorous nearness in the Indian Ocean Region (IOR), has been an impetus for peace, quietness and security in the IOR. It has been locked in other sea countries, broadening hand of kinship and co-operation. 

<br/><br/> 

On India accomplishing Independence, the Royal Indian Navy comprised of 32 maturing vessels appropriate just for seaside watch, alongside 11,000 officers and men. The senior officers were drawn from the Royal Navy, with R Adm ITS Hall, CIE, being the principal Post-freedom Commander-in-Chief. The prefix 'Imperial' was dropped on 26 January 1950 with India being constituted as a Republic. The principal Commander-in-Chief of the Indian Navy was Adm Sir Edward Parry, KCB, who gave over to Adm Sir Mark Pizey, KBE, CB, DSO in 1951. Adm Pizey additionally turned into the main Chief of the Naval Staff in 1955, and was prevailing by V Adm SH Carlill, CB, DSO. 

</p> 

<p class="Paragraph"><b><i>On 22 April 1958 V Adm RD Katari accepted office as the main Indian Chief of the Naval Staff. 

</i></b></p> 

Indian Navy is going by Chief of Navel Staff with base camp at New Delhi. He is helped by Vice Chief of Naval Staff, Chief of Personnel, Chief of Material and Deputy Chief of Naval Staff. The Navy is sorted out into following orders:-
<p class="Paragraph">
<table border=1>
<th>S.No. </th> <th>Command </th> <th>Headquarter </th>
<tr syle="text-align:center"> <td class="TableTdPlant">1 </td> <td class="TableTdPlant">Eastern command </td> <td class="TableTdPlant">Vishakhapatnam </td>
<tr syle="text-align:center"> <td class="TableTdPlant">2 </td> <td class="TableTdPlant">Southern command </td> <td class="TableTdPlant">Kochi </td>
<tr syle="text-align:center"> <td class="TableTdPlant">3 </td> <td class="TableTdPlant">Western command </td> <td class="TableTdPlant"> Mumbai</td>
</table>
<!-- <a href="http://www.facts-about-india.com" > >> more infomation on this </a> // -->


</p>

Ranks:-
<ol>
  <li class="PointTutorials"> Navy </li>
  <li class="PointTutorials"> Admiral </li>
  <li class="PointTutorials"> Vice Admiral </li>
  <li class="PointTutorials"> Read Admiral </li>
  <li class="PointTutorials"> Commodore </li>
  <li class="PointTutorials"> Captain </li>
  <li class="PointTutorials"> Commander </li>
  <li class="PointTutorials"> Lt Commander </li>
  <li class="PointTutorials"> Lieutenant </li>
  <li class="PointTutorials"> Sub-Lieutenant</li>
</ol>

The Indian Navy is divided into the following broad categories
<ul>
<li class="PointTutorials">Administration </li>
<li class="PointTutorials">Logistics and Material </li>
<li class="PointTutorials">Training </li>
<li class="PointTutorials">The Fleets </li>
<li class="PointTutorials">The Naval Aviation </li>
<li class="PointTutorials">The Submarine Arm. </li>
</ul>





<p class="Title">The Indian Air Force was authoritatively settled on 8 October 1932. 

 Brief History </p> 

<p class="Paragraph"> 
The previous 75 years have been significant for Indian Air Force (IAF) from a flight of 'Wapitis' in 1932, to the fourth biggest, professionally acclaimed, key Air Force in charge of guarding Nation's crucial advantages. From 1948 to Kargil, the IAF has dependably handled wining capacities. IAF's expert and incite operations in peace time, at home and abroad and in peacekeeping, have earned numerous honors. 

<br/> <br/> 

The initial five pilots dispatched into the Indian Air Force were H C Sircar, Subroto Mukerjee, Bhupendra Singh, A B Awan and Amarjeet Singh. A 6th officer, S N Tandon needed to return to Ground obligations as he was too short. Every one of them were dispatched as ''Pilot Officers'' in 1933. Subroto Mukerjee later went ahead to wind up noticeably the IAF's first Indian Chief of Air Staff. Resulting clusters drafted before World_War_2 included Aspy Engineer, K Majumdar, Narendra, R H D Singh, S N Goyal, Baba Mehar Singh, Prithpal Singh and Arjan Singh. 

<br/> 

The Indian Air Force is going by Chief of Air Staff with its home office at New Delhi. He is helped by six Principal Staff Officers, Vice Chief of Air Staff, Deputy Chief of Air Staff, Air Officer Incharge Administration, Air Officer Incharge Maintenance, Air Officer Incharge Personnel and Training and Inspector General Flight Safety and Inspection. 

</p>
<p class="Paragraph">
<table border=1>
<th>S.No. </th> <th>Command </th> <th>Headquarter </th>
<tr syle="text-align:center"> <td class="TableTdPlant">1 </td> <td class="TableTdPlant">Western command </td> <td class="TableTdPlant">New Delhi</td>
<tr syle="text-align:center"> <td class="TableTdPlant">2 </td> <td class="TableTdPlant">Central command </td> <td class="TableTdPlant">Allahabad </td>
<tr syle="text-align:center"> <td class="TableTdPlant">3 </td> <td class="TableTdPlant">Eastern command </td> <td class="TableTdPlant">Shillong </td>
<tr syle="text-align:center"> <td class="TableTdPlant">4 </td> <td class="TableTdPlant">South western command </td> <td class="TableTdPlant">Jodhpur </td>
<tr syle="text-align:center"> <td class="TableTdPlant">5 </td> <td class="TableTdPlant">Training command </td> <td class="TableTdPlant">Bangaluru </td>
<tr syle="text-align:center"> <td class="TableTdPlant">6 </td> <td class="TableTdPlant">Maintenance command </td> <td class="TableTdPlant">Nagpur </td>
<tr syle="text-align:center"> <td class="TableTdPlant">7 </td> <td class="TableTdPlant">Southern command </td> <td class="TableTdPlant">Thiruvananthapuram </td>
</table>
<!-- <a href="http://www.facts-about-india.com" > >> more infomation on this </a> // -->
</p>

The Air constrain battle armada is comprised of 45 squadrons comprises an assortment of warriors, contender planes, warrior interceptors, aircraft and transport and coordinations bolster air ship.
<ol>
  <li class="PointTutorials"> Air chief Marshal</li>
  <li class="PointTutorials"> Air Marshal</li>
  <li class="PointTutorials"> Air Vice Marshal</li>
  <li class="PointTutorials"> Air Commodore</li>
  <li class="PointTutorials"> Group Captain</li>
  <li class="PointTutorials"> Wing Commander</li>
  <li class="PointTutorials"> Squardron Leader</li>
  <li class="PointTutorials"> Flt. Lieutenant</li>
  <li class="PointTutorials"> Flying officers</li>
</ol>  




<p class="Title">Climate of India  </p>
<p class="Paragraph"> 

India has 'Tropical Monsoon' sort of atmosphere. The word storm has been gotten from the Arabic word 'Mausim' which implies occasional inversion of the breezes over the span of the year. 

</p> 

<table border=1 cellpadding=3> 

<th class="table_set"> Climate of India </th> 

<tr> 

<td class="TableTdPlant"> 

<ol> 

<li class="PointTutorials">The entire of India has a tropical monsoonal atmosphere, since most of the nation exists in the trophies, and the atmosphere is affected by the storms. </li> 

<li class="PointTutorials">The position of the mountain extents and course of the rain-bearing breezes are the two fundamental factors that decide the atmosphere of India </li> 

<li class="PointTutorials">Alternating seasons is the central normal for India's Climate. </li> 

</ol> 

</td> 

</tr> 

</table> 

<p class="Paragraph"> 

<b>Factors Affecting the Climate of India</u></b>: 

<ol> 

<li class="PointTutorials"> Latitude</u>: India lies between 8 <sup>0</sup> N and 37 <sup>0</sup> N scopes. The Tropic of Cancer goes through the center of India, hence influencing the southern portion of India in the Torrid Zone and the northern half in the Temperature To zone. </li> 

<li class="PointTutorials">Himalaya Mountains</u>: The Himalayas assume a vital part in loaning a sub-tropical touch to the atmosphere of India. The grand Himalaya Mountains shape a hindrance which impacts the atmosphere of India. It keeps the chilly breezes of north Asia from blowing into India, in this way shielding it from seriously icy winters. It likewise traps the Monsoon winds, compelling them to shed their dampness inside the sub-mainland. </li> 

<li class="PointTutorials">Altitude</u>: Temperature diminishes with stature. Places in the mountains are cooler than places on the plains.</li> 

<table border=0 align=right> 

<tr><td class="TableTdPlant"> 

</td></tr> 

</table> 

<li class="PointTutorials">Distance from the sea</u>: With a long coastline, vast beach front zones have an equable atmosphere. Regions in the inside of India are far from the directing impact of the ocean. Such regions have extremes of climate.</li> 

<li class="PointTutorials">Geographical Limits</u>: 

<ol type=i> 

<li class="PointTutorials">Western Disturbances: The low weight frameworks that begin over the eastern Mediterranean district in winter and move eastwards towards India disregarding Iran, Afghanistan and Pakistan are in charge of the winter rain in northern India. </li> 

<li class="PointTutorials">Conditions in the Regions Surrounding India: Temperature and weight conditions in East Africa, Iran, Central Asia and Tibet decide the quality of the storms and the incidental droughts. For instance, high temperatures in East Africa may draw the storm twists from the Indian Ocean into that area in this manner, causing a drought. </li> 

<li class="PointTutorials">Conditions over the Ocean: The climate conditions over the Indian sea and the China Sea might be in charge of tropical storms which frequently influence the east shore of India. </li> 

<li class="PointTutorials">Jet Streams: Air ebbs and flows in the upper layers of the environment known as fly steams could decide the landing of the storms and flight of the rainstorm. The Scientists are examining the fly streams and how it might influence the atmosphere of India however much stays to be found out about this wonders. </li> 

</ol> 

</li> 

</ol> 

</p> 

<p class="Title">Festivals in India are dictated by Solar and Lunar positions and they <b> may fall in the distinctive month </b>as determined beneath:- </p>
<table border=1>

<tr>
<td  style="text-align:center" width=30%> January
</td>
<td width=400>
  <ul>
   <li class="PointTutorials">Maker Sankranti </li>
   <li class="PointTutorials">Lohri </li>
   <li class="PointTutorials">Pongal </li>
   <li class="PointTutorials">Thai Pusam </li>
   <li class="PointTutorials">Flot Festivals </li>
   <li class="PointTutorials">National Kite Festival </li>
   <li class="PointTutorials">Kerela Village Fair </li>
   <li class="PointTutorials">Bikaner Festival </li>
   <li class="PointTutorials">Pattadakal Dance Festival </li>
   <li class="PointTutorials">Id-ud-Fitr </li>
   <li class="PointTutorials">Vasant Panchami </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> February
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Mahashivratri </li>
   <li class="PointTutorials">Goa Carnival </li>
   <li class="PointTutorials">Desert Festival </li>
   <li class="PointTutorials">Nagaur Fair </li>
   <li class="PointTutorials">International Yoga Week </li>
   <li class="PointTutorials">Elephant Festival </li>
   <li class="PointTutorials">Deccan Festival </li>
   <li class="PointTutorials">Taj Mahotsav </li>
   <li class="PointTutorials">Surajkund Crafts Mela </li>
   <li class="PointTutorials">Chapchar Kut </li>
   <li class="PointTutorials">Islands Tourism Festivals </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> March
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Holi	 </li>
   <li class="PointTutorials">Ganaur </li>
   <li class="PointTutorials">Jamshed-e-Navroz</li>
   <li class="PointTutorials">Ramnavami </li>
   <li class="PointTutorials">Id-ul-Zuha </li>
   <li class="PointTutorials">Mahavir Jayanti</li>
   <li class="PointTutorials">Khajuraho Dance Festival </li>
   <li class="PointTutorials">Elephant Festival </li>
   <li class="PointTutorials">Hoysla Mahotsava </li>
   <li class="PointTutorials">Ellora Festival </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> April
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Good Friday </li>
   <li class="PointTutorials">Easter </li>
   <li class="PointTutorials">Baisakhi </li>
   <li class="PointTutorials">Gudi Padva or Ugadi </li>
   <li class="PointTutorials">Pooram </li>
   <li class="PointTutorials">Muharram </li>
   <li class="PointTutorials">Buddha Purnima </li>
   <li class="PointTutorials">Mewar </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> May
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Urs Festival</li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> June
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Ganga Dussehra </li>
   <li class="PointTutorials">Hemis Festival </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> July
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Rathyatra </li>
   <li class="PointTutorials">Guru Purnima </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> August
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Janmashtami </li>
   <li class="PointTutorials">Onam </li>
   <li class="PointTutorials">Nag Panchami </li>
   <li class="PointTutorials">Rakshabandhan </li>
   <li class="PointTutorials">Ganesh Chaturthi </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> September
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Tarnetar Mela </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> October
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Navratri </li>
   <li class="PointTutorials">Durga Puja.	 </li>
   <li class="PointTutorials">Dussehra </li>
   <li class="PointTutorials">Marwar Festival </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> November
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Sharad Purnima </li>
   <li class="PointTutorials">Diwali </li>
   <li class="PointTutorials">Guru Purab </li>
   <li class="PointTutorials">Ka Pomblang Nongrem </li>
   <li class="PointTutorials">Sonepur Fair </li>
   <li class="PointTutorials">Pushkar Fair </li>
   <li class="PointTutorials">Hampi Festival </li>
  </ul>
</td>
</tr>

<tr>
<td  style="text-align:center"> December
</td>
<td class="TableTdPlant">
  <ul>
   <li class="PointTutorials">Christma </li>
   <li class="PointTutorials">Konark Dance Festival</li>
  </ul>
</td>
</tr>

</table>







<p class="Title"> States and their Capitals</p>

<table border=1 cellpadding=3>

<th bgcolor=#E0E0E0 class="centr" colspan=5> States and their Capitals </th>

<tr>
 <td class="TableTdPlant"><b>State</td>  <td width=30%><b>Administrative Capital</td>  <td class="TableTdPlant"><b>Legislative Capital</td>  <td class="TableTdPlant"><b>Judicial Capital </td>  <td class="TableTdPlant"><b>Since </td>
</tr>

<tr>
 <td class="TableTdPlant">Andhra Pradesh</td>  <td class="TableTdPlant">Hyderabad</td>  <td class="TableTdPlant">Hyderabad </td>  <td class="TableTdPlant">Hyderabad </td>  <td class="TableTdPlant">1956</td>
</tr>

<tr>
 <td class="TableTdPlant">Arunachal Pradesh </td>  <td class="TableTdPlant">Itanagar </td>  <td class="TableTdPlant">Itanagar </td>  <td class="TableTdPlant">Guwahati </td>  <td class="TableTdPlant">1972</td>
</tr>


<tr>
 <td class="TableTdPlant">Assam</td>  <td class="TableTdPlant">Dispur (Former Capital: Shilong(1874-1972)) </td>  <td class="TableTdPlant">Dispur </td>  <td class="TableTdPlant">Guwahati</td>  <td class="TableTdPlant">1972 </td>
</tr>

<tr>
 <td class="TableTdPlant">Bihar </td>  <td class="TableTdPlant">Patna</td>  <td class="TableTdPlant">Patna </td>  <td class="TableTdPlant">Patna </td>  <td class="TableTdPlant">1936</td>
</tr>

<tr>
 <td class="TableTdPlant">Chhattisgarh</td>  <td class="TableTdPlant">Raipur</td>  <td class="TableTdPlant">Raipur</td>  <td class="TableTdPlant">Bilaspur</td>  <td class="TableTdPlant">2000</td>
</tr>

<tr>
 <td class="TableTdPlant">Goa</td>  <td class="TableTdPlant">Panji </td>  <td class="TableTdPlant">Porvorim</td>  <td class="TableTdPlant">Mumbai</td>  <td class="TableTdPlant">1961</td>
</tr>

<tr>
 <td class="TableTdPlant">Gujarat</td>  <td class="TableTdPlant">Gandhinagar(Formal Capital: Ahmedabad(1960-1970))</td>  <td class="TableTdPlant">Gandhinagar</td>  <td class="TableTdPlant">Ahmedabad</td>  <td class="TableTdPlant">1970 </td>
</tr>

<tr>
 <td class="TableTdPlant">Haryana</td>  <td class="TableTdPlant">Chandigarh</td>  <td class="TableTdPlant">Chandigarh </td>  <td class="TableTdPlant">Chandigarh</td>  <td class="TableTdPlant">1966</td>
</tr>

<tr>
 <td class="TableTdPlant">Himachal Pradesh</td>  <td class="TableTdPlant">Shimla </td>  <td class="TableTdPlant">Shimla </td>  <td class="TableTdPlant">Shimla </td>  <td class="TableTdPlant">1948 </td>
</tr>

<tr>
 <td class="TableTdPlant">Jammu and Kashmir</td>  <td class="TableTdPlant">Srinagar(S),Jammu(W) </td>  <td class="TableTdPlant">Srinagar(S),Jammu(W)  </td> <td class="TableTdPlant">Srinagar </td>  <td class="TableTdPlant">1948</td>
</tr>

<tr>
 <td class="TableTdPlant">Jharkhand</td>  <td class="TableTdPlant">Ranchi </td>  <td class="TableTdPlant">Ranchi </td>  <td class="TableTdPlant">Ranchi </td>  <td class="TableTdPlant">2000</td>
</tr>

<tr>
<td class="TableTdPlant">Karnataka</td>  <td class="TableTdPlant">Bangaluru  </td>  <td class="TableTdPlant">Bangaluru</td>  <td class="TableTdPlant">Bangaluru </td>  <td class="TableTdPlant">1956 </td>
</tr>

<tr>
 <td class="TableTdPlant">Kerala</td>  <td class="TableTdPlant">Thiruvanantha-Puram (Former Capital: Kochi(1949-1956))</td>  <td class="TableTdPlant">T'puram </td>  <td class="TableTdPlant">Ernakulam</td>  <td class="TableTdPlant">1956</td>
</tr>

<tr>
 <td class="TableTdPlant">Madhya Pradesh</td>  <td class="TableTdPlant">Bhopal </td>  <td class="TableTdPlant">Bhopal </td>  <td class="TableTdPlant">Jabalpur </td>  <td class="TableTdPlant">1956</td>
</tr>

<tr>
 <td class="TableTdPlant">Maharashtra</td>  <td class="TableTdPlant">Mumbai</td>  <td class="TableTdPlant">Mumbai </td>  <td class="TableTdPlant">Mumbai </td>  <td class="TableTdPlant">1818</td>
</tr>

<tr>
 <td class="TableTdPlant">Manipur</td>  <td class="TableTdPlant">Imphal </td>  <td class="TableTdPlant">Imphal </td>  <td class="TableTdPlant">Guwahati </td>  <td class="TableTdPlant">1947</td>
</tr>

<tr>
 <td class="TableTdPlant">Meghalaya</td>  <td class="TableTdPlant">Shillong </td>  <td class="TableTdPlant">Shillong </td>  <td class="TableTdPlant">Guwahati </td>  <td class="TableTdPlant">1970</td>
</tr>

<tr>
 <td class="TableTdPlant">Mizoram </td>  <td class="TableTdPlant">Aizwal </td>  <td class="TableTdPlant">Aizwal </td>  <td class="TableTdPlant">Guwahati </td>  <td class="TableTdPlant">1972</td>
</tr>

<tr>
 <td class="TableTdPlant">Nagaland </td>  <td class="TableTdPlant">Kohima </td>  <td class="TableTdPlant">Kohima </td>  <td class="TableTdPlant">Guwahati </td>  <td class="TableTdPlant">1963 </td>
</tr>

<tr>
 <td class="TableTdPlant">Orrisa </td>  <td class="TableTdPlant">Bhubaneshwar (Former Capital: Cuttak (1936-1948)) </td>  <td class="TableTdPlant">Bhubaneshwar </td>  <td class="TableTdPlant">Cuttack </td>  <td class="TableTdPlant">1948 </td>
</tr>

<tr>
 <td class="TableTdPlant">Punjab </td>  <td class="TableTdPlant">Chandigarh (Former Capital: Lahore(1936-1947) & Shimla(1947-1966))</td>  <td class="TableTdPlant">Chandigarh </td>  <td class="TableTdPlant">Chandigarh </td>  <td class="TableTdPlant">1966</td>
</tr>

<tr>
 <td class="TableTdPlant">Rajasthan</td>  <td class="TableTdPlant">Jaipur </td>  <td class="TableTdPlant">Jaipur </td>  <td class="TableTdPlant">Jodhpur </td>  <td class="TableTdPlant">1948 </td>
</tr>

<tr>
 <td class="TableTdPlant">Sikkim </td>  <td class="TableTdPlant">Gangtok </td>  <td class="TableTdPlant">Gangtok </td>  <td class="TableTdPlant">Gangtok </td>  <td class="TableTdPlant">1975 </td>
</tr>

<tr>
 <td class="TableTdPlant">Tamil Nadu </td>  <td class="TableTdPlant">Chennai </td>  <td class="TableTdPlant">Chennai </td>  <td class="TableTdPlant">Chennai </td>  <td class="TableTdPlant">1956 </td>
</tr>

<tr>
 <td class="TableTdPlant">Tripura</td>  <td class="TableTdPlant">Agartala </td>  <td class="TableTdPlant">Agartala </td>  <td class="TableTdPlant">Guwahati </td>  <td class="TableTdPlant">1956 </td>
</tr>

<tr>
 <td class="TableTdPlant">Uttarakhand</td>  <td class="TableTdPlant">Dehradun </td>  <td class="TableTdPlant">Dehradun </td>  <td class="TableTdPlant">Nainital </td>  <td class="TableTdPlant">2000 </td>
</tr>

<tr>
 <td class="TableTdPlant">Uttar Pradesh </td>  <td class="TableTdPlant">Lucknow </td>  <td class="TableTdPlant">Lucknow </td>  <td class="TableTdPlant">Allahabad </td>  <td class="TableTdPlant">1937 </td>
</tr>

<tr>
 <td class="TableTdPlant">West Bengal </td>  <td class="TableTdPlant">Kolkata </td>  <td class="TableTdPlant">Kolkata </td>  <td class="TableTdPlant">Kolkata </td>  <td class="TableTdPlant">1905 </td>
</tr>


<tr >
 <td colspan=5 class="TableTdPlant"  ><b>Union Territories </td>
</tr>

<tr>
 <td class="TableTdPlant">Andaman and Nicobar Islands </td>  <td class="TableTdPlant">Port Blair </td>  <td class="TableTdPlant">-- </td>  <td class="TableTdPlant">Kolkata </td> <td class="TableTdPlant">1956 </td>
</tr>

<tr>
 <td class="TableTdPlant">Chandigarh </td>  <td class="TableTdPlant">Chandigarh </td>  <td class="TableTdPlant">-- </td>  <td class="TableTdPlant">Chandigarh </td> <td class="TableTdPlant">1966 </td>
</tr>

<tr>
 <td class="TableTdPlant">Dadra and Nagar Haveli </td>  <td class="TableTdPlant">Silvasaa </td>  <td class="TableTdPlant">-- </td>  <td class="TableTdPlant">Mumbai </td> <td class="TableTdPlant">1961 </td>
</tr>

<tr>
 <td class="TableTdPlant">Daman and Diu </td>  <td class="TableTdPlant">Daman </td>  <td class="TableTdPlant">-- </td>  <td class="TableTdPlant">Mumbai </td> <td class="TableTdPlant">1987 </td>
</tr>

<tr>
 <td class="TableTdPlant">Lakshadweep </td>  <td class="TableTdPlant">Kavaratti </td>  <td class="TableTdPlant">-- </td>  <td class="TableTdPlant">Ernakulam </td> <td class="TableTdPlant">1956 </td>
</tr>

<tr>
 <td class="TableTdPlant">National Capital Territory of Delhi </td>  <td class="TableTdPlant">N.Delhi </td>  <td class="TableTdPlant">-- </td>  <td class="TableTdPlant">-- </td> <td class="TableTdPlant">--</td>
</tr>

<tr>
 <td class="TableTdPlant">Ponducherry </td>  <td class="TableTdPlant">Ponducherry  </td>  <td class="TableTdPlant"> Ponducherry </td>  <td class="TableTdPlant">Chennai </td> <td class="TableTdPlant">1954 </td>
</tr>

</table>



<p class="Title">Largest In India</p>

<table border=1 cellspacing="1" cellpadding="4" >

<tr>
<td class="TableTdPlant">Highest Award </td>
<td class="TableTdPlant">Bharat Ratna </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Gallantry Award </td>
<td class="TableTdPlant">Param Vir Chakra </td>
</tr>


<tr>
<td class="TableTdPlant">Longest River in India </td>
<td class="TableTdPlant">The Ganges </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Tributary river of India </td>
<td class="TableTdPlant">Yamuna </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Lake </td>
<td class="TableTdPlant">Wular Lake, Kashmir </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Lake (Saline Water) </td>
<td class="TableTdPlant">Chilka Lake, Orrisa </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Man-Made Lake </td>
<td class="TableTdPlant">Govind Vallabh Pant Sagar (Rihand Dam) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Fresh Water Lake </td>
<td class="TableTdPlant">Kolleru Lake (Andhra Pradesh) </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Lake </td>
<td class="TableTdPlant">Devtal Lake, Gadhwal (Uttarakhand) </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Lake </td>
<td class="TableTdPlant">Devatal (Gharhwal) </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Peak </td>
<td class="TableTdPlant">Karkoram-2 of K-2(8,611 meters)
<br/>Highest Peak in the world is Mount Everest which is in Nepal
</td>
</tr>

<tr>
<td class="TableTdPlant">Largest Populated City </td>
<td class="TableTdPlant">Mumbai </td>
</tr>

<tr>
<td class="TableTdPlant">Largest State(Area) </td>
<td class="TableTdPlant">Rajasthan </td>
</tr>

<tr>
<td class="TableTdPlant">Largest State(Population) </td>
<td class="TableTdPlant">Uttar Pradesh </td>
</tr>

<tr>
<td class="TableTdPlant">Highest rainfall </td>
<td class="TableTdPlant">Cherrapunhi (426 inches per annum) </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Watefall </td>
<td class="TableTdPlant">Nohkalikai Falls (335 meters, 1100 ft high) in Shora </td>
</tr>

<tr>
<td class="TableTdPlant">State wise largest area under forest  </td>
<td class="TableTdPlant">Madhya Pradesh </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Delta  </td>
<td class="TableTdPlant">Sunderbans Delta </td>
</tr>

<tr>
<td class="TableTdPlant">Largest River without Delta  </td>
<td class="TableTdPlant">Narmada and Tapti </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Cantilever Span bridge  </td>
<td class="TableTdPlant">Howrah Bridge </td>
</tr>

<tr>
<td class="TableTdPlant">Longest River Bridge   </td>
<td class="TableTdPlant">Mahatma Gandhi Setu, Patna </td>
</tr>

<tr>
<td class="TableTdPlant">Biggest Cave temple </td>
<td class="TableTdPlant">Ellora </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Road </td>
<td class="TableTdPlant">  Grand Trunk Road</td>
</tr>

<tr>
<td class="TableTdPlant">Highest Road </td>
<td class="TableTdPlant">Road at Khardungla,(in Leh-Manali Sector)</td>
</tr>

<tr>
<td class="TableTdPlant">Biggest Mosque  </td>
<td class="TableTdPlant">Jama Masjid at Delhi </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Gateway </td>
<td class="TableTdPlant">Buland Darwaza at Fatehpur Sikri (53.6 meters high) </td>
</tr>

<tr>
<td class="TableTdPlant">Tallest Statue  </td>
<td class="TableTdPlant">Statue of Gomateshwar (17 meters high In Karnataka </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Public Sector Bank  </td>
<td class="TableTdPlant">State Bank of India </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Canal  </td>
<td class="TableTdPlant">Indira Gandhi Canal or Rajasthan Canal (Rajasthan) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Dome </td>
<td class="TableTdPlant">Gol Gumbaz at Bijapur </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Zoo  </td>
<td class="TableTdPlant">Zoological Garden at Alipur (Kolkata) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Museum  </td>
<td class="TableTdPlant"> India Museum at Kolkata</td>
</tr>

<tr>
<td class="TableTdPlant">Longest Dam  </td>
<td class="TableTdPlant">Hirakud Dam (Orrisa) </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Dam  </td>
<td class="TableTdPlant">Tehri Dam ( 260 meters , 850 ft ) </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Tower  </td>
<td class="TableTdPlant">Kutab Minar at Delhi (88.4 meters high) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Desert </td>
<td class="TableTdPlant">Thar (Rajasthan) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest District </td>
<td class="TableTdPlant">Kutch district  </td>
</tr>

<tr>
<td class="TableTdPlant">Fastest Train </td>
<td class="TableTdPlant">Shatabadi Express running between 
New Delhi and Bhopal </td>
</tr>


<tr>
<td class="TableTdPlant">State with longest coastline  </td>
<td class="TableTdPlant">Gujarat </td>
</tr>

<tr>
<td class="TableTdPlant">State with longest coastline of South India </td>
<td class="TableTdPlant">Andhra Pradesh </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Electric Railway Line  </td>
<td class="TableTdPlant">From Delhi to Kolkata via Patna </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Railway Route </td>
<td class="TableTdPlant"> From Assam to Kanyakumari </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Railway Platform </td>
<td class="TableTdPlant"> Kharagpur (W. Bengal) </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Railway Station </td>
<td class="TableTdPlant"> Ghum (W. Bengal) </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Platform  </td>
<td class="TableTdPlant">Kharagpur (West Bengal) 833 meters in Length.
It is also the longest railway station in world </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Tunnel  </td>
<td class="TableTdPlant">Jawahar tunnel (Jammu  & Kashmir) </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Highway  </td>
<td class="TableTdPlant">NH-44 (NH-7) which turns from Varanasi to Kanyakumari </td>
</tr>

<tr>
<td class="TableTdPlant">Smallest State (Population) </td>
<td class="TableTdPlant">Sikkim </td>
</tr>

<tr>
<td class="TableTdPlant">Smallest State (Area) </td>
<td class="TableTdPlant"> Goa</td>
</tr>

<tr>
<td class="TableTdPlant">Largest State (Area) </td>
<td class="TableTdPlant"> Rajasthan</td>
</tr>

<tr>
<td class="TableTdPlant">Largest State (Population) </td>
<td class="TableTdPlant">Uttar Pradesh </td>
</tr>

<tr>
<td class="TableTdPlant">Densest Populated State </td>
<td class="TableTdPlant">West Bengal </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Cave </td>
<td class="TableTdPlant">Amarnath (J&K)</td>
</tr>

<tr>
<td class="TableTdPlant">Largest Cave Temple </td>
<td class="TableTdPlant"> Kailash Temple, Ellora (Maharastra)</td>
</tr>

<tr>
<td class="TableTdPlant">Largest Animal Fair </td>
<td class="TableTdPlant">Sonepur (Bihar) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Auditorium </td>
<td class="TableTdPlant">Sri Shanmukhanand Hall (Mumbai) </td>
</tr>

<tr>
<td class="TableTdPlant">Biggest Hotel </td>
<td class="TableTdPlant">Oberai-Sheraton (Mumbai) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Port </td>
<td class="TableTdPlant">Mumbai </td>
</tr>

<tr>
<td class="TableTdPlant"> Largest Gurudwara</td>
<td class="TableTdPlant">Golden Temple, Amritsar </td>
</tr>

<tr>
<td class="TableTdPlant">Deepest River Valley </td>
<td class="TableTdPlant">Bhagirathi & Alaknanda </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Church </td>
<td class="TableTdPlant">Saint Cathedral (Goa) </td>
</tr>

<tr>
<td class="TableTdPlant">Oldest Church </td>
<td class="TableTdPlant">St. Thomas Church at Palayar, Trichur (Kerala) </td>
</tr>

<tr>
<td class="TableTdPlant">Longest River </td>
<td class="TableTdPlant">Ganga (2640 km long) </td>
</tr>

<tr>
<td class="TableTdPlant">Longest Beach </td>
<td class="TableTdPlant">Marina Beach, Chennai </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Battle Field </td>
<td class="TableTdPlant">Siachin Glacier </td>
</tr>

<tr>
<td class="TableTdPlant">Highest Airport </td>
<td class="TableTdPlant">Leh (Laddakh) </td>
</tr>

<tr>
<td class="TableTdPlant">Biggest Stadium </td>
<td class="TableTdPlant">Yuva Bharti (Salt Lake) Stadium, Kolkata</td>
</tr>

<tr>
<td class="TableTdPlant">Largest River Island </td>
<td class="TableTdPlant">Majuli (Brahmaputra River, Asom) </td>
</tr>

<tr>
<td class="TableTdPlant">Largest Planetarium</td>
<td class="TableTdPlant">Birla Planetarium (Kolkata)</td>
</tr>

<tr>
<td class="TableTdPlant">Sambhar lake</td>
<td class="TableTdPlant">Largest inland salt lake</td>
</tr>

</table>	

</div>
<p ><a class="TutorialPreviousPagea" href="ImportantMedicinalPlants.php">&lt;&lt;-Previous  Page</a>
                          <a class="TutorialNextPagea"  href="ListofMedicinalplantsandtheiruses.php">Next Page-&gt;&gt;</a></p> <br/>       	
<?php
  require "IndexRelated/indexLower.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>
</html>