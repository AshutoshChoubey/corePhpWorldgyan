<div style="width: 100%; height: 29px; background-color:!important">
                 <!---------------Adds Are Here ----------------------!>   
                    <?php
                        require "../../../IndexRelated/Adds2.php";
                    ?> 
                  <!---------------Adds Are Here ----------------------!>    
                </div>
        	</div>        
        </div>
		<div id="sidebar-right"> 
                <?php
                     require "RightSideBar.php";
                 ?>
         
            <table border='0' style="width: 100%; height: 500px; background-color;">
                <tr><td>   
                    <?php
                         require "../../../IndexRelated/Adds3.php";
                     ?>
                  </td></tr>   
            </table>            
        </div>
           <table border='0' style="width: 100%; height: 100px; background-color;">
                <tr><td>   
                  <div style="width: 100%; height: 100px; background-color:;">
                 <!---------------Adds Are Here ----------------------!>   
                 <?php
                     require "../../../IndexRelated/Adds4.php";
                 ?>
                  <!---------------Adds Are Here ----------------------!>    
                </div>  
                  </td></tr>   
            </table>        
		<div id="footer">
              <?php
                     require "../../../IndexRelated/Footer.php";
                 ?>
         
        </div>
	</body>