<?
$Contents='JavaTutorial';
require "AboveWorlplace.php";
?>

        		<div class="contentTutorial">
                                       <!-- Start from Here -->
                                       <!--------------------------------------->
                      <h1 align='center'>Science of Self Realization(Title)</h1>
                      <div style="width: 100%; height: 200px; background-color:!important;">
                      <table align='left' style="width: 30%; float: left;border: 1px solid #032D5D;">
                      <tr>
                          <td style="font-size: 12px;"><b></b>Author:</b></td>
                          <td style="font-size: 10px;">ASHUTOSH KUMAR CHOUBEY</td>                      
                      </tr>
                      <tr>
                          <td style="font-size: 12px;"><b></b>Publisher:</b></td>
                          <td style="font-size: 10px;">ASHUTOSH KUMAR CHOUBEY</td>                      
                      </tr>
                      <tr>
                          <td style="font-size: 12px;"><b></b>Source:</b></td>
                          <td style="font-size: 10px;">iskcon</td>                      
                      </tr>
                       <tr>
                          <td style="font-size: 12px;"><b></b>About Author:</b></td>
                          <td style="font-size: 10px;"></td>                      
                      </tr>
                      </table>
                        <!---------------Adds Are Here ----------------------!>   
                        <?php
                            require "..//../../IndexRelated/Adds1.php";
                        ?>
                        <!---------------Adds Are Here ----------------------!>    
                    </div>
                     <p style="float: right; color:#430383 ;"><a href="JavaTutorialBasicSyntax.php">Next Page-&gt;&gt;</a></p> <br/>
                     
                     <!--<table align='left' border='1' style="width: 10%; float: right;">
                      <tr>
                      <td><b></b>Author:</b></td>
                      <td>ASHUTOSH KUMAR CHOUBEY</td>                      
                      </tr>                      
                      </table>-->
             
                      <p><b style="font-size: 20px; color: #2F0422;">Search for happiness-:(Sub Title) </b>
                    There are four things which are common between us
                    and animals. And that is  which means eating. We are
                    making arrangements, elaborate arrangements so that some
                    how or the other we can solve the problem of this eating
                    which is essential. Sleeping, to protect ourselves,
                    that is defending and -procreation, producing offsprings.
                    It is said that these four????? ??? ????? ??????, ???????? ??????, ??????, ????? ?? ?????. ?????? ????? ?????? ?? ????, ????????? ?? ??? ???? ?????? ?? ?? ?????
                    activities are common between us and the animals.(Discription)</p>
                     <p align='center'>In Vedic literature it is said:(Image Title)</p>
                     <p align='center'> <img src="../../../UploadedImage/slock1.png" class="img-responsive" alt="Cinque Terre"  /><caption>(Image)</caption></p>
                     
                        <p><b style="font-size: 20px; color: #2F0422;"> What is Java:(Sub Title)</b>
<br/><li style="font-size: 15px; color: #8A470B;"> </b><b style="font-size: 17px; color: #33023D">Object Oriented:(Points Title)</b>Everything is an Object In Java. It can be easily extended since it is based on the Object orianted Model.<caption >(Points Discription)</caption>
</li><br/><li style="font-size: 15px; color: #8A470B"> <b style="font-size: 17px; color: #2F0422;"> Platform Independent:(Points Title)</b>Java is the first  Language which is Platform Independent because used both compiler and Interpreter.<caption >(PointsDiscription)</caption>
</li><br/><li style="font-size: 15px; color: #8A470B;"> <b style="font-size: 17px; color: #2F0422;"> Secure:</b> Java is very secure Which enables to develop virus-free, tamper-free systems. Here Authentication techniques are based on public-key encryption which makes more secure.
</li><br/><li style="font-size: 15px; color: #8A470B;"><b style="font-size: 17px; color: #2F0422;"> Simple:</b> Java is Very Simple and to easy to learn. If you understand the basic concept of Object orianted programming , Java would be easy to be a master.
</li><br/><li style="font-size: 15px; color: #8A470B;"> <b style="font-size: 17px; color: #2F0422;"> Portable:</b>Java Programs can Moved easily  from one computer to another anywhere and anytimes .java is populer programming language on internet which interconnect different kinds of system worldwise
</li><br/><li style="font-size: 15px; color: #8A470B;"><b style="font-size: 17px; color: #2F0422;"> Robust:</b> is provides many safeguards to ensure reliable code.
</li><br/><li style="font-size: 15px; color: #8A470B;"> <b style="font-size: 17px; color: #2F0422;"> Interpreted:</b> Java byte code is translated  to  machine instructions and it is not stored anywhere. The development process is very rapid and analytical when it links is an incremental and light-weight process.</li>
</li><br/><li style="font-size: 15px; color: #8A470B;"> <b style="font-size: 17px; color: #2F0422;"> Multithreaded:</b>That means java compiler handle  muliple tasks simultaniously.
</li><br/><li style="font-size: 15px; color: #8A470B;"><b style="font-size: 17px; color: #2F0422;"> High Performance:</b> Java gives high performance.</p> 
<p style="float: right; color:#430383 ;"><a href="JavaTutorialBasicSyntax.php">Next Page-&gt;&gt;</a></p> <br/>
                       
                                       
                                       
                                <!--Work section End -->
                                <!--------------------------------------->
        		</div>
        	
<?
require "BelowWorkPlace.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>
</html>	