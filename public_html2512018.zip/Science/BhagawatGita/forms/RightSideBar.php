<h1>Other usefull link</h1>
			<ul>
				<li><a href="#">News</a></li>
				<li><a href="#">General Knowledge</a></li>
				<li><a href="#">Tips and Tricks</a></li>
				<li><a href="#">technical tips</a></li>
                <li><a href="#">Notes</a></li>
                <li><a href="#">Encyclopedia</a></li>                
			</ul>