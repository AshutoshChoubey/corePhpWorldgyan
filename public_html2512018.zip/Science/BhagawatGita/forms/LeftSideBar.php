<?php
{
?>
<div id="sidebar">
        			<ul>
		      		  <li>
        					<div style="clear: both;">&nbsp;</div>
        				</li>
        				<li>
        					<h2>Java Tutorial </h2>
        					<ul>
        						<li><a <? if($Contents=='JavaTutorial') echo "class=\"openLink\"";  ?>  href="/Science/Java/forms/JavaTutorial.php">Introduction</a></li>
        						<li><a <? if($Contents=='JavaTutorialBasicSyntax') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialBasicSyntax.php">Basic Syntax</a></li>
        						<li><a <? if($Contents=='JavaTutorialJavaPlatform') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialJavaPlatform.php">Java Platform</a></li>
        						<li><a <? if($Contents=='JavautorialArraysandForloop') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavautorialArraysandForloop.php">Arrays and For loop</a></li>
        						<li><a <? if($Contents=='JavautorialConstructors') echo "class=\"openLink\"";  ?>  href="/Science/Java/forms/JavautorialConstructors.php">Constructors</a></li>
        						<li><a <? if($Contents=='JavaTutorialStaticMembers') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialStaticMembers.php">Static Members</a></li>
        						<li><a <? if($Contents=='JavaTutorialOverloadingMethods') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialOverloadingMethods.php">Overloading Methods</a></li>
        						<li><a <? if($Contents=='JavaTutorialInnerClasses') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialInnerClasses.php">Inner Classes</a></li>
        						<li><a <? if($Contents=='JavaTutorialInheritance') echo "class=\"openLink\"";  ?>  href="/Science/Java/forms/JavaTutorialInheritance.php">Inheritance</a></li>
                                <li><a  <? if($Contents=='JavaTutorialAccessusingSuperkeyword') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialAccessusingSuperkeyword.php">Accessusing Super keyword</a></li>           
                                <li><a <? if($Contents=='JavaTutorialConstructorsinInheritance') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialConstructorsinInheritance.php">Constructors in Inheritance</a></li>
                                <li><a  <? if($Contents=='JavaTutorialOverriddenMethods') echo "class=\"openLink\"";  ?>  href="/Science/Java/forms/JavaTutorialOverriddenMethods.php">Overridden Methods</a></li>
                                <li><a  <? if($Contents=='JavaTutorialFinalKeyword') echo "class=\"openLink\"";  ?>  href="/Science/Java/forms/JavaTutorialFinalKeyword.php">Final Keyword</a></li>
                                <li><a <? if($Contents=='JavaTutorialMultipleimplements') echo "class=\"openLink\"";  ?> href="/Science/Java/forms/JavaTutorialMultipleimplements.php">Multiple implements</a></li>
        					</ul>
        				</li>
        			</ul>
</div>
<?
}
?>