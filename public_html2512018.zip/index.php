<?php
$Description="WorldGyan provides free Tutorials and Knowledge in all the field .WorldGyan has focus on simplicity,straight-forward learning.
We have Lots of articles,theory,projects,Offline Materials,etc. which is very helpfull for the peoples.";
$Keywords="WorldGyan,Learn Every thing,All the tutorial,Lots of Tutorials,Easy learning Tutorial,Earn Money Through WorldGan ,Laravel tutorial,Data base tutorial,Dbms Tutorial,Java Tutorials,Advertize from WorldGyan.Worldgyan is the solution of all problem.WorldGyan Provides Technical and Non Technical Tutorias.WorldGyan is Fast growing ";
    require "IndexRelated/indexUpper.php";
?> 
		<!------------------------------------------------------ Center Column Start ------------------------------------------------------------>
        <div style="width: 100%;">
                <div class="post">
                				<h2 align='center' class="title"><a href="/Science/Java/forms/JavaTutorial.php">Java Tutorials</a></h2>
                				<p class="meta"><span class="date">November 27, 2017</span></p>
                				<div style="clear: both;">&nbsp;</div>
                				<div class="entry">
                					<p style="font-size: 15px; color: #031B4C;"><b style="font-size: 20px; color: #2F0422;">History-: </b>Java language Developed  by James Gosling and 5 people in  1991 for use in one of his many  projects.</p>
                                        <li style="font-size: 15px; color: #8A470B"> Platform Independent:Java is the first  Language which is Platform Independent because used both compiler and Interpreter.
                                        </li><li style="font-size: 15px; color: #8A470B;">  Object Oriented
                                        </li><li style="font-size: 15px; color: #8A470B;">
                                        Internet Supported</li>
                                        <li style="font-size: 15px; color: #8A470B;"> 
                                        Allow us to design Applications and Applets
                                        </li>
                                        <li style="font-size: 15px; color: #8A470B;">  
                                        Supports Distributed and Network Applications
                                        </li>
                                        <li style="font-size: 15px; color: #8A470B;"> 
                                        Supports Multimedia
                                        </li>
                                        <li style="font-size: 15px; color: #8A470B;"> 
                                        Compiler and Interpret based
                                        </li>
                                        <li style="font-size: 15px; color: #8A470B;"> 
                                        secure                                
                                        </li>
                                        <li style="font-size: 15px; color: #8A470B;"> 
                                        Multi threaded and Dynamic                                
                                        </li>
                                   <p class="TutorialNextPagea"><a href="/Science/Java/forms/JavaTutorial.php">Learn More-&gt;&gt;</a></p> <br/>
                                </div>
  			       </div>
                		 <div style="clear: both;">&nbsp;</div>
                         <div class="post">
                				<h2 align='center' class="title"><a href="/Science/Laravel/forms/LaravelTutorial.php">Laravel</a></h2>
                				<p class="meta"><span class="date">December 17, 2017</span></p>
                				<div style="clear: both;">&nbsp;</div>
                				<div class="entry">
                					<p style="font-size: 15px; color: #031B4C;">This instructional exercise will manage the engineers and understudies who need to figure out how to build up
                                           a site utilizing Laravel.
                                    </p>
                                    <p><li class="PointTutorials"> 
                                       Laravel is a MVC structure with groups, movements, and Artisan CLI. 
                                       this offers a vigorous arrangement of instruments and an application design that consolidates a significant
                                       number of the best highlights of structures like CodeIgniter, ASP.NET MVC, Ruby on Rails etc  .
                                        </li>
                                    </p>
                                    <p><li class="PointTutorials">
                                            Laravel is an Open Source system. It has an exceptionally rich arrangement of highlights which will help the speed of Web Development. On the off chance that you comfortable with Core PHP and Advanced PHP, Laravel will make your errand less demanding. It will spare a considerable measure time on the off chance that you are wanting to build up a site starting with no outside help. Not just that, the site worked in Laravel is likewise secure. It keeps the different assaults that can occur on sites.
                                        </li>
                                    </p>
                                </div>
                                    <p class="TutorialNextPagea"><a href="/Science/Laravel/forms/LaravelTutorial.php">Learn More-&gt;&gt;</a></p> <br/>
    			     </div>
                     <div class="post">
                				<h2 align='center' class="title"><a href="/Science/DBMS/forms/index.php">Data Base Tutorial(DBMS)</a></h2>
                				<p class="meta"><span class="date">January 01, 2018</span></p>
                				<div style="clear: both;">&nbsp;</div>
                				<div class="entry">
                					<p style="font-size: 15px; color: #031B4C;">Applicartion of DBMS
                                    </p>
                                    <p><li class="PointTutorials"> 
                                      Program Data Independence.
                                        </li>
                                    </p>
                                    <p><li class="PointTutorials">
                                            Authorized Implementation or Accesses.</li>
                                    </p>
                                    <p><li class="PointTutorials">
                                           High Level Security.</li>
                                    </p>
                                     <p><li class="PointTutorials">
                                           Controlling Redundancy.</li>
                                    </p>
                                     <p><li class="PointTutorials">
                                          Persistance storage for objects.</li>
                                    </p>
                                     <p><li class="PointTutorials">
                                         We can implement Index</li>
                                    </p>
                                </div>
                                    <p class="TutorialNextPagea"><a href="/Science/DBMS/forms/index.php">Learn More-&gt;&gt;</a></p> <br/>
    			     </div>
                		 <div style="clear: both;">&nbsp;</div>
         </div>
        
		<!------------------------------------------------------ /Center Column Start ------------------------------------------------------------>
<?php
    require "IndexRelated/indexLower.php";
?> 
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////
				
	/////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
    
</script>