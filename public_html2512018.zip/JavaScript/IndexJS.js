function Category(Category)
        {
            var url="/Science/Science.php";
            url=url+"?sesCategory="+Category;
            location.href=url;
        }
