<?php
$Contents='';
 require "IndexRelated/indexUpper.php";
?>
        		
                                       <!-- Start from Here -->
  
		<h2 align='center'>Helping</h2>

<p class="h3" style="color: #380808;">
If you are expert in any subjects,Topics or in anything Then  you can  to help internet community, write your own artical and share with us. 
If your articals are original, accurate and relevant then we will publish them on our website.
</p>
                                <!--Work section End -->
                                <!--------------------------------------->
        	
        	
<?php
  require "IndexRelated/indexLower.php";
?>   
<script language="javascript" type="text/javascript">
	/////////////////////////////////////////////////////////////Start Client SIDE CODE //////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////End Client SIDE CODE //////////////////////////////////////////////////////////
</script>
</html>